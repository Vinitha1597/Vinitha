package com.Base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

public class Testbase extends GenerateExtentReport {

	//private static final GenerateExtentReport SafariDriverManager = null;
	public static WebDriver driver;
	public static Properties prop;
	static int relativemaxheight = 744;
	static int relativemaxwidth = 1301;
	public static String browsern;

	public Testbase() {
		try {
			prop = new Properties();
			FileInputStream ip = new FileInputStream(
					System.getProperty("user.dir") + "/src/main/java/com/configprop/Config.Properties");
			prop.load(ip);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void initialization(String browserName) throws Exception {
		//String browserName = prop.getProperty("browser");
		browsern = browserName;

		if (browserName.equals("windows_chrome")) {

			System.setProperty("webdriver.chrome.driver", "..//powernoodle-selenium//Drivers//chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browserName.equals("windows_FF")) {
			System.setProperty("webdriver.gecko.driver", "..//powernoodle-selenium//Drivers//geckodriver.exe");
			driver = new FirefoxDriver();
		}
		else if (browserName.equals("windows_IE")) {
			System.setProperty("webdriver.ie.driver", "..//powernoodle-selenium//Drivers//IEDriverServer.exe");
			
			InternetExplorerOptions options = new InternetExplorerOptions();
			options.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			
			driver = new InternetExplorerDriver(options);	        

		}
		else if (browserName.equals("windows_edge")) {
			System.setProperty("webdriver.edge.driver","..//powernoodle-selenium//Drivers//MicrosoftWebDriver.exe");
			DesiredCapabilities dcap = DesiredCapabilities.edge();
	        dcap.setCapability("pageLoadStrategy", "normal");
				           	        
			driver = new EdgeDriver(dcap);
		}
		else if (browserName.equals("linux_chrome")) {
			System.setProperty("webdriver.chrome.driver", "..//powernoodle-selenium//Drivers//chromedriver");
			driver = new ChromeDriver();
		}
		else if (browserName.equals("linux_FF")) {
			System.setProperty("webdriver.gecko.driver", "..//powernoodle-selenium//Drivers//geckodriver");
			driver = new FirefoxDriver();
		}
		else if (browserName.equals("mac_chrome")) {
			System.setProperty("webdriver.chrome.driver", "..//powernoodle-selenium//Drivers//macdrivers//chromedriver");
			driver = new ChromeDriver();
		}
		else if (browserName.equals("mac_FF")) {
			System.setProperty("webdriver.gecko.driver", "..//powernoodle-selenium//Drivers//macdrivers//geckodriver");
			driver = new FirefoxDriver();
		}
		else if (browserName.equals("mac_safari")) {							
			driver = new SafariDriver();
		}
		else {
			System.out.println("Choose a correct browser");
		}

		Thread.sleep(1000);
		org.openqa.selenium.Dimension dm = driver.manage().window().getSize();

		if (dm.height < relativemaxheight && dm.width < relativemaxwidth) {
			driver.manage().window().maximize();
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().deleteAllCookies();
		driver.get(prop.getProperty("url"));
		Thread.sleep(1000);
	}

}
