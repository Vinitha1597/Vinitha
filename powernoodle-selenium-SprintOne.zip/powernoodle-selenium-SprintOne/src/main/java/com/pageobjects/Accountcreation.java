package com.pageobjects;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.Base.Testbase;

public class Accountcreation extends Testbase {

	@FindBy(xpath = "//a[contains(text(),'Sign up for FREE')]")
	WebElement Clickonsignup;

	@FindBy(xpath = "//input[@placeholder='First Name']")
	WebElement firstname;

	@FindBy(id = "lastname")
	WebElement lastname;

	@FindBy(id = "email")
	WebElement Enteremail;

	@FindBy(id = "password")
	WebElement createpswd;
	@FindBy(id = "termsconditions")
	WebElement checkbox;
	@FindBy(id = "submit")
	WebElement Clicksignup;
	
	@FindBy(xpath = "//div[@class='SignupComplete']/h3")
	WebElement signupCompleteMsg;
	
	@FindBy(xpath="//form[@id='signup']//ul/li[1]")
	WebElement emptyFieldsError;
	
	@FindBy(xpath="//form[@id='signup']//ul/li[2]")
	WebElement emptyEmailError;
	
	@FindBy(xpath="//form[@id='signup']//ul/li[1]")
	WebElement invalidEmailError;
	
	@FindBy(xpath = "//form[@id='signup']/div[1]/p")
	List<WebElement> emptyPasswordErrors;
	
	@FindBy(xpath="//form[@id='signup']/div[@class='pw_errors']/ul/li/span")
	List<WebElement> invalidPasswordErrors;
	
	@FindBy(xpath = "//form[@id='signup']/div/p")
	WebElement invalidPswdError;

	public Accountcreation() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}

	public void Sign_up() {
		Clickonsignup.click();
	}

	public void add_details(String fn, String ln, String email, String pswd) {
		firstname.sendKeys(fn);
		lastname.sendKeys(ln);
		Enteremail.sendKeys(email);
		createpswd.sendKeys(pswd);
		checkbox.click();
		/*JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", Clicksignup);*/
		

	}
	
	public String checkSignUpCompleteMsg() throws Exception{
		Thread.sleep(2000);
		return signupCompleteMsg.getText();
	}
	
	public String signupWithEmptyFields() throws Exception{
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", Clicksignup);
		Thread.sleep(1000);
		return emptyFieldsError.getText();
	}
	
	public String signupWithEmptyFirstName(String ln, String email,String pswd) throws Exception{
		
		lastname.sendKeys(ln);
		Enteremail.sendKeys(email);
		createpswd.sendKeys(pswd);
		checkbox.click();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", Clicksignup);
		Thread.sleep(1000);
		return emptyFieldsError.getText();
	}

	public String signupWithEmptyLastName(String fn, String email,String pswd) throws Exception{
	
		firstname.sendKeys(fn);
		Enteremail.sendKeys(email);
		createpswd.sendKeys(pswd);
		checkbox.click();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", Clicksignup);
		Thread.sleep(1000);
		return emptyFieldsError.getText();
	}

	public String signupWithEmptyEmail(String fn, String ln,String pswd) throws Exception{
	
		firstname.sendKeys(fn);
		lastname.sendKeys(ln);
		Enteremail.clear();
		createpswd.sendKeys(pswd);
		checkbox.click();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", Clicksignup);
		Thread.sleep(1000);
		String errormessage = emptyFieldsError.getText()+" "+emptyEmailError.getText();
		System.out.println(errormessage);
		return errormessage;
	}
	
	public String signupWithInvalidEmail(String fn, String ln,String email,String pswd) throws Exception{
		
		firstname.sendKeys(fn);
		lastname.sendKeys(ln);
		Enteremail.clear();
		Enteremail.sendKeys(email);
		createpswd.sendKeys(pswd);
		checkbox.click();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", Clicksignup);
		Thread.sleep(1000);
		return invalidEmailError.getText();
	}
	
	public String signupWithEmptyPswd(String fn, String ln,String email) throws Exception{
		
		firstname.sendKeys(fn);
		lastname.sendKeys(ln);
		Enteremail.clear();
		Enteremail.sendKeys(email);
		checkbox.click();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", Clicksignup);
		Thread.sleep(1000);
		String error = "";
		for(WebElement element: emptyPasswordErrors) {
			error = error + " " + element.getText();
		}
		return error;
	}
	
	public Boolean signupWithInvalidPswd(String fn, String ln,String email,String pswd) throws Exception{
		
		firstname.sendKeys(fn);
		lastname.sendKeys(ln);
		Enteremail.clear();
		Enteremail.sendKeys(email);
		createpswd.sendKeys(pswd);
		checkbox.click();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", Clicksignup);
		Thread.sleep(1000);
		/*String error = "";
		for(WebElement element: invalidPasswordErrors) {
			error = error + " " + element.getText();
		}*/
		
		return invalidPswdError.isDisplayed();
	}

	
	public String signupWithUnClickedCheckBox(String fn, String ln,String email,String password) throws Exception{
			
			firstname.sendKeys(fn);
			lastname.sendKeys(ln);
			Enteremail.clear();
			Enteremail.sendKeys(email);
			createpswd.sendKeys(password);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].click();", Clicksignup);
			Thread.sleep(1000);
			return invalidPswdError.getText();
		}
}
