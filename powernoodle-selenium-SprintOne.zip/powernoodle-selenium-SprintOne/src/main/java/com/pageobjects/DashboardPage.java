package com.pageobjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Base.Testbase;

public class DashboardPage extends Testbase {

	WebDriverWait wait = new WebDriverWait(driver, 40);

	@FindBy(xpath = "//div[@id='main']//ul/li/a")
	List<WebElement> allMenus;

	@FindBy(xpath = "//div[@id='main']//ul/li/a[contains(text(),'All Decision Spaces')]")
	WebElement dashboardIcon;

	@FindBy(xpath = "//div[@id='main']//ul/li/a[contains(text(),'User Settings')]")
	WebElement settingsIcon;

	@FindBy(xpath = "//button[contains(text(),'Use a Model')]")
	WebElement useModelMenu;

	@FindBy(xpath = "//button[contains(text(),'Create a new Decision Space')]")
	WebElement createNewDecisionMenu;

	@FindBy(id = "filter-text")
	WebElement searchBox;

	@FindBy(xpath = "//ul[@id='spaces']/li")
	WebElement spaces;

	@FindBy(xpath = "//div[@class='userSettings']/h2[contains(text(),'Account Details')]")
	WebElement accountdetailsTitle;

	@FindBy(xpath = "//div[@id='main']//ul/li/a[contains(text(),'Contacts')]")
	WebElement contactsIcon;

	@FindBy(xpath = "//div[@id='contacts']/h2[contains(text(),'Contacts')]")
	WebElement contactsTitle;

	@FindBy(xpath = "//div[@id='contacts']/button[contains(text(),'Add Contact')]")
	WebElement addContactsButton;

	@FindBy(xpath = "//*[@id='help-btn']")
	WebElement helpIcon;

	@FindBy(xpath = "//h1[contains(text(),'Help Center for Powernoodle')]")
	WebElement helpTabTitle;

	@FindBy(xpath = "//div[@id='main']//ul/li/a[contains(text(),'Logout')]")
	WebElement logoutIcon;

	@FindBy(xpath = "//ul[@id='spaces']/li/button")
	WebElement enterButtonInSpaces;

	@FindBy(id = "nav-settings-menu")
	WebElement settingsButton;

	@FindBy(xpath = "//input[@value='Login to Powernoodle']")
	WebElement loginButton;

	public DashboardPage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}

	public Boolean checkAreMenusThere() throws Exception {

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Use a')]")));
		//button[contains(text(),'Use a Template')]
		Boolean found;

		Thread.sleep(2000);
		if (allMenus.size() == 4) {
			found = true;
		} else {
			found = false;
		}
		return found;

	}
	
	public Boolean checkAreMenusThereInParticipant() throws Exception {

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Toggle Main Menu']")));
		Boolean found;

		Thread.sleep(2000);
		if (allMenus.size() == 4) {
			found = true;
		} else {
			found = false;
		}
		return found;

	}

	public Boolean checkAllDecisionSpace() throws Exception {
		Thread.sleep(2000);
		if (isPresent("//button[contains(text(),'Use a')]")
				&& isPresent("//button[contains(text(),'Create a new Decision Space')]")
				&& isPresent("//*[@id='filter-text']")) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean checkSettingsMenus() throws Exception {

		JavascriptExecutor set = (JavascriptExecutor) driver;
		set.executeScript("arguments[0].click();", settingsIcon);
		Thread.sleep(2500);
		if (allMenus.size() == 6) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean checkAccountDetailsMenu() throws Exception {

		if (accountdetailsTitle.isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean checkContactsMenu() throws Exception {
		Thread.sleep(3000);
		JavascriptExecutor contact = (JavascriptExecutor) driver;
		contact.executeScript("arguments[0].click();", contactsIcon);
		Thread.sleep(2000);
		if (contactsTitle.isDisplayed() && addContactsButton.isDisplayed() && searchBox.isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean checkHelpMenu() throws Exception {
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("help-btn")));
		Thread.sleep(1000);
		WebElement help;
		
		if(browsern.equals("windows_edge")) {
			 help = driver.findElement(By.partialLinkText("Help "));
			 help.click();
		}
		else {
			help = driver.findElement(By.id("help-btn"));
			JavascriptExecutor hm = (JavascriptExecutor) driver;
			hm.executeScript("arguments[0].click();", help);
		}
		
		
		
		Thread.sleep(3000);
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());			
		
		Thread.sleep(1000);
		
		
		
		driver.switchTo().window(tabs2.get(1));
		Thread.sleep(3000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(),'Help Center for Powernoodle')]")));
		Thread.sleep(1000);
		int helptitle = driver.findElements(By.xpath("//h1[contains(text(),'Help Center for Powernoodle')]")).size();
		Thread.sleep(2000);
		if (helptitle>0) {
			driver.switchTo().window(tabs2.get(0));
			return true;
		} else {
			driver.switchTo().window(tabs2.get(0));
			return false;
		}
		

	}

	public Boolean checkSpaces() throws Exception {
		Thread.sleep(1000);

		JavascriptExecutor enterSpace = (JavascriptExecutor) driver;
		enterSpace.executeScript("arguments[0].click();", enterButtonInSpaces);
		Thread.sleep(2000);
		if (isPresent("//a[contains(text(),'Home')]")) {
			return true;
		} else {
			return false;
		}

	}

	public Boolean logoutMenu() throws Exception {
		Thread.sleep(3000);
		JavascriptExecutor logout = (JavascriptExecutor) driver;
		logout.executeScript("arguments[0].click();", logoutIcon);
		// logoutIcon.click();
		Thread.sleep(3000);
		if (loginButton.isDisplayed()) {
			return true;
		} else {
			return false;
		}

	}

	public Boolean isPresent(String location) throws Exception {
		List<WebElement> list = driver.findElements(By.xpath(location));
		if (list.size() != 0) {
			return true;
		} else
			return false;
	}
}
