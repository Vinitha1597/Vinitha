package com.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Base.Testbase;

public class Usemodel extends Testbase {

	@FindBy(xpath = "//button[contains(text(),'Create a new Decision Space')]")
	WebElement Decisionspace;

	@FindBy(xpath = "//input[@placeholder='Enter a name for your Decision Space']")
	WebElement adddecision;

	@FindBy(xpath = "//button[contains(text(),'Submit')]")
	WebElement submit;

	@FindBy(xpath = "//a[contains(text(),'Facilitator')]")
	WebElement facilitator;

	@FindBy(xpath = "//a[contains(text(),'Save to Model')]")
	WebElement savemodel;

	@FindBy(xpath = "//button[@id='makeTpl']")
	WebElement makemodel;

	@FindBy(xpath = "//*[@id='all-decision-btn']")
	WebElement clickdashboard;
	@FindBy(xpath = "//button[contains(text(),'Use a Model')]")
	WebElement clickmodel;

	WebDriverWait wait = new WebDriverWait(driver, 40);
	
	public Usemodel() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}

	public void decisionspace() throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Use a Model')]")));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", Decisionspace);
		Thread.sleep(1000);
		JavascriptExecutor dec = (JavascriptExecutor) driver;
		adddecision.clear();
		dec.executeScript("arguments[0].click();", adddecision);
		adddecision.sendKeys("Elms");
		Thread.sleep(1000);

		JavascriptExecutor add = (JavascriptExecutor) driver;
		add.executeScript("arguments[0].click();", submit);
		Thread.sleep(1000);
	}

	public void model() throws InterruptedException {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", facilitator);
		Thread.sleep(1000);

		JavascriptExecutor menu = (JavascriptExecutor) driver;
		menu.executeScript("arguments[0].click();", savemodel);
		Thread.sleep(500);

		JavascriptExecutor model1 = (JavascriptExecutor) driver;
		model1.executeScript("arguments[0].click();", makemodel);
		Thread.sleep(1000);

	}

	public void dashboard() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", clickdashboard);
		Thread.sleep(1000);

		JavascriptExecutor model1 = (JavascriptExecutor) driver;
		model1.executeScript("arguments[0].click();", clickmodel);
		Thread.sleep(500);
	}
}
