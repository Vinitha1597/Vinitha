package com.pageobjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Base.Testbase;

public class NextActionPage extends Testbase {

	

	@FindBy(xpath = "//ul[@id='spaces']/li/h3/preceding-sibling::button")
	List<WebElement> enterButtonInSearchingSpace;
	
	@FindBy(xpath = "//ul[@id='spaces']/li/h3")
	List<WebElement> spaceNames;
	
	@FindBy(xpath = "//div[@id='decision_space']/div[@class='header']/h2")
	WebElement headerNameOfSpace;
	
	@FindBy(xpath="//button[@id='open-btn']")
	WebElement openActionBtn;
	
	@FindBy(id= "dialog-close-btn")
	WebElement tickMarkOfActionSettings;
	
	@FindBy(xpath = "//div[@class='idea']//span[@class='ideaNumber']")
	WebElement ideanumber;
	
	@FindBy(xpath = "//div[@class='idea']//span[@class='title']/p")
	WebElement ideaTitle;
	
	@FindBy(xpath = "//div[@class='idea']//div[contains(@class,'commentsNumber')]")
	WebElement ideacommentcount;
	
	@FindBy(xpath = "//button[text()='Add Action']")
	WebElement addActionBtn;
	
	@FindBy(id="total_participants_done")
	WebElement participantDoneCount;
	
	@FindBy(xpath="//label[@for='participant_done']")
	WebElement participantDoneCheckbox;
	
	@FindBy(xpath = "//form[@class='add_action']/input[@type='text']")
	List<WebElement> addActionsTextFields;
	
	@FindBy(xpath = "//input[@name='task']")
	WebElement actionTextbox;
	
	@FindBy(xpath = "//input[@name='assigned_to']")
	WebElement assignedToTextbox;
	
	@FindBy(xpath = "//input[@name='priority']")
	WebElement priorityTextbox;
	
	@FindBy(xpath = "//input[@name='task_status']")
	WebElement statusTextbox;
	
	@FindBy(xpath = "//input[@name='due_date']")
	WebElement duedateTextbox;
	
	@FindBy(xpath = "//input[@name='complete']")
	WebElement completeTextbox;
	
	@FindBy(xpath = "//form[@class='add_action']//button[text()='Add Action']")
	WebElement addActionButtonInForm;
	
	@FindBy(xpath = "//table[@class='table-condensed']/thead/tr[1]/th[@class='picker-switch']")
	WebElement yearmonthheaderInCal;
	
	@FindBy(xpath = "//div[@style='display: block;']//thead/tr[1]/th[@class='prev']")
	WebElement previousArrowIcon;
	
	@FindBy(xpath = "//div[@style='display: block;']//thead/tr[1]/th[@class='next']")
	WebElement nextArrowIcon;
	
	@FindBy(xpath = "//span[@class='glyphicon glyphicon-time']")
	WebElement timeIcon;
	
	@FindBy(xpath = "//span[@data-action='showHours']")
	WebElement hoursSelected;
	
	@FindBy(xpath = "//span[@data-action='showMinutes']")
	WebElement minuteSelected;
	
	@FindBy(xpath = "//button[@data-action='togglePeriod']")
	WebElement ampmSelected;
	
	@FindBy(xpath = "//a[@data-action='incrementHours']/span")
	WebElement hrsUpIcon;
	
	@FindBy(xpath = "//a[@data-action='decrementHours']/span")
	WebElement hrsDownIcon;
	
	@FindBy(xpath = "//a[@data-action='incrementMinutes']/span")
	WebElement minuteUpIcon;
	
	@FindBy(xpath = "//a[@data-action='decrementMinutes']/span")
	WebElement minuteDownIcon;
	
	@FindBy(xpath = "//td[@class='edit']/button")
	WebElement pencilIcon;
	
	@FindBy(id="dialog-delete-btn")
	WebElement deleteActionIcon;
	
	@FindBy(id="confirm-btn")
	WebElement confirmDeleteAction;
	
	@FindBy(xpath = "//img[@src='images/icons/greyPlus.svg']")
	WebElement descPlusIcon;
	
	@FindBy(xpath = "//div[@id='desc-edit']//div[@role='textbox']")
	WebElement descTextbox;
	
	@FindBy(xpath = "//div[@id='desc-edit']//div[@role='textbox']//span[@data-text='true']")
	WebElement descTextboxText;
	
	@FindBy(id = "activity-settings-btn")
	WebElement activitySettingsMenu;
	
	@FindBy(id="filter-btn")
	WebElement filterMenu;
	
	@FindBy(id="export_ideas")
	WebElement exportTileButton;
	
	@FindBy(xpath = "//select[@id='decision_space_chooser']")
	WebElement selectDSDropdownbox;
	
	@FindBy(id="reveal_add")
	WebElement addNewTopicButton;
	
	@FindBy(xpath = "//input[@placeholder='Add a new topic']")
	WebElement addNewTopicTextBox;	
	
	@FindBy(xpath = "//button[@id='add-activity-btn'][text()='Add']")
	WebElement addTopicBlueButton;
	
	@FindBy(xpath = "//label[@id='export_tags_lbl_yes']")
	WebElement yesTagButton;
	
	@FindBy(id = "export_btn")
	WebElement exportButton;
	
	@FindBy(id="all-decision-btn")
	WebElement alldsmenu;
	
	@FindBy(xpath = "//label[@id='hide_files_lbl_show']")
	WebElement showFileButtonInActionDialogue;
	
	@FindBy(xpath = "//h2[text()='Actions']")
	WebElement actionIcon;
	
	@FindBy(xpath = "//h2[text()='Noodle']")
	WebElement noodleIcon;
	
	@FindBy(xpath = "//button[text()='Open Tagging']")
	WebElement openTagBtn;
	
	@FindBy(id = "confirm-btn")
	WebElement confirmReopenBtn;
	
	@FindBy(xpath = "//label[@for = 'show-tag-block-show-description']")
	WebElement showTagCheckbox;
	
	@FindBy(xpath = "//label[@for='view-style-block-show-description']")
	WebElement showDescriptionCheckbox;
	
	@FindBy(xpath = "//label[@id='tile_visibility_lbl_all']")
	WebElement allTileVisibilityButtonInActionDialogue;
	
	@FindBy(xpath = "//label[@title='My Tiles']")
	WebElement myTileContributorBtn;
	
	
	@FindBy(xpath = "//label[@title='All Tiles']")
	WebElement allTileContributorBtn;
	
	@FindBy(xpath = "//label[@for='tagfirst-on']")
	WebElement onTagFirstToggle;
	
	@FindBy(xpath ="//label[@id='tile_visibility_lbl_owner']")
	WebElement ownerTileVisibilityButtonInActionSettings;
	
	@FindBy(xpath = "//div[@class='ideaTxt']/span[1]")
	List<WebElement> tileNumbers;
	
	@FindBy(xpath ="//label[@id='hide_tag_lbl_false']")
	WebElement hideTagsOnTileInActionSettings;
	
	@FindBy(xpath ="//label[@id='hide_tag_lbl_true']")
	WebElement showTagsOnTileInActionSettings;
	
	@FindBy(xpath ="//label[@for='hide_comments_rdo_show']")
	WebElement allcommentsVisibilityInActionSettings;
	
	@FindBy(xpath ="//label[@for='hide_comments_rdo_hide']")
	WebElement ownercommentsVisibilityInActionSettings;
	
	@FindBy(xpath = "//div[@class='add-comment']//div[@role='textbox']")
	WebElement writeACommentTextBox;
	
	@FindBy(xpath = "//button[contains(text(),'Post')]")
	WebElement postcommentButton;
	
	@FindBy(xpath ="//label[@for='hide_files_rdo_show']")
	WebElement showFileVisibilityInActionSettings;
	
	@FindBy(xpath ="//label[@for='hide_files_rdo_hide']")
	WebElement hideFileVisibilityInActionSettings;
	
	@FindBy(xpath ="//label[@id='everyone_tags_lbl_yes']")
	WebElement alltaggingAbilityInActionSettings;
	
	@FindBy(xpath ="//label[@id='everyone_tags_lbl_no']")
	WebElement ownerstaggingAbilityInActionSettings;
	
	@FindBy(xpath = "//a[@id='idea_tags']")
	WebElement tagLabelInsideTile;
	
	@FindBy(xpath = "//label[@for='sort_ascend_alpha']")
	WebElement alphaAscendingAS;
	
	@FindBy(xpath = "//label[@for='sort_descend_alpha']")
	WebElement alphaDescendingAS;
	
	@FindBy(xpath = "//label[@for='sort_ascend']")
	WebElement sortAscendingAS;
	
	@FindBy(xpath = "//label[@for='sort_descend']")
	WebElement sortDescendingAS;
	
	@FindBy(xpath = "//label[@for='sort_shuffle']")
	WebElement sortShuffleAS;
	
	@FindBy(xpath = "//button[text()='Reset Next Actions']")
	WebElement resetNextactionButton;
	
	public NextActionPage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}
	
	WebDriverWait wait = new WebDriverWait(driver, 40);
	JavascriptExecutor closeTickMark = (JavascriptExecutor) driver;
	Actions action=new Actions(driver);

	public String clickSpace(String noodleTitle) throws Exception {
		Thread.sleep(2000);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='spaces']/li/button")));
		
		List<WebElement> spaceall = driver.findElements(By.xpath("//ul[@id='spaces']/li/h3"));
		
		

		for (int i = 0; i < spaceall.size(); i++) {

			String s = spaceall.get(i).getText();
			

			if (s.equals(noodleTitle)) {

				WebElement enterBtn = enterButtonInSearchingSpace.get(i);

				JavascriptExecutor eb = (JavascriptExecutor) driver;
				eb.executeScript("arguments[0].click();", enterBtn);
				//enterBtn.click();
				break;
			}
		}

		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//div[@id='decision_space']/div[@class='header']/h2")));
		Thread.sleep(1000);

		return headerNameOfSpace.getText();
	}
	
	public boolean openNextActionForATopic(String topic) throws Exception{
		
		//action.moveToElement(driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li//button[contains(text(), 'Actions Settings')]"))).build().perform();
		
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li//button[contains(text(), 'Actions Settings')]")));
		WebElement ns = driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li//button[contains(text(), 'Actions Settings')]"));
		JavascriptExecutor eb = (JavascriptExecutor) driver;
		eb.executeScript("arguments[0].click();", ns);
		Thread.sleep(2000);
		
		int isopenActionthere = driver.findElements(By.xpath("//button[@id='open-btn']")).size();
		if(isopenActionthere>0) {
			openActionBtn.click();
		}
		else {
			System.out.println("Already the next action activity is opened for this topic");
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		}
		
		Thread.sleep(2000);
		
		int isActionEnabled = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'organizer actions active')]//span[text()= 'Actions']")).size();	
		if(isActionEnabled>0) {
			WebElement actionBtn = driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'organizer actions active')]//span[text()= 'Actions']"));
			JavascriptExecutor ab = (JavascriptExecutor) driver;
			ab.executeScript("arguments[0].click();", actionBtn);
			Thread.sleep(2000);
			int isactiontitle = driver.findElements(By.xpath("//h3[text()='actions: ']")).size();
			if(isactiontitle>0) {
				return true;
			}
			else {
				System.out.println("Action page is not displayed");
				return false;
			}
		}
		else {
			System.out.println("Action button is not clickable");
			return false;
		}
		
	}
	
	public boolean clickNextActionBasedOnTopic(String topic) throws Exception{
		//action.moveToElement(driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li//span[text()= 'Actions']"))).build().perform();
		
		Thread.sleep(2000);
		int isActionEnabled = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'organizer actions active')]//span[text()= 'Actions']")).size();	
		if(isActionEnabled>0) {
			WebElement actionBtn = driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'organizer actions active')]//span[text()= 'Actions']"));
			JavascriptExecutor ab = (JavascriptExecutor) driver;
			ab.executeScript("arguments[0].click();", actionBtn);
			Thread.sleep(2000);
			int isactiontitle = driver.findElements(By.xpath("//h3[text()='actions: ']")).size();
			if(isactiontitle>0) {
				return true;
			}
			else {
				System.out.println("Action page is not displayed");
				return false;
			}
		}
		else {
			System.out.println("Action button is not clickable");
			return false;
		}
	}
	
	public boolean participantclickNextActionBasedOnTopic(String topic) throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Home')]")));
				
		int isActionEnabled = driver.findElements(By.xpath("//li/h4[text()='"+topic+"']/following-sibling::ul[@class='activities']/li[@class='actions active']//span[text()= 'Actions']")).size();	
		if(isActionEnabled>0) {
			WebElement actionBtn = driver.findElement(By.xpath("//li/h4[text()='"+topic+"']/following-sibling::ul[@class='activities']/li[@class='actions active']//span[text()= 'Actions']"));
			JavascriptExecutor ab = (JavascriptExecutor) driver;
			ab.executeScript("arguments[0].click();", actionBtn);
			Thread.sleep(2000);
			int isactiontitle = driver.findElements(By.xpath("//h3[text()='actions: ']")).size();
			if(isactiontitle>0) {
				return true;
			}
			else {
				System.out.println("Action page is not displayed");
				return false;
			}
		}
		else {
			System.out.println("Action button is not clickable");
			return false;
		}
	}
	
	
	
	public boolean isListView() throws Exception{
		Thread.sleep(4000);
		int isList = driver.findElements(By.xpath("//div[@class='grid-layout list']")).size();
		if(isList>0) {
			System.out.println("ideas are in list view");
			return true;
		}
		
		else {
			System.out.println("ideas are not in list view");
			return false;
		}
		
	}
	
	public boolean clickTileNoAndCheck()throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
		Thread.sleep(1000);
		ideanumber.click();
		Thread.sleep(1000);
		int isComment = driver.findElements(By.id("idea_comments")).size();
		if(isComment>0) {
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			return true;
		}
		else {
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			return false;
		}
		
	}
	
	public boolean clickTileNameAndCheck()throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
		Thread.sleep(1000);
		ideaTitle.click();
		Thread.sleep(1000);
		int isComment = driver.findElements(By.id("idea_comments")).size();
		if(isComment>0) {
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			return true;
		}
		else {
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			return false;
		}
		
	}
	
	public boolean clickTilesCommentCountAndCheck()throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
		Thread.sleep(1000);
		ideacommentcount.click();
		Thread.sleep(1000);
		int isComment = driver.findElements(By.id("idea_comments")).size();
		if(isComment>0) {
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			return true;
		}
		else {
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			return false;
		}
		
	}
	
	
	
	public boolean checkAddActionButton() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
		addActionBtn.click();
		Thread.sleep(1000);
		int isDialogue = driver.findElements(By.xpath("//div[text()='Add Action'][@class ='dialogTitle']")).size();
		if(isDialogue>0) {
			System.out.println("Dialogue window is displayed");
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			return true;
		}
		else {
			System.out.println("Dialogue window is not displayed");
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			return false;
		}
	}
	
	public void putIamDone() throws Exception {

		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[@for='participant_done']")));
		System.out.println(participantDoneCheckbox.isSelected());
		if (participantDoneCheckbox.isSelected() == false) {
			participantDoneCheckbox.click();
			Thread.sleep(100);
			
		} else {
			participantDoneCheckbox.click();
			Thread.sleep(4000);
			participantDoneCheckbox.click();
			Thread.sleep(100);
			
		}
		
	}
	
	public String doneCountNow() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
		System.out.println(participantDoneCount.getText());
		return participantDoneCount.getText();
	}
	
	public Boolean checkActionDialogue(String countoftextbox) throws Exception{
		int intcountoftextbox = Integer.parseInt(countoftextbox);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
		addActionBtn.click();
		Thread.sleep(1000);
		int isDialogue = driver.findElements(By.xpath("//div[text()='Add Action'][@class ='dialogTitle']")).size();
		if(isDialogue>0) {
			System.out.println("Dialogue window is displayed");
			Thread.sleep(1000);
			int nooftextboxcount = addActionsTextFields.size();
			int isAddBtn = driver.findElements(By.xpath("//form[@class='add_action']/button[text()='Add Action']")).size();
			if(nooftextboxcount==intcountoftextbox && isAddBtn==1) {				
				System.out.println("All textboxes and the add action button are displaying");
				closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);			
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
				return true;
			}
			
			else {
				System.out.println("Textboxes are missing or add action button is not there");
				closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);			
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
				return false;
			}
		}
		else {
			System.out.println("Dialogue window is not displayed");
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			return false;
		}
	}
	
	public void selectDateAndTimeFromCal(String date, String time) throws Exception{
		
		String splittedDate[] = date.split("/");
		
		String year = splittedDate[0].substring(0, 4);
		int yearInInt = Integer.parseInt(year);
		System.out.println(yearInInt);
		
		String month = splittedDate[1].substring(0, 3);
		System.out.println(month);
		
		String day = splittedDate[2];
		int intDay = Integer.parseInt(day);
		
		String selectedyearArray[] = currentDate.split("_");
		String selectedyear = selectedyearArray[0].substring(0, 4);
		int selectedyearinint = Integer.parseInt(selectedyear);
		System.out.println(selectedyearinint);
		
		Thread.sleep(1000);
		duedateTextbox.click();
		Thread.sleep(1000);
		
		yearmonthheaderInCal.click();
		Thread.sleep(1000);
		 
		
		int x = selectedyearinint;
		
		if(selectedyearinint>yearInInt){
			int times = selectedyearinint-yearInInt;
			for(int i = 1; i<=times;i++) {
				driver.findElement(By.xpath("//table//thead/tr[1]/th[text()='"+x+"']/preceding-sibling::th[@class='prev']")).click();
				Thread.sleep(500);
				x--;
			}		
					
					
		}
		else if(selectedyearinint<yearInInt){
			int times = yearInInt-selectedyearinint;
			for(int i = 1; i<=times;i++) {
				driver.findElement(By.xpath("//table//thead/tr[1]/th[text()='"+x+"']/following-sibling::th[@class='next']")).click();
				Thread.sleep(500);
				x++;
			}
		}
		
		driver.findElement(By.xpath("//span[@class='month'][text()='"+month+"']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//tbody/tr/td[@class='day'][text()='"+intDay+"']")).click();
		Thread.sleep(3000);
		
		timeIcon.click();
		Thread.sleep(2000);
		
		String splittedTime[] = time.split(" ");
		String hoursToSelect = splittedTime[0].substring(0,2);
		int hoursToSelectinInt = Integer.parseInt(hoursToSelect);
		
		String minutesToSearch = splittedTime[1].substring(0,2);
		int minutesToSearchinInt = Integer.parseInt(minutesToSearch);
		
		String periodToSearch = splittedTime[2];
		
		int hourshighlighted = Integer.parseInt(hoursSelected.getText());
		Thread.sleep(200);
		int minuteshighlighted = Integer.parseInt(minuteSelected.getText());
		Thread.sleep(200);
		
		
		if(hourshighlighted>hoursToSelectinInt) {
			int downtimes = hourshighlighted - hoursToSelectinInt;
			for(int j=1;j<=downtimes;j++) {
				hrsDownIcon.click();
				Thread.sleep(500);
			}
		}
		
		else if(hourshighlighted<hoursToSelectinInt) {
			int uptimes = hoursToSelectinInt - hourshighlighted;
			for(int j=1;j<=uptimes;j++) {
				hrsUpIcon.click();
				Thread.sleep(500);
			}
		}
		
		Thread.sleep(1000);
		if(minuteshighlighted>minutesToSearchinInt) {
			int downmin = minuteshighlighted - minutesToSearchinInt;
			for(int k=1;k<=downmin;k++) {
				minuteDownIcon.click();
				Thread.sleep(500);
			}
		}
		
		else if(minuteshighlighted<minutesToSearchinInt) {
			int downmin = minutesToSearchinInt - minuteshighlighted;
			for(int k=1;k<=downmin;k++) {
				minuteUpIcon.click();
				Thread.sleep(500);
			}
		}
		
		Thread.sleep(1000);
		String periodhighlighted = ampmSelected.getText();
		
		Boolean equalString = periodToSearch.equals(periodhighlighted);
		System.out.println(equalString);
		if(equalString == false) {
			ampmSelected.click();
			Thread.sleep(1000);
		}
		
	}
	
	public Boolean addAction(String tileno, String action,String assignedto,String priority,String status,String duedate,String duetime,String complete) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
		int actualtile = driver.findElements(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']/ancestor::div[@class='ideaTxt']/following-sibling::div//button[text()='Add Action']")).size();
		if(actualtile==1) {
			driver.findElement(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']/ancestor::div[@class='ideaTxt']/following-sibling::div//button[text()='Add Action']")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Add Action'][@class ='dialogTitle']")));
			Thread.sleep(1000);
			
			actionTextbox.sendKeys(action);
			Thread.sleep(1000);
			assignedToTextbox.sendKeys(assignedto);
			Thread.sleep(1000);
			priorityTextbox.sendKeys(priority);
			Thread.sleep(1000);
			statusTextbox.sendKeys(status);
			Thread.sleep(1000);
			this.selectDateAndTimeFromCal(duedate, duetime);
			Thread.sleep(1000);
			
			completeTextbox.sendKeys(complete);
			Thread.sleep(1000);
			
			addActionButtonInForm.click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			Thread.sleep(1000);
			
			int isActionAdded = driver.findElements(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']/ancestor::div[@class='sticky']/following-sibling::div[@class='actions']//td[text()='"+action+"']")).size();
			if(isActionAdded>0) {
				System.out.println("Action added successfully");
				return true;
			}
			else {
				System.out.println("Action is not added");
				return false;
			}
			
		}
		else {
			System.out.println("Tile is not there with the specified tile number");
			return false;
		}
	}
	
	
	public boolean checkEditActionDialogue(String countOfTexboxes) throws Exception{
		int intcountoftextbox = Integer.parseInt(countOfTexboxes);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
		pencilIcon.click();
		Thread.sleep(2000);
		
		int isDialogueThere = driver.findElements(By.xpath("//div[@class='dialogTitle'][text()='Edit Action']")).size();
		if(isDialogueThere>0) {
			System.out.println("Edit dialogue window is there");
			int nooftextboxcount = addActionsTextFields.size();
			int isTickMarkThere = driver.findElements(By.id("dialog-close-btn")).size();
			int isDeleteMarkThere = driver.findElements(By.id("dialog-delete-btn")).size();
			if(nooftextboxcount == intcountoftextbox && isTickMarkThere==1 && isDeleteMarkThere==1) {
				System.out.println("Textboxes and the icons are displaying in the edit dialogue window");
				return true;
			}
			else {
				System.out.println("Textboxes or the delete icon are there in the Edit dialogue window");
				return false;
			}
		}
		
		else {
			System.out.println("Edit dialogue window is not there");
			return false;
		}
		
	}
	
public void editDateAndTimeFromCal(String date, String time) throws Exception{
		
		String splittedDate[] = date.split("/");
		
		String year = splittedDate[0].substring(0, 4);
		int yearInInt = Integer.parseInt(year);
		System.out.println(yearInInt);
		
		String month = splittedDate[1].substring(0, 3);
		System.out.println(month);
		
		String day = splittedDate[2];
		int intDay = Integer.parseInt(day);
		
		Thread.sleep(1000);
		/*String datetoedit = duedateTextbox.getAttribute("value");
		System.out.println(datetoedit);*/
		//String checkempty = "x"+datetoedit+"x";
		int selectedyearinint;
		
		//if(checkempty.equals("xx")) {
			String selectedyearArray[] = currentDate.split("_");
			String selectedyear = selectedyearArray[0].substring(0, 4);
			selectedyearinint = Integer.parseInt(selectedyear);
		/*}
		else {
		
		
		String datetoeditarray[] = datetoedit.split("/");
		String selectedyear = datetoeditarray[2].substring(0,4);
		selectedyearinint = Integer.parseInt(selectedyear);
		System.out.println(selectedyearinint);
		}*/
		
		
		
		
		Thread.sleep(1000);
		duedateTextbox.click();
		Thread.sleep(1000);
		
		yearmonthheaderInCal.click();
		Thread.sleep(1000);
		 
		
		int x = selectedyearinint;
		
		if(selectedyearinint>yearInInt){
			int times = selectedyearinint-yearInInt;
			for(int i = 1; i<=times;i++) {
				driver.findElement(By.xpath("//table//thead/tr[1]/th[text()='"+x+"']/preceding-sibling::th[@class='prev']")).click();
				Thread.sleep(500);
				x--;
			}		
					
					
		}
		else if(selectedyearinint<yearInInt){
			int times = yearInInt-selectedyearinint;
			for(int i = 1; i<=times;i++) {
				driver.findElement(By.xpath("//table//thead/tr[1]/th[text()='"+x+"']/following-sibling::th[@class='next']")).click();
				Thread.sleep(500);
				x++;
			}
		}
		
		driver.findElement(By.xpath("//span[@class='month'][text()='"+month+"']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//tbody/tr/td[@class='day'][text()='"+intDay+"']")).click();
		Thread.sleep(3000);
		
		timeIcon.click();
		Thread.sleep(2000);
		
		String splittedTime[] = time.split(" ");
		String hoursToSelect = splittedTime[0].substring(0,2);
		int hoursToSelectinInt = Integer.parseInt(hoursToSelect);
		
		String minutesToSearch = splittedTime[1].substring(0,2);
		int minutesToSearchinInt = Integer.parseInt(minutesToSearch);
		
		String periodToSearch = splittedTime[2];
		
		int hourshighlighted = Integer.parseInt(hoursSelected.getText());
		Thread.sleep(200);
		int minuteshighlighted = Integer.parseInt(minuteSelected.getText());
		Thread.sleep(200);
		
		
		if(hourshighlighted>hoursToSelectinInt) {
			int downtimes = hourshighlighted - hoursToSelectinInt;
			for(int j=1;j<=downtimes;j++) {
				hrsDownIcon.click();
				Thread.sleep(500);
			}
		}
		
		else if(hourshighlighted<hoursToSelectinInt) {
			int uptimes = hoursToSelectinInt - hourshighlighted;
			for(int j=1;j<=uptimes;j++) {
				hrsUpIcon.click();
				Thread.sleep(500);
			}
		}
		
		Thread.sleep(1000);
		if(minuteshighlighted>minutesToSearchinInt) {
			int downmin = minuteshighlighted - minutesToSearchinInt;
			for(int k=1;k<=downmin;k++) {
				minuteDownIcon.click();
				Thread.sleep(500);
			}
		}
		
		else if(minuteshighlighted<minutesToSearchinInt) {
			int downmin = minutesToSearchinInt - minuteshighlighted;
			for(int k=1;k<=downmin;k++) {
				minuteUpIcon.click();
				Thread.sleep(500);
			}
		}
		
		Thread.sleep(1000);
		String periodhighlighted = ampmSelected.getText();
		
		Boolean equalString = periodToSearch.equals(periodhighlighted);
		//System.out.println(equalString);
		if(equalString == false) {
			ampmSelected.click();
			Thread.sleep(1000);
		}
		
	}
	
	
	public Boolean editAction(String tileno, String actiontoedit,String actiontext,String assignedto,String priority,String status,String duedate,String duetime,String complete) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
		Thread.sleep(3000);
		int actualpencilicon = driver.findElements(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']/ancestor::div[@class='sticky']/following-sibling::div[@class='actions']//td[text()='"+actiontoedit+"']/following-sibling::td[@class='edit']/button")).size();
		
		if(actualpencilicon>0) {
			driver.findElement(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']/ancestor::div[@class='sticky']/following-sibling::div[@class='actions']//td[text()='"+actiontoedit+"']/following-sibling::td[@class='edit']/button")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Edit Action'][@class ='dialogTitle']")));
			Thread.sleep(1000);
			
			actionTextbox.clear();
			Thread.sleep(500);
			actionTextbox.sendKeys(actiontext);
			Thread.sleep(1000);
			
			assignedToTextbox.clear();
			Thread.sleep(500);
			assignedToTextbox.sendKeys(assignedto);
			Thread.sleep(1000);
			
			priorityTextbox.clear();
			Thread.sleep(500);
			priorityTextbox.sendKeys(priority);
			Thread.sleep(1000);
			
			statusTextbox.clear();
			Thread.sleep(500);
			statusTextbox.sendKeys(status);
			Thread.sleep(1000);
			
			this.editDateAndTimeFromCal(duedate, duetime);
			Thread.sleep(1000);
			
			
			completeTextbox.clear();
			Thread.sleep(500);
			completeTextbox.sendKeys(complete);
			Thread.sleep(1000);
			
			tickMarkOfActionSettings.click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			Thread.sleep(1000);
			
			int isActionEdited = driver.findElements(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']/ancestor::div[@class='sticky']/following-sibling::div[@class='actions']//td[text()='"+actiontext+"']")).size();
			if(isActionEdited>0) {
				System.out.println("Action edited successfully");
				return true;
			}
			else {
				System.out.println("Changes are not appearing in the action");
				return false;
			}
			
		}
		else {
			System.out.println("Tile is not there with the specified tile number or the user don't having the permission to edit this action");
			return false;
		}
	}
	
	public boolean isEditactionPresent(String tileno, String action) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
		Thread.sleep(1000);
		int actualpencilicon = driver.findElements(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']/ancestor::div[@class='sticky']/following-sibling::div[@class='actions']//td[text()='"+action+"']/following-sibling::td[@class='edit']/button")).size();
		
		if(actualpencilicon>0) {
			System.out.println("Edit action icon is displaying for this action");
			return true;
		}
		else {
			System.out.println("Edit action icon is not displaying for this action");
			return false;
		}
	}
	
	public boolean deleteAction(String tileno, String action) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
		Thread.sleep(1000);
		int actualpencilicon = driver.findElements(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']/ancestor::div[@class='sticky']/following-sibling::div[@class='actions']//td[text()='"+action+"']/following-sibling::td[@class='edit']/button")).size();
		
		if(actualpencilicon>0) {
			driver.findElement(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']/ancestor::div[@class='sticky']/following-sibling::div[@class='actions']//td[text()='"+action+"']/following-sibling::td[@class='edit']/button")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Edit Action'][@class ='dialogTitle']")));
			Thread.sleep(1000);
			
			deleteActionIcon.click();
			Thread.sleep(1500);
			confirmDeleteAction.click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
			Thread.sleep(500);
			
			int deletedaction = driver.findElements(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']/ancestor::div[@class='sticky']/following-sibling::div[@class='actions']//td[text()='"+action+"']")).size();
			if(deletedaction==actualpencilicon-1) {
				System.out.println("Action deleted successfully");
				return true;
			}
			else {
				System.out.println("Deleted action is not disappearing from the idea");
				return false;
			}
		}
		else {
			System.out.println("This user don't have permission to delete or there is no tile or action with this name");
			return false;
		}
	}
	
	public boolean editActionDescription(String tileno,String description) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
		Thread.sleep(1000);
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		int isactiontilethere = driver.findElements(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")).size();
		if(isactiontilethere==1) {
			driver.findElement(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")).click();
			Thread.sleep(1000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idea_comments")));
			
			int isPlusThere = driver.findElements(By.xpath("//img[@src='images/icons/greyPlus.svg']")).size();
			
			if(isPlusThere>0) {
				descPlusIcon.click();
				Thread.sleep(1000);
			}
			
			int isEditableDesc = driver.findElements(By.xpath("//div[@id='desc-edit']//div[@role='textbox']")).size();
			if(isEditableDesc==1) {
				descTextbox.click();
				descTextbox.sendKeys(Keys.CONTROL + "a");
				descTextbox.sendKeys(Keys.DELETE);
				Thread.sleep(500);
				descTextbox.sendKeys(description);
				Thread.sleep(500);				
				
				tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")));
				driver.findElement(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")).click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idea_comments")));
				String desc = descTextboxText.getText();
				
				if(desc.equals(description)) {
					System.out.println("Action description edited successfully");
					tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
					return true;
				}
				else {
					System.out.println("changes are not appearing in the action description");
					tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
					return false;
				}
			}
			else {
				System.out.println("User don't have permission to edit the description of this action.");
				tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
				return false;
			}
					
		}
		else {
			System.out.println("There is no action tile with this tile number");
			return false;
		}
	}
	
	
	
	
	public boolean switchToActivity() throws Exception{
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(500);
		
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		//activitySettingsMenu.click();
		Thread.sleep(2000);
		
		List<WebElement> activitylist = driver.findElements(By.xpath("//div[@id='sub-menu']//ul[@id='stepMap']/li/h2"));
		int sizeOfVisibleActivity = activitylist.size();
		String actualtext;
		int dialoguecount=0;
		for(int count = 0;count<sizeOfVisibleActivity;count++) {
			actualtext = activitylist.get(count).getText().substring(0,3);
			activitylist.get(count).click();
			Thread.sleep(1500);
			//div[@class='dialogTitle'][contains(text(),'Noo')]
			int isDialogue = driver.findElements(By.xpath("//div[@class='dialogTitle'][contains(text(),'"+actualtext+"')]")).size();
			
			if(isDialogue>0) {
				dialoguecount++;
			}
			
			tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='idea']")));
		}
		
		if(dialoguecount==sizeOfVisibleActivity) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Boolean hideAllActivitiesExceptAction(String topic) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='"+topic+"']")));
		
		
		int isNoodleVisible = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'visible')]//button[text()='Noodle Settings']/preceding-sibling::label")).size();
		
		if(isNoodleVisible>0) {
			driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'visible')]//button[text()='Noodle Settings']/preceding-sibling::label")).click();
			Thread.sleep(1000);
		}
		
		int isTagVisible = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'visible')]//button[text()='Tag Settings']/preceding-sibling::label")).size();
		
		if(isTagVisible>0) {
			driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'visible')]//button[text()='Tag Settings']/preceding-sibling::label")).click();
			Thread.sleep(1000);
		}
		
		int isCombineVisible = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'visible')]//button[text()='Combine Settings']/preceding-sibling::label")).size();
		
		if(isCombineVisible>0) {
			driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'visible')]//button[text()='Combine Settings']/preceding-sibling::label")).click();
			Thread.sleep(1000);
		}
		
		int isVoteVisible = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'visible')]//button[text()='Vote Settings']/preceding-sibling::label")).size();
		
		if(isVoteVisible>0) {
			driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'visible')]//button[text()='Vote Settings']/preceding-sibling::label")).click();
			Thread.sleep(1000);
		}
		
		int isRateVisible = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'visible')]//button[text()='Rate Settings']/preceding-sibling::label")).size();
		
		if(isRateVisible>0) {
			driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'visible')]//button[text()='Rate Settings']/preceding-sibling::label")).click();
			Thread.sleep(1000);
		}
		
		int isPriorityVisible = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'visible')]//button[text()='Prioritize Settings']/preceding-sibling::label")).size();
		
		if(isPriorityVisible>0) {
			driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'visible')]//button[text()='Prioritize Settings']/preceding-sibling::label")).click();
			Thread.sleep(1000);
		}
		
		Thread.sleep(1000);
		int isVisible = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'visible')]//button[contains(text(),' Settings')]/preceding-sibling::label")).size();
		if(isVisible==1) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean checkHiddenActivities() throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(500);
		
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);		
		Thread.sleep(2000);
		
		int isactivitylocked = driver.findElements(By.xpath("//div[@id='sub-menu']//ul[@id='stepMap']/li[@class='step locked']/h2")).size();
		
		if(isactivitylocked==6) {
			return true;
		}
		
		else {
			return false;
		}
		
	}
	
	public Boolean enableAllActivitiesExceptAction(String topic) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='"+topic+"']")));
		
		
		int isNoodleVisible = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'disabled')]//button[text()='Noodle Settings']/preceding-sibling::label")).size();
		
		if(isNoodleVisible>0) {
			driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'disabled')]//button[text()='Noodle Settings']/preceding-sibling::label")).click();
			Thread.sleep(1000);
		}
		
		int isTagVisible = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'disabled')]//button[text()='Tag Settings']/preceding-sibling::label")).size();
		
		if(isTagVisible>0) {
			driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'disabled')]//button[text()='Tag Settings']/preceding-sibling::label")).click();
			Thread.sleep(1000);
		}
		
		int isCombineVisible = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'disabled')]//button[text()='Combine Settings']/preceding-sibling::label")).size();
		
		if(isCombineVisible>0) {
			driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'disabled')]//button[text()='Combine Settings']/preceding-sibling::label")).click();
			Thread.sleep(1000);
		}
		
		int isVoteVisible = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'disabled')]//button[text()='Vote Settings']/preceding-sibling::label")).size();
		
		if(isVoteVisible>0) {
			driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'disabled')]//button[text()='Vote Settings']/preceding-sibling::label")).click();
			Thread.sleep(1000);
		}
		
		int isRateVisible = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'disabled')]//button[text()='Rate Settings']/preceding-sibling::label")).size();
		
		if(isRateVisible>0) {
			driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'disabled')]//button[text()='Rate Settings']/preceding-sibling::label")).click();
			Thread.sleep(1000);
		}
		
		int isPriorityVisible = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'disabled')]//button[text()='Prioritize Settings']/preceding-sibling::label")).size();
		
		if(isPriorityVisible>0) {
			driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'disabled')]//button[text()='Prioritize Settings']/preceding-sibling::label")).click();
			Thread.sleep(1000);
		}
		
		Thread.sleep(1000);
		int isVisible = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'disabled')]//button[contains(text(),' Settings')]/preceding-sibling::label")).size();
		if(isVisible==0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean checkVisibleActivities() throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(500);
		
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);		
		Thread.sleep(2000);
		
		int isactivitylocked = driver.findElements(By.xpath("//div[@id='sub-menu']//ul[@id='stepMap']/li[@class='step ']/h2")).size();
		
		if(isactivitylocked==7) {
			return true;
		}
		
		else {
			return false;
		}
		
	}
	
	public boolean checkShowStatus(String topic) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		int count = 0;
		
		List<String> activityList = new ArrayList<String>();
		activityList.add("Noodle Settings");
		activityList.add("Tag Settings");
		activityList.add("Combine Settings");
		activityList.add("Vote Settings");
		activityList.add("Rate Settings");
		activityList.add("Prioritize Settings");
		activityList.add("Actions Settings");
		
		String menuText;
		for(int loopcount=0;loopcount <activityList.size();loopcount++) {
			menuText = activityList.get(loopcount);
			int isSettingsThere = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'visible')]//button[text()='"+menuText+"']")).size();
			if(isSettingsThere>0) {
				
				driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'visible')]//button[text()='"+menuText+"']")).click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle']")));
				
				int isShowSelected = driver.findElements(By.xpath("//label[@class='selected'][contains(@for,'step_rdo')][text()='Show']")).size();
				if(isShowSelected>0) {
					count++;
					tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='"+topic+"']")));
				}
				else {
					System.out.println("Show toggle is not enabled");
				}
			}
			
			else {
				System.out.println("Activity is not enabled for "+menuText);
			}
		}
		
		
		
		if(count == 7) {
			System.out.println("Show icon is enabled for all the activities");
			return true;
		}
		
		else {
			System.out.println("Show icon is not enabled for all the activities");
			return false;
		}
		
		
		
	}


	public boolean checkHideStatus(String topic) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		int count = 0;
	
		List<String> activityList = new ArrayList<String>();
		activityList.add("Noodle Settings");
		activityList.add("Tag Settings");
		activityList.add("Combine Settings");
		activityList.add("Vote Settings");
		activityList.add("Rate Settings");
		activityList.add("Prioritize Settings");
		
	
		String menuText;
		for(int loopcount=0;loopcount <activityList.size();loopcount++) {
			menuText = activityList.get(loopcount);
			int isSettingsThere = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'disabled')]//button[text()='"+menuText+"']")).size();
			if(isSettingsThere>0) {
			
				driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'disabled')]//button[text()='"+menuText+"']")).click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle']")));
			
				int isHideSelected = driver.findElements(By.xpath("//label[@class='selected'][contains(@for,'step_rdo')][text()='Hide']")).size();
				if(isHideSelected>0) {
					count++;
					tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='"+topic+"']")));
				}
				else {
					System.out.println("Hide toggle is not enabled");
				}
			}
		
			else {
				System.out.println("Activity is not disabled for "+menuText);
			}
		}
	
	
	
		if(count == 6) {
			System.out.println("Hide icon is enabled for all the activities");
			return true;
		}
	
		else {
			System.out.println("Hide icon is not enabled for all the activities");
			return false;
		}
	
	
	
	}
	
	public boolean checkExportTilesDialogue() throws Exception {
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		JavascriptExecutor fm = (JavascriptExecutor) driver;
		fm.executeScript("arguments[0].click();", filterMenu);
		//filterMenu.click();
		Thread.sleep(1000);
		
		exportTileButton.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='export-tiles']")));
		
		
		
		int isSelectDSThere = driver.findElements(By.xpath("//select[@id='decision_space_chooser']")).size();
		int isExportButtonThere = driver.findElements(By.xpath("//button[@id='export_btn']")).size();
		int isCloseDialogeButtonThere = driver.findElements(By.xpath("//div[@id='dialog-close-btn']")).size();
		
		if(isSelectDSThere>0 && isExportButtonThere>0 && isCloseDialogeButtonThere>0) {
			tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			Thread.sleep(1000);
			return true;
		}
		else {
			tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			Thread.sleep(1000);
			return false;
		}
		
	}
	
	public boolean addANewTopicToExport(String dsname,String newtopic) throws Exception {
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		JavascriptExecutor fm = (JavascriptExecutor) driver;
		fm.executeScript("arguments[0].click();", filterMenu);
		//filterMenu.click();
		Thread.sleep(1000);
		
		exportTileButton.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='export-tiles']")));
		
		Select select = new Select(selectDSDropdownbox);
		select.selectByVisibleText(dsname);
		Thread.sleep(1500);
		int isAddANewTopicThere = driver.findElements(By.id("reveal_add")).size();
		if(isAddANewTopicThere>0) {
			System.out.println("Add a new topic button appeared immediately");
			addNewTopicButton.click();
			Thread.sleep(1000);
			
			if(driver.findElements(By.xpath("//input[@placeholder='Add a new topic']")).size()>0) {
				System.out.println("Add a new topic textbox appeared");
				addNewTopicTextBox.sendKeys(newtopic);
				addTopicBlueButton.click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//select[@id='question_chooser']")));
				
				int isAddedTopicThere = driver.findElements(By.xpath("//select[@id='question_chooser']/option[text()='"+newtopic+"']")).size();
				
				if(isAddedTopicThere>0) {
					System.out.println("New topic added successfully and appeared in the topic options");
					tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
					return true;
				}
				else {
					System.out.println("New topic is not appeared in the topic dropdown options.");
					tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
					return false;
				}
			}
			else {
				System.out.println("Add a new topic textbox is not appeared");
				tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				return false;
			}
			
		}
		else {
			System.out.println("Add a new topic button is not appeared");
			tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			return false;
		}
	}
	
	public boolean exportTilesToNewTopic(String dsname,String newtopic) throws Exception {
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		JavascriptExecutor fm = (JavascriptExecutor) driver;
		fm.executeScript("arguments[0].click();", filterMenu);
		//filterMenu.click();
		Thread.sleep(1000);
		
		exportTileButton.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='export-tiles']")));
		
		Select select = new Select(selectDSDropdownbox);
		select.selectByVisibleText(dsname);
		Thread.sleep(1500);
		int isAddANewTopicThere = driver.findElements(By.id("reveal_add")).size();
		if(isAddANewTopicThere>0) {
			System.out.println("Add a new topic button appeared immediately");
			addNewTopicButton.click();
			Thread.sleep(1000);
			
			if(driver.findElements(By.xpath("//input[@placeholder='Add a new topic']")).size()>0) {
				System.out.println("Add a new topic textbox appeared");
				addNewTopicTextBox.sendKeys(newtopic);
				addTopicBlueButton.click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//select[@id='question_chooser']")));
				
				int isAddedTopicThere = driver.findElements(By.xpath("//select[@id='question_chooser']/option[text()='"+newtopic+"']")).size();
				
				if(isAddedTopicThere>0) {
					System.out.println("New topic added successfully and appeared in the topic options");
					yesTagButton.click();
					exportButton.click();
					driver.navigate().refresh();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
					return true;
				}
				else {
					System.out.println("New topic is not appeared in the topic dropdown options.");
					tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
					return false;
				}
			}
			else {
				System.out.println("Add a new topic textbox is not appeared");
				tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				return false;
			}
			
		}
		else {
			System.out.println("Add a new topic button is not appeared");
			tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			return false;
		}
	}
	
	public boolean checkExportedTileNames(String domainspace, String topic) throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		
		List<WebElement> tileList = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p"));
		int sizeoftilelist = tileList.size();
		
		List<String> oldtopictilenames = new ArrayList<String>();
		for(WebElement tiletext : tileList) {
			oldtopictilenames.add(tiletext.getText());
		}
				
		JavascriptExecutor dsmenu = (JavascriptExecutor) driver;
		dsmenu.executeScript("arguments[0].click();", alldsmenu);
		
		
		this.clickSpace(domainspace);
		NoodleActivity noodle = new NoodleActivity();
		noodle.clickNoodleBasedOnTopic(topic);
		
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
		Thread.sleep(2000);
		List<WebElement> tilelistofnewtopic = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p"));
		int sizeoftilelistofnewtopic = tilelistofnewtopic.size();
		int count = 0;
		String oldtopictilename;
		String newtopictilename;
		for(int x = 0;x<sizeoftilelist;x++) {
			
			for(int y=0; y<sizeoftilelistofnewtopic;y++) {
				newtopictilename = tilelistofnewtopic.get(y).getText();
				oldtopictilename = oldtopictilenames.get(x);
				if(newtopictilename.equals(oldtopictilename)) {
					count++;
					break;
				}
			}
		}
		
		if(count==sizeoftilelist) {
			System.out.println("Tiles which are there in the exported topic are there in the new topic");
			return true;
		}
		else {
			System.out.println("Tiles which are there in the exported topic are not there in the new topic");
			return false;
		}
		
	}
	
	public boolean checkExportedTileComments(String domainspace, String topic) throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		
		List<WebElement> tileList = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p"));
		int sizeoftilelist = tileList.size();
		
		List<String> oldtopictilenames = new ArrayList<String>();
		for(WebElement tiletext : tileList) {
			oldtopictilenames.add(tiletext.getText());
		}
		
		List<WebElement> commentnumbers = driver.findElements(By.xpath("//span[@class='title']/p/ancestor::div[@class='ideaTxt']/following-sibling::div[@class='comment_sliders']/div[1]"));
		
		List<String> oldtopiccommentnumbers = new ArrayList<String>();
		for(WebElement cn : commentnumbers) {
			oldtopiccommentnumbers.add(cn.getText());
		}
		
				
		JavascriptExecutor dsmenu = (JavascriptExecutor) driver;
		dsmenu.executeScript("arguments[0].click();", alldsmenu);
		
		
		this.clickSpace(domainspace);
		NoodleActivity noodle = new NoodleActivity();
		noodle.clickNoodleBasedOnTopic(topic);
		
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
		Thread.sleep(2000);
		
		//int tilecountofnewtopic = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']")).size();
		int isPresent;
		int count = 0;
		for(int u=0;u<sizeoftilelist;u++) {
			
				isPresent = driver.findElements(By.xpath("//span[@class='title']/p[text()='"+oldtopictilenames.get(u)+"']/ancestor::div[@class='ideaTxt']/following-sibling::div[@class='comment_sliders']/div[1][text()='"+oldtopiccommentnumbers.get(u)+"']")).size();
				if(isPresent>0) {
					count++;
				}
			
		}
		
		if(count==sizeoftilelist) {
			System.out.println("Tiles which are there in the exported topic are there in the new topic");
			return true;
		}
		else {
			System.out.println("Tiles which are there in the exported topic are not there in the new topic");
			return false;
		}
		
	}
	
	
	
	public boolean checkCommentsOfExportedTiles(String domainspace,String topic,String exportedds, String exportedtopic) throws Exception{
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		
		List<WebElement> tileList = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p"));
		int sizeoftilelist = tileList.size();
		
		List<String> oldtopictilenames = new ArrayList<String>();
		for(WebElement tiletext : tileList) {
			oldtopictilenames.add(tiletext.getText());
		}
		
		List<WebElement>  listofcomments;
		int verifiedtilecount = 0;
		List<String>  listofcommentstext = new ArrayList<String>();
		for(int b =0 ; b<sizeoftilelist; b++) {
			tileList = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p"));
			tileList.get(b).click();
			Thread.sleep(1000);
			
			listofcomments =  driver.findElements(By.xpath("//div[@class='comment-row top']/div[@class='comment-entry']//span[@data-text='true']"));
			System.out.println(listofcomments.size());
			if(listofcomments.size()>0) {
				listofcommentstext.clear();
				for(WebElement el : listofcomments) {
					listofcommentstext.add(el.getText());
				}
			
				Thread.sleep(1000);
				tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			
				JavascriptExecutor dsmenu = (JavascriptExecutor) driver;
				dsmenu.executeScript("arguments[0].click();", alldsmenu);
			
				this.clickSpace(domainspace);
				NoodleActivity noodle = new NoodleActivity();
				noodle.clickNoodleBasedOnTopic(topic);
			
			
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
				Thread.sleep(2000);
			
				List<WebElement> searchedtileinnewtopic = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p[text()='"+oldtopictilenames.get(b)+"']"));
				List<WebElement> newtopiccomments;
				for(int searchtile = 0; searchtile<searchedtileinnewtopic.size();searchtile++) {
					searchedtileinnewtopic = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p[text()='"+oldtopictilenames.get(b)+"']"));
					searchedtileinnewtopic.get(searchtile).click();
					Thread.sleep(2000);
					int count = 0;
					newtopiccomments = driver.findElements(By.xpath("//div[@class='comment-row top']/div[@class='comment-entry']//span[@data-text='true']"));
					if(newtopiccomments.size()>0) {
						for(String d : listofcommentstext ) {
							for(WebElement e : newtopiccomments) {
								if(d.equals(e.getText())) {
									count++;
									break;
								}
							}
						}
						System.out.println("count"+count);
					
						if(count == listofcommentstext.size()) {
							System.out.println("The comments of "+searchedtileinnewtopic.get(searchtile).getText()+" preserved in the new topic too");
							verifiedtilecount++;
							System.out.println("verifiedtilecount: "+verifiedtilecount);
							break;
						}
					}
					
					else {
						tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
						Thread.sleep(2000);
						System.out.println("Inside else block");
					}
					
				 
				}
			 
				tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
				Thread.sleep(2000);
			 
				JavascriptExecutor dsmenuforaction = (JavascriptExecutor) driver;
				dsmenuforaction.executeScript("arguments[0].click();", alldsmenu);
				this.clickSpace(exportedds);
				this.clickNextActionBasedOnTopic(exportedtopic);
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			
			}
			else {
				verifiedtilecount++;
				System.out.println("verifiedtilecount: "+verifiedtilecount);
				tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			}
		}
		System.out.println(verifiedtilecount);
		System.out.println(sizeoftilelist);
		if(verifiedtilecount == sizeoftilelist) {
			System.out.println("Comments of all tiles in the exported topic are preserved in the new topic too.");
			return true;
		}
		
		else {
			System.out.println("Comments of all tiles in the exported topic are not preserved in the new topic");
			return false;
		}
		
	}
	
	public boolean checkRepliesOfExportedTiles(String domainspace,String topic,String exportedds, String exportedtopic) throws Exception{
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		
		List<WebElement> tileList = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p"));
		int sizeoftilelist = tileList.size();
		
		List<String> oldtopictilenames = new ArrayList<String>();
		for(WebElement tiletext : tileList) {
			oldtopictilenames.add(tiletext.getText());
		}
		
		List<WebElement>  listofcomments;
		int verifiedtilecount = 0;
		List<String>  listofcommentstext = new ArrayList<String>();
		for(int b =0 ; b<sizeoftilelist; b++) {
			tileList = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p"));
			tileList.get(b).click();
			Thread.sleep(1000);
			
			listofcomments =  driver.findElements(By.xpath("//div[@class='comment-row top']/div[@class='comment-row']//span[@data-text='true']"));
			System.out.println(listofcomments.size());
			if(listofcomments.size()>0) {
				listofcommentstext.clear();
				for(WebElement el : listofcomments) {
					listofcommentstext.add(el.getText());
				}
			
				Thread.sleep(1000);
				tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			
				JavascriptExecutor dsmenu = (JavascriptExecutor) driver;
				dsmenu.executeScript("arguments[0].click();", alldsmenu);
				Thread.sleep(1000);
				this.clickSpace(domainspace);
				NoodleActivity noodle = new NoodleActivity();
				noodle.clickNoodleBasedOnTopic(topic);
			
			
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
				Thread.sleep(2000);
			
				List<WebElement> searchedtileinnewtopic = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p[text()='"+oldtopictilenames.get(b)+"']"));
				List<WebElement> newtopiccomments;
				for(int searchtile = 0; searchtile<searchedtileinnewtopic.size();searchtile++) {
					searchedtileinnewtopic = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p[text()='"+oldtopictilenames.get(b)+"']"));
					searchedtileinnewtopic.get(searchtile).click();
					Thread.sleep(2000);
					int count = 0;
					newtopiccomments = driver.findElements(By.xpath("//div[@class='comment-row top']/div[@class='comment-row']//span[@data-text='true']"));
					if(newtopiccomments.size()>0) {
						for(String d : listofcommentstext ) {
							for(WebElement e : newtopiccomments) {
								if(d.equals(e.getText())) {
									count++;
									break;
								}
							}
						}
						System.out.println("count"+count);
					
						if(count == listofcommentstext.size()) {
							System.out.println("The replies of "+searchedtileinnewtopic.get(searchtile).getText()+" preserved in the new topic too");
							verifiedtilecount++;
							System.out.println("verifiedtilecount: "+verifiedtilecount);
							break;
						}
					}
					
					else {
						tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
						Thread.sleep(2000);
						System.out.println("Inside else block");
					}
					
				 
				}
			 
				tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
				Thread.sleep(2000);
			 
				JavascriptExecutor dsmenuforaction = (JavascriptExecutor) driver;
				dsmenuforaction.executeScript("arguments[0].click();", alldsmenu);
				this.clickSpace(exportedds);
				this.clickNextActionBasedOnTopic(exportedtopic);
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			
			}
			else {
				verifiedtilecount++;
				System.out.println("verifiedtilecount: "+verifiedtilecount);
				tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			}
		}
		System.out.println(verifiedtilecount);
		System.out.println(sizeoftilelist);
		if(verifiedtilecount == sizeoftilelist) {
			System.out.println("Replies of all tiles in the exported topic are preserved in the new topic too.");
			return true;
		}
		
		else {
			System.out.println("Replies of all tiles in the exported topic are not preserved in the new topic");
			return false;
		}
		
	}
	
	public boolean checkDescriptionOfExportedTiles(String domainspace, String topic) throws Exception {
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		
		List<WebElement> tileList = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p"));
		int sizeoftilelist = tileList.size();
		
		List<String> oldtopictilenames = new ArrayList<String>();
		for(WebElement tiletext : tileList) {
			oldtopictilenames.add(tiletext.getText());
		}
		
		List<String> descriptionlist = new ArrayList<String>();
		for(int f = 0; f < sizeoftilelist; f++) {
			tileList = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p"));
			tileList.get(f).click();
			Thread.sleep(1000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idea_comments")));
			
			int isPlusThere = driver.findElements(By.xpath("//img[@src='images/icons/greyPlus.svg']")).size();
			
			if(isPlusThere>0) {
				descPlusIcon.click();
				Thread.sleep(1000);
				descriptionlist.add("No description");
				System.out.println("No desc in old tiles");
			}	
			else{
				String desc = descTextboxText.getText();
				System.out.println("desc in old tiles:  "+desc);
				descriptionlist.add(desc);
				Thread.sleep(500);
			}
				tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			
		}
		
		JavascriptExecutor dsmenu = (JavascriptExecutor) driver;
		dsmenu.executeScript("arguments[0].click();", alldsmenu);
		Thread.sleep(1000);
		this.clickSpace(domainspace);
		NoodleActivity noodle = new NoodleActivity();
		noodle.clickNoodleBasedOnTopic(topic);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
		Thread.sleep(2000);
		int count = 0;
		
		for(int n = 0; n<sizeoftilelist; n++ ) {
			
				System.out.println("Tile to check : "+oldtopictilenames.get(n));
				List<WebElement> newtilematched = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p[text()='"+oldtopictilenames.get(n)+"']"));
				System.out.println("matched tiles count : "+newtilematched.size());
				String newtiledesc;
				if(newtilematched.size()>0) {
					for(int o = 0; o<newtilematched.size(); o++) {
						newtilematched = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p[text()='"+oldtopictilenames.get(n)+"']"));
						newtilematched.get(o).click();
						Thread.sleep(500);
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idea_comments")));
						int isPlusThereInNewTile = driver.findElements(By.xpath("//img[@src='images/icons/greyPlus.svg']")).size();
						
						if(isPlusThereInNewTile>0) {
							descPlusIcon.click();
							Thread.sleep(1000);
							newtiledesc = "No description";
							System.out.println("No desc in new tile");
						}	
						else {
							newtiledesc = descTextboxText.getText();
							System.out.println("Desc in new tile: "+newtiledesc);
						}
						
						System.out.println("Actual searching description is : "+descriptionlist.get(n));
						if(newtiledesc.equals(descriptionlist.get(n))) {
							System.out.println("Desc matched with a new tile desc");
							count++;
							Thread.sleep(500);
							tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
							Thread.sleep(2000);
							break;
						}
						else {
							System.out.println("Desc doesn't matched with a new tile desc");
							Thread.sleep(500);
							tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
							Thread.sleep(2000);
						}
					}
				}
				else {
					System.out.println("There is no tile with the searched title");
				}
			
		}
		System.out.println("Final count:"+count);
		if(count == sizeoftilelist) {
			System.out.println("Description of all tiles of exported topic preserved in the old topic too.");
			return true;
		}
		else {
			System.out.println("Description of all tiles of exported topic not preserved in the old topic");
			return false;
		}		
		
	}
	
	public void enablefilevisibilityofNoodle()throws Exception {
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		noodleIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Noodle Settings']")));
		showFileButtonInActionDialogue.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
	}
	
	public boolean checkFilesInExportedTiles(String domainspacetoexport, String topictoexport,String domainspaceexported, String topicexported) throws Exception {
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		NoodleActivity noodle = new NoodleActivity();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));		
		List<WebElement> tileList = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p"));
		int sizeoftilelist = tileList.size();
		
		List<String> oldtopictilenames = new ArrayList<String>();
		for(WebElement tiletext : tileList) {
			oldtopictilenames.add(tiletext.getText());
			System.out.println("tile names: "+ tiletext.getText());
		}
		
		List<WebElement>  listoffiles;
		int verifiedtilecount = 0;
		List<String>  listoffilename = new ArrayList<String>();
		for(int b =0 ; b<sizeoftilelist; b++) {
			tileList = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p"));
			tileList.get(b).click();
			System.out.println("tile name clicked: "+ tileList.get(b).getText());
			Thread.sleep(1000);
			
			listoffiles =  driver.findElements(By.xpath("//div[@class='files']/div/div/a"));
			System.out.println("file size: "+listoffiles.size());
			if(listoffiles.size()>0) {
				listoffilename.clear();
				for(WebElement el : listoffiles) {
					listoffilename.add(el.getText());
					System.out.println("file name "+ el.getText());
				}
			
				Thread.sleep(1000);
				tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			
				JavascriptExecutor dsmenu = (JavascriptExecutor) driver;
				dsmenu.executeScript("arguments[0].click();", alldsmenu);
				Thread.sleep(2000);
			
				this.clickSpace(domainspacetoexport);
				
				noodle.clickNoodleBasedOnTopic(topictoexport);
				
				this.enablefilevisibilityofNoodle();
			
			
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
				Thread.sleep(2000);
			
				List<WebElement> searchedtileinnewtopic = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p[text()='"+oldtopictilenames.get(b)+"']"));
				List<WebElement> newtopicfiles;
				System.out.println("searched tile present count: "+ searchedtileinnewtopic.size());
				for(int searchtile = 0; searchtile<searchedtileinnewtopic.size();searchtile++) {
					searchedtileinnewtopic = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p[text()='"+oldtopictilenames.get(b)+"']"));
					searchedtileinnewtopic.get(searchtile).click();
					Thread.sleep(2000);
					int count = 0;
					
					newtopicfiles = driver.findElements(By.xpath("//div[@class='files']/div/div/a"));
					if(newtopicfiles.size()>0) {
						for(String d : listoffilename ) {
							for(WebElement e : newtopicfiles) {
								if(d.equals(e.getText())) {
									count++;
									break;
								}
							}
						}
						System.out.println("count of files matched: "+count);
					
						if(count == listoffilename.size()) {
							newtopicfiles.clear();
							System.out.println("The files of "+searchedtileinnewtopic.get(searchtile).getText()+" preserved in the new topic too");
							verifiedtilecount++;
							System.out.println("verifiedtilecount: "+verifiedtilecount);
							tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
							Thread.sleep(2000);
							break;
						}
						else {
							newtopicfiles.clear();
							System.out.println("files are not in this tile.");
							tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
							Thread.sleep(2000);
						}
					}
					
					else {
						//newtopicfiles.clear();
						tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
						Thread.sleep(2000);
						System.out.println("Inside else block");
					}
					
				 
				}
			 
				
			 
				JavascriptExecutor dsmenuforaction = (JavascriptExecutor) driver;
				dsmenuforaction.executeScript("arguments[0].click();", alldsmenu);
				this.clickSpace(domainspaceexported);
				this.clickNextActionBasedOnTopic(topicexported);
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			
			}
			else {
				verifiedtilecount++;
				System.out.println("verifiedtilecount: "+verifiedtilecount);
				tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			}
		}
		System.out.println(verifiedtilecount);
		System.out.println(sizeoftilelist);
		if(verifiedtilecount == sizeoftilelist) {
			System.out.println("Files of all tiles in the exported topic are preserved in the new topic too.");
			return true;
		}
		
		else {
			System.out.println("Files of all tiles in the exported topic are not preserved in the new topic");
			return false;
		}
		
	}
	
	public void enablefilevisibility() throws Exception {
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		showFileButtonInActionDialogue.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
	}
	
	public boolean enabletagforatopic(String topic) throws Exception{
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//div[@id='decision_space']/div[@class='header']/h2")));
		
		int isTagInactive = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'inactive')]//span[text()='Tag']")).size();
		int isTagActive = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'active')]//span[text()='Tag']")).size();
		if(isTagInactive>0) {
			Thread.sleep(500);
			driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li//button[contains(text(), 'Tag Settings')]")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Tag Settings']")));
			
			
			int isReopenTagThere = driver.findElements(By.xpath("//button[text()='Open Tagging']")).size();
			if(isReopenTagThere>0) {
				openTagBtn.click();
				Thread.sleep(1000);
				//confirmReopenBtn.click();
				wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//div[@id='decision_space']/div[@class='header']/h2")));
				
				Thread.sleep(1000);
				
				int isNowTagActive = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'active')]//span[text()='Tag']")).size();
				if(isNowTagActive>0) {
					
					System.out.println("Tag activity is enabled for this topic");
					return true;
				}
				else {
					System.out.println("Tag activity is not enabled for this topic");
					return false;
				}
			}
			else {
				System.out.println("There is no reopen tagging button");
				return false;
			}
		}
		
		else if(isTagActive>0) {
			System.out.println("Tag activity is already enabled for this topic");
			return true;
		}
		else {
			System.out.println("The topic is not present in the domain space");
			return false;
		}
	}
	
	public boolean checkTagsInExportedTopics(String domainspacetoexport, String topictoscript, String olddomainspace, String oldtopic) throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		
		JavascriptExecutor fm = (JavascriptExecutor) driver;
		fm.executeScript("arguments[0].click();", filterMenu);
		Thread.sleep(1500);
		
		showTagCheckbox.click();
		Thread.sleep(1500);
		
		int tagCount = driver.findElements(By.xpath("//span[@class='title']/p/ancestor::div[@class='ideaTxt']/following-sibling::div//div[@class='tag-group']//span")).size();
		if(tagCount>0) {
			List<WebElement> tileList = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p"));
			int sizeoftilelist = tileList.size();
			
			List<String> oldtopictilenames = new ArrayList<String>();
			for(WebElement tiletext : tileList) {
				oldtopictilenames.add(tiletext.getText());
				System.out.println("Old tile names: "+tiletext.getText());
			}
			List<String> tagtitlenames = new ArrayList<String>();
			List<String> tagnames = new ArrayList<String>();
			for(int xx = 0; xx<sizeoftilelist; xx++) {
				int isTileThere = driver.findElements(By.xpath("//span[@class='title']/p[text()='"+oldtopictilenames.get(xx)+"']/ancestor::div[@class='ideaTxt']/following-sibling::div//div[@class='tag-group']//span")).size();
				
				if(isTileThere>0) {
					tagtitlenames.add(oldtopictilenames.get(xx));
					String tagtext = driver.findElement(By.xpath("//span[@class='title']/p[text()='"+oldtopictilenames.get(xx)+"']/ancestor::div[@class='ideaTxt']/following-sibling::div//div[@class='tag-group']//span")).getText();
					tagnames.add(tagtext);
					System.out.println("Tile's tag name: "+tagtext);
				}
			}
			
			Thread.sleep(1000);
			JavascriptExecutor dsmenu = (JavascriptExecutor) driver;
			dsmenu.executeScript("arguments[0].click();", alldsmenu);
			Thread.sleep(1000);
		
			this.clickSpace(domainspacetoexport);
			System.out.println("After next space");
			this.enabletagforatopic(topictoscript);
			System.out.println("After next topic");
			driver.findElement(By.xpath("//input[@value='"+topictoscript+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'active')]//span[text()='Tag']")).click();
			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
			
			Thread.sleep(2000);
			
			List<WebElement> newtileList = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p"));
			int newsizeoftilelist = newtileList.size();
			if(sizeoftilelist<=newsizeoftilelist) {
				int presentcount = 0;
				for(int ii = 0; ii<tagtitlenames.size();ii++) {
					int isNewTileThere = driver.findElements(By.xpath("//span[@class='title']/p[text()='"+tagtitlenames.get(ii)+"']/ancestor::div[@class='ideaTxt']/following-sibling::div//div[@class='tag-group']//span[text()='"+tagnames.get(ii)+"']")).size();			
					if(isNewTileThere>0) {
						presentcount++;
					}
				}
				
				if(presentcount== tagtitlenames.size()) {
					System.out.println("Tags of all tiles in the exported topic are preserved in the new topic too.");
					return true;
				}
				else {
					System.out.println("Tags of all tiles in the exported topic are not preserved in the new topic.");
					return false;
				}
			}
			else {
				System.out.println("All ideas are not preserved in the exported topic.");
				return false;
			}
			
		}
		else {
			System.out.println("There is no tag added for this topic");
			return true;
		}
		
	}
	
	//Action filters..............................................................................................................................
	
	public boolean checkShowDescription() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));		
		JavascriptExecutor fm = (JavascriptExecutor) driver;
		fm.executeScript("arguments[0].click();", filterMenu);
		Thread.sleep(1500);
		int isDescThere = driver.findElements(By.xpath("//div[@class='description-container']")).size();
		if(isDescThere>0) {
			showDescriptionCheckbox.click();
			Thread.sleep(2000);
			int isDescNotThere = driver.findElements(By.xpath("//div[@class='description-container']")).size();
			if(isDescNotThere==0) {
				System.out.println("Description of all the tiles disappeared");
				Thread.sleep(500);
				showDescriptionCheckbox.click();
				int isDescAgainThere = driver.findElements(By.xpath("//div[@class='description-container']")).size();
				if(isDescAgainThere==isDescThere) {
					System.out.println("Description of all the tiles appeared again");
					return true;
				}
				else {
					System.out.println("Description of all tiles are not appeared again");
					return false;
				}
				
			}
			else {
				System.out.println("Description of ideas are still displaying.");
				return false;
			}
		}
		else {
			System.out.println("There is no tile contains description");
			return true;
		}
	}
	
	public boolean checkShowTag() throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));		
		JavascriptExecutor fm = (JavascriptExecutor) driver;
		fm.executeScript("arguments[0].click();", filterMenu);
		Thread.sleep(1500);
		
		int tagNotThereCount = driver.findElements(By.xpath("//span[@class='title']/p/ancestor::div[@class='ideaTxt']/following-sibling::div//div[@class='tag-group']")).size();
		if(tagNotThereCount==0) {
			showTagCheckbox.click();
			Thread.sleep(1500);
			int tagThereCount = driver.findElements(By.xpath("//span[@class='title']/p/ancestor::div[@class='ideaTxt']/following-sibling::div//div[@class='tag-group']")).size();
			if(tagThereCount>0) {
				System.out.println("Tags are appeared on the tiles");
				Thread.sleep(500);
				showTagCheckbox.click();
				Thread.sleep(1500);
				int tagNotThereAgainCount = driver.findElements(By.xpath("//span[@class='title']/p/ancestor::div[@class='ideaTxt']/following-sibling::div//div[@class='tag-group']")).size();
				if(tagNotThereAgainCount==0) {
					System.out.println("Tags disappeared again immediately from the tiles");
					return true;
				}
				else {
					System.out.println("Tags of the ideas are not hidden after unchecking the show tag checkbox.");
					return false;
				}
				
			}
			else {
				System.out.println("Tags of the ideas are not appeared while having checked show tag checkbox.");
				return false;
			}
		}
		
		else {
			System.out.println("Tags of the ideas are not hidden while having unchecked show tag checkbox.");
			return false;
		}
		
		
		
	}
	
	public boolean checkTileContributor(String owntileno, String alltileno) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		allTileVisibilityButtonInActionDialogue.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		
		JavascriptExecutor fm = (JavascriptExecutor) driver;
		fm.executeScript("arguments[0].click();", filterMenu);
		Thread.sleep(1500);
		allTileContributorBtn.click();
		Thread.sleep(1000);
		int owntileThere = driver.findElements(By.xpath("//span[@class='ideaNumber'][text()='"+owntileno+"']")).size();
		int alltileThere = driver.findElements(By.xpath("//span[@class='ideaNumber'][text()='"+alltileno+"']")).size();
		
		if(owntileThere==1 && alltileThere==1) {
			Thread.sleep(500);
			myTileContributorBtn.click();
			Thread.sleep(1500);
			int owntileThereStill = driver.findElements(By.xpath("//span[@class='ideaNumber'][text()='"+owntileno+"']")).size();
			int alltileNotThere = driver.findElements(By.xpath("//span[@class='ideaNumber'][text()='"+alltileno+"']")).size();
			
			if(owntileThereStill==1 && alltileNotThere==0) {
				System.out.println("Tiles which were created by this particular user alone displayed.");
				return true;
			}
			else {
				System.out.println("Your test case failed because of any one following reasons. /n 1.own tile is not displaying (or) /n 2.the other's tile is displaying");
				return false;
			}
			
		}
		else {
			System.out.println("All tiles are not displaying");
			return false;
		}
		
	}
	
	public void clickFilterIcon() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));		
		JavascriptExecutor fm = (JavascriptExecutor) driver;
		fm.executeScript("arguments[0].click();", filterMenu);
		Thread.sleep(1500);
	}
	
	public boolean viewTagVice() throws Exception {
		this.clickFilterIcon();
		showTagCheckbox.click();
		Thread.sleep(1000);
		
		int tagcount = 0;
		int alltilecount = 0;
		int newsizeoftilelist = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p")).size();
		
		int taggroupcount = driver.findElements(By.xpath("//ul//label[@class='tag_idea']/span[@class='count']")).size();
		List<WebElement> taglist;
		if(taggroupcount>0) {
		String taggedtilecount;
		for(int kk = 0; kk<taggroupcount; kk++) {
			taglist = driver.findElements(By.xpath("//ul//label[@class='tag_idea']/span[@class='count']"));
			taggedtilecount=taglist.get(kk).getText();
			int taggedtilecountinint = Integer.parseInt(taggedtilecount);
			
			taglist.get(kk).click();
			Thread.sleep(1500);
			
			int newsizeoftagtilelist = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p")).size();
			if(newsizeoftagtilelist==taggedtilecountinint) {
				tagcount++;
			}
			taglist.get(kk).click();
			Thread.sleep(1500);
			int newsizeofentirelist = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']/div[@class='sticky']//span[@class='title']/p")).size();
			if(newsizeofentirelist==newsizeoftilelist) {
				alltilecount++;
			}
		}
		
		if(tagcount == taggroupcount && alltilecount == taggroupcount) {
			System.out.println("User is able to see the tiles based on the tags");
			return true;
		}
		else {
			System.out.println("User is unable to see the tiles based on the tags");
			return false;
		}
		}
		else {
			System.out.println("There is no tag added for this topic");
			return true;
		}
	}
	
	public boolean checkfirstTagGroupMenu() throws Exception{
		this.clickFilterIcon();
		showTagCheckbox.click();
		Thread.sleep(1500);
		int tilecontainstag = 0;
		
		int taggedtilescount = driver.findElements(By.xpath("//div[@class='tag-group']//span")).size();	
		onTagFirstToggle.click();
		Thread.sleep(2000);
		int tiles;
		for(int mm =1; mm<=taggedtilescount;mm++) {
			tiles = driver.findElements(By.xpath("//div[@id='ideas']/div[@class='idea']["+mm+"]//div[@class='tag-group']//span")).size();
			if(tiles>0) {
				tilecontainstag++;
			}
		}
		
		if(tilecontainstag==taggedtilescount) {
			System.out.println("All tagged tiles are displaying first");
			return true;
		}
		else {
			System.out.println("Tagged tiles are not displaying first");
			return false;
		}
		
		
		}
	
	
	//Action settings ..................................................................................................................................
	
	
	public void setalltileVisibilitySettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));	
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		allTileVisibilityButtonInActionDialogue.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
	}
	
	public void setownertileVisibilitySettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));	
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		ownerTileVisibilityButtonInActionSettings.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
	}
	
	public boolean isTilePresent(String tileno) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		int isPresent = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[1][text()='"+tileno+"']")).size();
		if(isPresent>0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
	
	public boolean setShowTagInSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));	
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		showTagsOnTileInActionSettings.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
		
		int tagThereCount = driver.findElements(By.xpath("//span[@class='title']/p/ancestor::div[@class='ideaTxt']/following-sibling::div//div[@class='tag-group']")).size();
		if(tagThereCount>0) {
			System.out.println("Tag is displaying on front of tile");
			return true;
		}
		else {
			System.out.println("Tag is not displaying on front of tile");
			return false;
		}
		
		
	}
	
	public boolean setHideTagInSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));	
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		hideTagsOnTileInActionSettings.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
		
		int tagThereCount = driver.findElements(By.xpath("//span[@class='title']/p/ancestor::div[@class='ideaTxt']/following-sibling::div//div[@class='tag-group']")).size();
		if(tagThereCount==0) {
			System.out.println("Tag is disappeared on front of tile");
			return true;
		}
		else {
			System.out.println("Tag is not disappeared on front of tile");
			return false;
		}
		
		
	}
	
	public void setAllCommentVisibilitySettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));	
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		allTileVisibilityButtonInActionDialogue.click();
		Thread.sleep(500);
		allcommentsVisibilityInActionSettings.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
				
	}
	
	public void setOwnersCommentVisibilitySettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));	
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		allTileVisibilityButtonInActionDialogue.click();
		Thread.sleep(500);
		ownercommentsVisibilityInActionSettings.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
				
	}
	
	public boolean postAComment(String tileno, String comment) throws Exception {
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")));
		int countbeforeadding = this.takeCommentCount(tileno);
		driver.findElement(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='idea_comments']")));
		JavascriptExecutor commentBox = (JavascriptExecutor) driver;
		commentBox.executeScript("arguments[0].click();", writeACommentTextBox);
		writeACommentTextBox.sendKeys(comment);
		Thread.sleep(500);
		postcommentButton.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")));
		Thread.sleep(1000);
		int countafteradding = this.takeCommentCount(tileno);
		if(countbeforeadding+1 == countafteradding) {
			System.out.println("Comment added successfully");
			return true;
		}
		else {
			System.out.println("Comment not added successfully");
			return false;
		}
	}
	
	public int takeCommentCount(String tileno) throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")));
		
		String commentcount = driver.findElement(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']//ancestor::div[@class='idea']//div[@class='commentsNumber ideaComments']")).getText();
		return Integer.parseInt(commentcount);		
		
	}
	
	public boolean checkShowFileVisibility() throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));	
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		showFileVisibilityInActionSettings.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[@class='ideaNumber']")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='idea_comments']")));
		
		
		int filebutton = driver.findElements(By.xpath("//label[@id='add-file-lbl']")).size();
		if(filebutton>0) {
			System.out.println("Add file button is displaying");
			tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			return true;
		}
		else {
			System.out.println("Add file button is not displaying");
			tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			return false;
		}
	}
	
	public boolean checkHideFileVisibility() throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		hideFileVisibilityInActionSettings.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[@class='ideaNumber']")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='idea_comments']")));
		
		
		int filebutton = driver.findElements(By.xpath("//label[@id='add-file-lbl']")).size();
		if(filebutton==0) {
			System.out.println("Add file button is hidden");
			tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			return true;
		}
		else {
			System.out.println("Add file button is not hidden");
			tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			return false;
		}
	}
	
	
	
	public void setAllTaggingAbilitySettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));	
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		allTileVisibilityButtonInActionDialogue.click();
		Thread.sleep(500);
		alltaggingAbilityInActionSettings.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
	}
	
	public void setOwnersTaggingAbilitySettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));	
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		allTileVisibilityButtonInActionDialogue.click();
		Thread.sleep(500);
		ownerstaggingAbilityInActionSettings.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
	}
	
	public boolean checkTaggingAbilityOfATile(String tileno) throws Exception{
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")));
		driver.findElement(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='idea_comments']")));
		//tagLabelInsideTile.click();
		JavascriptExecutor taglabel = (JavascriptExecutor) driver;
		taglabel.executeScript("arguments[0].click();", tagLabelInsideTile);
		Thread.sleep(1500);
		int isTaggingAbility = driver.findElements(By.xpath("//div[@class='tag-display selector disabled']")).size();
		if(isTaggingAbility>0) {
			System.out.println("Tagging ability of this tile is restricted for this user");
			tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			Thread.sleep(1000);
			return false;
		}
		else {
			System.out.println("User can able to tag this tile");
			tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
			Thread.sleep(1000);
			return true;
		}
	}
	
	public void setAlphaAscendingSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));	
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		allTileVisibilityButtonInActionDialogue.click();
		Thread.sleep(500);
		alphaAscendingAS.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
	}
	
	public Boolean alphabeticalAscendingTiles() throws Exception{
		int count = 0;
		NoodleActivity noodle = new NoodleActivity();
		
		Thread.sleep(2000);
		List<WebElement> tiles = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[2]/p"));
		int n =tiles.size();
		
		
		String alphabetOrder[] = noodle.sortElementsInAlphabeticalOrder(tiles);
		
		for(int i=0;i<n;i++) {
			System.out.println(alphabetOrder[i]);
			System.out.println("original order: "+tiles.get(i).getText());
			if(tiles.get(i).getText().equalsIgnoreCase(alphabetOrder[i])) {
				count++;
			}
		}
		System.out.println(count);
		if(count == n) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void setAlphaDescendingSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));	
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		allTileVisibilityButtonInActionDialogue.click();
		Thread.sleep(500);
		alphaDescendingAS.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
	}
	
	public Boolean alphabeticalDescendingTiles() throws Exception{
		int count = 0;
		NoodleActivity noodle = new NoodleActivity();
		Thread.sleep(2000);
		List<WebElement> tiles = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[2]/p"));
		int n =tiles.size();
		
		
		String alphabetOrder[] = noodle.sortElementsInAlphadescendingOrder(tiles);
		
		for(int i=0;i<n;i++) {
			if(tiles.get(i).getText().equalsIgnoreCase(alphabetOrder[i])) {
				count++;
			}
		}
		System.out.println(count);
		if(count == n) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void setNumericAscendingSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));	
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		allTileVisibilityButtonInActionDialogue.click();
		Thread.sleep(500);
		sortAscendingAS.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
	}
	
	
	public Boolean tilenoAscendingOrder() throws Exception{
		int count = 0;
		NoodleActivity noodle = new NoodleActivity();
		Thread.sleep(2000);
		List<WebElement> tiles = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[1]"));
		int n =tiles.size();
		
		
		int alphabetOrder[] = noodle.sortElementsInNumericAsc(tiles);
		String stringNumber;
		for(int i=0;i<n;i++) {
			stringNumber = Integer.toString(alphabetOrder[i]);
			if(tiles.get(i).getText().equalsIgnoreCase(stringNumber)) {
				count++;
			}
		}
		System.out.println(count);
		if(count == n) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void setNumericDescendingSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));	
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		allTileVisibilityButtonInActionDialogue.click();
		Thread.sleep(500);
		sortDescendingAS.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
	}
	
	public Boolean tilenoDescendingOrder() throws Exception{
		int count = 0;
		NoodleActivity noodle = new NoodleActivity();
		Thread.sleep(2000);
		List<WebElement> tiles = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[1]"));
		int n =tiles.size();
		
		
		int alphabetOrder[] = noodle.sortElementsInNumericDesc(tiles);
		String stringNumber;
		for(int i=0;i<n;i++) {
			stringNumber = Integer.toString(alphabetOrder[i]);
			if(tiles.get(i).getText().equalsIgnoreCase(stringNumber)) {
				count++;
			}
		}
		System.out.println(count);
		if(count == n) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void setShuffleSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));	
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		allTileVisibilityButtonInActionDialogue.click();
		Thread.sleep(500);
		sortShuffleAS.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
	}
	
	public Boolean tileshuffledOrder() throws Exception{
		int tilecount = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[1]")).size();
		Thread.sleep(2000);
		int tilecountAfterShuffle = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[1]")).size();
		if(tilecount ==tilecountAfterShuffle) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean resetNextAction() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));	
		
		Thread.sleep(1000);
		JavascriptExecutor sb = (JavascriptExecutor) driver;
		sb.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1000);
		
		actionIcon.click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'dialogTitle'][text()='Action Settings']")));
		Thread.sleep(500);
		resetNextactionButton.click();
		Thread.sleep(1000);
		confirmReopenBtn.click();
		Thread.sleep(500);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='actions: ']")));
		Thread.sleep(1000);
		
		int actiontitle = driver.findElements(By.xpath("//th[text()='Action']")).size();
		if(actiontitle==0) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
}









