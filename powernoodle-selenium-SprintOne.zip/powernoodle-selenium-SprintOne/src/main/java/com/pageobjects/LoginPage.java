package com.pageobjects;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.Base.Testbase;

public class LoginPage extends Testbase{
	
	@FindBy(id = "email")
	WebElement username;
	@FindBy(xpath = "//input[@name ='password']")
	WebElement password;
	@FindBy(xpath = "//input[@value='Login to Powernoodle']")
	WebElement clicklogin;
	
	public LoginPage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}
	
	public void Login(String un,String pswd) {
		username.sendKeys(un);
		password.sendKeys(pswd);
		clicklogin.click();

	}
}
