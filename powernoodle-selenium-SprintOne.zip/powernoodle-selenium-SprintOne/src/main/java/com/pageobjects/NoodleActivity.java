package com.pageobjects;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Base.Testbase;
import com.sun.corba.se.spi.orbutil.fsm.Action;

public class NoodleActivity extends Testbase {

	

	@FindBy(xpath = "//ul[@id='spaces']/li/h3/preceding-sibling::button")
	List<WebElement> enterButtonInSearchingSpace;

	@FindBy(xpath = "//ul[@id='spaces']/li/h3")
	List<WebElement> spaceNames;

	@FindBy(xpath = "//div[@id='decision_space']/div[@class='header']/h2")
	WebElement headerNameOfSpace;

	@FindBy(xpath = "//ul[@class='activities']/li//span[contains(text(),'Noodle')]")
	WebElement noodleActivity;

	@FindBy(xpath = "//div[@id='activityTitle']/h3[contains(text(),'noodle: ')]")
	WebElement noodlePageTitle;

	@FindBy(xpath = "//a[contains(text(),'Instructions')]")
	WebElement instructionIcon;

	@FindBy(xpath = "//div[@id='instructions']/h3[contains(text(),'Instructions')]")
	List<WebElement> instructionTitles;

	@FindBy(xpath = "//div[@id='instructions']/h3[contains(text(),'Instructions')]")
	WebElement instructionTitle;

	@FindBy(id = "addIdeaBtn")
	WebElement addIdeaButton;

	@FindBy(xpath = "//div[@id='instructions-part']//ol")
	WebElement instructionContent;

	@FindBy(xpath = "//a[contains(text(),'Watch this video!')]")
	WebElement linkInContent;

	@FindBy(xpath = "//a[contains(text(),'Applications')]")
	WebElement tabElementForWatchThisVideo;

	@FindBy(xpath = "//iframe[@class='pnvideo']")
	WebElement videoFrame;

	@FindBy(xpath = "//div[@class='play-icon']")
	WebElement playVideoIcon;

	@FindBy(xpath = "//div[@class='pause-icon']")
	WebElement pauseVideoIcon;

	@FindBy(xpath = "//div[@class='replay-icon']")
	WebElement replayVideoIcon;

	@FindBy(xpath = "//div[@role='textbox']")
	WebElement tileNameTextBoxInAddTileFrame;

	@FindBy(id = "add-idea-btn")
	WebElement submitInAddTileFrame;

	@FindBy(xpath = "//div[@id='ideas']/div[2]//div/span[2]/p")
	WebElement tileTitle;

	@FindBy(xpath = "//label[@for='participant_done']")
	WebElement iamDoneCheckBox;

	@FindBy(xpath = "//input[@id='participant_done']")
	WebElement iamDoneBox;

	@FindBy(xpath = "//div[@class = 'flash_notify success']")
	WebElement alertMsgAfterIAMDone;

	@FindBy(xpath = "//span[@id='total_participants_done']")
	WebElement doneCount;

	@FindBy(id = "switch-topics-btn")
	WebElement SwitchToTopicIcon;

	@FindBy(xpath = "//div[@class='questions']/div/div[2]/button[contains(text(),'Enter')]")
	WebElement nextTopicsEnterBtn;

	@FindBy(xpath = "//div[@class='ideaTxt']")
	WebElement tileTextArea;

	@FindBy(xpath = "//div[@class='comment_sliders']")
	WebElement tileCommentArea;

	@FindBy(xpath = "//div[contains(text(),'Write a Comment')]")
	WebElement writeACommentTextbox;

	@FindBy(id = "dialog-close-btn")
	WebElement dialogueCloseBtn;

	@FindBy(xpath = "//div[@class='ideaTxt']/span[1]")
	List<WebElement> tileNumbers;

	@FindBy(xpath = "//div[@class='ideaTxt']/span[2]/p")
	List<WebElement> tileNames;

	@FindBy(xpath = "//img[@src = 'images/icons/greyPlus.svg']")
	WebElement plusIconOfDescription;

	@FindBy(xpath = "//img[@src='images/icons/greyMinus.svg']")
	WebElement minusIconOfDescription;

	@FindBy(xpath = "//div[@class='desc']/following-sibling::a[contains(text(),'Show More')]")
	WebElement descWithShowMore;

	@FindBy(xpath = "//div[@class='collapsible-header']/following-sibling::div//div[@contenteditable ='true']")
	WebElement editableDescriptionBox;

	@FindBy(xpath = "//div[@id='desc-no-edit']")
	WebElement noneditableDescriptionBox;

	@FindBy(xpath = "//div[@class='collapsible-header']/following-sibling::div//div[@contenteditable ='true']//span/span")
	WebElement descriptionText;

	@FindBy(xpath = "//span[@class='num']/following-sibling::div[@class='draft-wrapper']//div[@role='textbox']")
	WebElement editableTitleOfTile;

	@FindBy(xpath = "//span[@class='num']/following-sibling::div[@class='title']")
	WebElement noneditableTitleOfTile;

	@FindBy(xpath = "//a[@id='idea_comments']/span[@id='idea_comment_count']")
	WebElement commentCountOftile;

	@FindBy(xpath = "//div[@class='add-comment']//div[@role='textbox']")
	WebElement writeACommentTextBox;

	@FindBy(xpath = "//button[contains(text(),'Post')]")
	WebElement postcommentButton;

	@FindBy(xpath = "//div[@class='comment-row top']//div/p")
	List<WebElement> unclickableCommentBars;

	@FindBy(xpath = "//div[@class='comment-row top']//div[@role='textbox']//span[@data-text='true']")
	List<WebElement> editableCommentBars;
	
	@FindBy(xpath = "//div[contains(text(),'Write a Reply')]/parent::div/following-sibling::div/div[@role='textbox']")
	WebElement writeAReplyTextBox;
	
	@FindBy(xpath = "//div[@class='comment-row top']/div[@class='comment-entry']/button[@class='toggle-children']")
	WebElement minusIconOfComment;
	
	@FindBy(xpath = "//div[@class='comment-entry']/following-sibling::div[@class='comment-row']")
	WebElement replyRow;
	
	@FindBy(xpath = "//div[@class='comment-row top']/div[@class='comment-entry']/button[@class='toggle-children']")
	List<WebElement> minusIconsOfComment;
	
	@FindBy(xpath = "//div[@class='comment-entry']/button[@class='toggle-children collapsed']")
	WebElement plusIconOfComment;
	
	@FindBy( xpath = "//div[@class='collapsible-header']/following-sibling::div//div[@contenteditable ='true']//span[@style='font-weight: bold;']/span")
	WebElement bolddescription;
	
	@FindBy(xpath = "//div[@class='tools']/button[contains(text(),'B')]")
	WebElement boldIcon;
	
	@FindBy(xpath = "//div[@class='tools']/button[contains(text(),'I')]")
	WebElement italicIcon;
	
	@FindBy(xpath = "//div[@class='tools']/button[contains(text(),'U')]")
	WebElement underlineIcon;
	
	@FindBy(xpath = "//div[@class='tools']/button[contains(text(),'•')]")
	WebElement dotBulletIcon;
	
	@FindBy(xpath = "//div[@class='tools']/button[contains(text(),'1.')]")
	WebElement numberBulletIcon;
	
	@FindBy(xpath = "//div[@class='tools']/button[contains(text(),'#')]")
	WebElement hyperlinkIcon;
	
	@FindBy(xpath = "//div[@class='add-url']/input")
	WebElement addUrlTextbox;
	
	@FindBy(xpath = "//div[@class='add-url']/button[@class='edit glyphicon glyphicon-ok']")
	WebElement tickMarkInAddUrl;
	
	@FindBy(xpath = "//span[@class='num']/following-sibling::div[1]//div[@role='textbox']")
	WebElement tileTextBoxInsideTile;
	
	@FindBy(xpath = "//div[@class='delete-confirm']/button[contains(text(),'OK')]")
	WebElement confirmDeleteBtn;
	
	@FindBy(xpath = "//div[@class='dialog-controls']/button[@id='dialog-delete-btn']")
	WebElement tileDeleteIcon;
	
	@FindBy(xpath = "//div[@class='dialog-controls']/button[@class='dialog-control delete disabled']")
	WebElement disabledTiledeleteBtn;
	
	@FindBy(xpath = "//div[@class='controls']/button[contains(text(),'Confirm')]")
	WebElement deleteTileConfirmBtn;
	
	@FindBy(xpath = "//div[@class='control']/button[@id='toggle_view_panel']")
	WebElement viewPanelToggle;
	
	@FindBy(xpath = "//div[@id='ideasFilters']//div/label[@title='List View']")
	WebElement listViewIcon;
	
	@FindBy(xpath = "//div[@id='ideasFilters']//div/label[@title='Tile View']")
	WebElement tileViewIcon;
	
	@FindBy(xpath = "//div[@id='ideasFilters']//div/label[@id='view-style-block-show-description_lbl']")
	WebElement showDescriptionCheckbox;
	
	@FindBy(xpath = "//div[@id='ideasFilters']//div/label[@title='My Tiles']")
	WebElement myTilesIcon;
		
	@FindBy(xpath = "//div[@id='ideasFilters']//div/label[@title='All Tiles']")
	WebElement allTilesIcon;
	
	@FindBy(xpath = "//div[@class='sort icon toggle']/label[@for ='sort_ascend_alpha']")
	WebElement alphaAscendingIcon;
	
	@FindBy(xpath = "//div[@class='sort icon toggle']/label[@for ='sort_descend_alpha']")
	WebElement alphaDescendingIcon;
	
	@FindBy(xpath = "//div[@class='sort icon toggle']/label[@for ='sort_ascend']")
	WebElement sortAscendingIcon;
	
	@FindBy(xpath = "//div[@class='sort icon toggle']/label[@for ='sort_descend']")
	WebElement sortDescendingIcon;
	
	@FindBy(xpath = "//div[@class='sort icon toggle']/label[@for ='sort_shuffle']")
	WebElement sortShuffleIcon;
	
	@FindBy(xpath = "//a[@id='activity-settings-btn']")
	WebElement viewNoodleSettingsIcon;
	
	@FindBy(xpath = "//ul[@id='stepMap']/li[@id='noodle']/div[@class='circle']")
	WebElement noodleCircle;
	
	@FindBy(xpath= "//div[@class='col-sm-5 toggle text-right step']//label[contains(text(),'Hide')]")
	WebElement hideNoodleBtn;
	
	@FindBy(xpath = "//div[@class='col-sm-5 toggle text-right step']//label[contains(text(),'Show')]")
	WebElement showNoodleBtn;
	
	@FindBy(xpath = "//div[@id='main']//ul/li/a[contains(text(),'Logout')]")
	WebElement logoutIcon;
	
	@FindBy(id="reopen-btn")
	WebElement resetNoodleBtn;
	
	@FindBy(xpath = "//div[@class='dialog reset-steps confirm']/div[@id='dialogTitle']")
	WebElement resetNoodleConfirmationAlert;
	
	@FindBy(xpath = "//div[@class='dialog reset-steps confirm']/div[@id='dialog-close-btn']")
	WebElement resetNoodleCloseBtnOfAlert;
	
	@FindBy(xpath = "//button[@id='confirm-btn']")
	WebElement confirmBtnItResetNoodleAlert;
	
	@FindBy(xpath = "//label[@id='add-file-lbl']/input[@id='add-file']")
	WebElement addFile;

	@FindBy(xpath  = "//input[@class='desc']")
	WebElement fileDesc;
	
	@FindBy(xpath  = "//input[@class='name']")
	WebElement fileNameOwn;
	
	@FindBy(xpath = "//button[@class='light-blue']")
	WebElement postFileNameBtn;
	
	@FindBy(xpath = "//button[@id='instructions-btn']")
	WebElement editInstructionIcon;
	
	@FindBy(id = "dialog-close-ok-btn")
	WebElement editInstructionOKButton;
	
	@FindBy(xpath = "//div[@class='DraftEditor-editorContainer']/div[@role='textbox']")
	WebElement participantTextArea;
	
	@FindBy(id="dialog-close-btn")
	WebElement tickOfResetNoodle;
	
	@FindBy(xpath = "//label[@id='tile_visibility_lbl_all']")
	WebElement tileVisibilityAllBtn;
	
	@FindBy(xpath = "//label[@id='tile_visibility_lbl_owner']")
	WebElement tileVisibilityOwnerBtn;
	
	@FindBy(xpath = "//div[text()='Add Tiles']/following::div/label[text()='Yes']")
	WebElement addTilesVisibilityYes;
	
	@FindBy(xpath = "//div[text()='Add Tiles']/following::div/label[text()='No']")
	WebElement addTilesVisibilityNo;
	
	@FindBy(xpath = "//label[text()='List']")
	WebElement listStyleIcon;
	
	@FindBy(xpath = "//label[text()='Tile']")
	WebElement tileStyleIcon;
	
	@FindBy(xpath = "//div[text()='Comment Visibility']/following-sibling::div/label[text()='All']")
	WebElement commentVisibilityAll;
	
	@FindBy(xpath = "//div[text()='Comment Visibility']/following-sibling::div/label[text()='Owners']")
	WebElement commentVisibilityOwners;
	
	
	//div[@id='instructions-part']/em/p[4]/em  last row
	

	public NoodleActivity() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}
	
	WebDriverWait wait = new WebDriverWait(driver, 40);
	JavascriptExecutor js = (JavascriptExecutor) driver;

	public String clickSpace(String noodleTitle) throws Exception {

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='spaces']/li/button")));

		for (int i = 0; i < spaceNames.size(); i++) {

			String s = spaceNames.get(i).getText();

			if (s.equals(noodleTitle)) {

				WebElement enterBtn = enterButtonInSearchingSpace.get(i);

				JavascriptExecutor eb = (JavascriptExecutor) driver;
				eb.executeScript("arguments[0].click();", enterBtn);
				break;
			}
		}

		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//div[@id='decision_space']/div[@class='header']/h2")));
		Thread.sleep(1000);

		return headerNameOfSpace.getText();
	}

	public Boolean clickNoodle() throws Exception {

		js.executeScript("window.scrollBy(0,1000)");
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//ul[@class='activities']/li//span[contains(text(),'Noodle')]")));
		JavascriptExecutor eb = (JavascriptExecutor) driver;
		eb.executeScript("arguments[0].click();", noodleActivity);
		Thread.sleep(1000);

		return noodlePageTitle.isDisplayed();
	}
	
	public boolean clickNoodleBasedOnTopic(String topic) throws Exception{
		//input[@value='xxxx']/ancestor::div/following-sibling::ul[@class='activities']/li//span[contains(text(),'Noodle')]
		js.executeScript("window.scrollBy(0,1000)");
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li//span[contains(text(),'Noodle')]")));
		WebElement na = driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li//span[contains(text(),'Noodle')]"));
		JavascriptExecutor eb = (JavascriptExecutor) driver;
		eb.executeScript("arguments[0].click();", na);
		Thread.sleep(1000);
		
		int isTherena = driver.findElements(By.xpath("//div[@id='activityTitle']/h3[contains(text(),'noodle: ')]")).size();
		if(isTherena>0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean clickNoodleBasedOnTopicInUserAccount(String topic) throws Exception{
		//input[@value='xxxx']/ancestor::div/following-sibling::ul[@class='activities']/li//span[contains(text(),'Noodle')]
		
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//h4[text()='"+topic+"']/following-sibling::ul[@class='activities']/li//span[contains(text(),'Noodle')]")));
		WebElement na = driver.findElement(By.xpath("//h4[text()='"+topic+"']/following-sibling::ul[@class='activities']/li//span[contains(text(),'Noodle')]"));
		JavascriptExecutor eb = (JavascriptExecutor) driver;
		eb.executeScript("arguments[0].click();", na);
		Thread.sleep(1000);
		
		int isTherena = driver.findElements(By.xpath("//div[@id='activityTitle']/h3[contains(text(),'noodle: ')]")).size();
		if(isTherena>0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Boolean checkInsIcon() throws Exception {
		Boolean bl = false;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		if (instructionTitle.isDisplayed()) {
			JavascriptExecutor ii = (JavascriptExecutor) driver;
			ii.executeScript("arguments[0].click();", instructionIcon);
			// instructionIcon.click();
			Thread.sleep(1000);
			Boolean state = instructionTitle.isDisplayed();
			if (state == false) {
				bl = true;
			}
		} else {
			JavascriptExecutor iii = (JavascriptExecutor) driver;
			iii.executeScript("arguments[0].click();", instructionIcon);
			// instructionIcon.click();
			Thread.sleep(1000);
			Boolean state = instructionTitle.isDisplayed();
			if (state == true) {
				bl = true;
			}
		}
		return bl;
	}

	public Boolean checkInstructions() throws Exception {
		//int count = 0;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));

		int stateOfIns = driver.findElements(By.xpath("//div[@id='instructions']/h3[contains(text(),'Instructions')]")).size();
		if (stateOfIns >0) {
			JavascriptExecutor iii = (JavascriptExecutor) driver;
			iii.executeScript("arguments[0].click();", instructionIcon);
			// instructionIcon.click();
			Thread.sleep(1000);
		}

		/*for (WebElement tl : instructionTitles) {
			if (tl.isDisplayed()) {
				count++;
			}
		}*/
		if ( instructionContent.isDisplayed() && linkInContent.isDisplayed()) {
			return true;
		} else {
			return false;
		}

	}

	public Boolean checkHyperLink() throws Exception {
		Boolean stateOfIns = instructionTitle.isDisplayed();
		if (stateOfIns == false) {
			JavascriptExecutor iii = (JavascriptExecutor) driver;
			iii.executeScript("arguments[0].click();", instructionIcon);

			Thread.sleep(1000);
		}
		linkInContent.click();
		Thread.sleep(3000);
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Applications')]")));

		if (videoFrame.isDisplayed()) {
			driver.switchTo().window(tabs2.get(0));
			return true;
		} else {
			driver.switchTo().window(tabs2.get(0));
			return false;
		}
	}

	public Boolean addNewTile(String tileName) throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		addIdeaButton.click();

		tileNameTextBoxInAddTileFrame.sendKeys(tileName);

		JavascriptExecutor tileSubmit = (JavascriptExecutor) driver;
		tileSubmit.executeScript("arguments[0].click();", submitInAddTileFrame);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		Thread.sleep(2000);
		if (tileTitle.getText().equals(tileName)) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean putIamDone() throws Exception {

		Boolean bl = false;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[@for='participant_done']")));
		// System.out.println(iamDoneBox.isSelected());
		if (iamDoneBox.isSelected() == false) {
			iamDoneCheckBox.click();
			Thread.sleep(100);
			if (alertMsgAfterIAMDone.isDisplayed()) {
				bl = true;
			} else {
				bl = false;
			}
		} else {
			iamDoneCheckBox.click();
			Thread.sleep(4000);
			iamDoneCheckBox.click();
			Thread.sleep(100);
			if (alertMsgAfterIAMDone.isDisplayed()) {
				bl = true;
			} else {
				bl = false;
			}
		}
		return bl;
	}

	public Boolean verifyDoneCount(String count) throws Exception {

		wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[contains(text(),'Participants Done: ')]")));
		if (doneCount.getText().equals(count)) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean verifyDoneCountBySwitchforthAndBack(String count, String topicName) throws Exception {

		Boolean bl = false;

		wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[contains(text(),'Participants Done: ')]")));

		if (doneCount.getText().equals(count)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("switch-topics-btn")));
			// SwitchToTopicIcon.click();
			JavascriptExecutor topicMenu = (JavascriptExecutor) driver;
			topicMenu.executeScript("arguments[0].click();", SwitchToTopicIcon);
			Thread.sleep(2000);

			JavascriptExecutor enterTopicBtn = (JavascriptExecutor) driver;
			enterTopicBtn.executeScript("arguments[0].click();", nextTopicsEnterBtn);
			Thread.sleep(1000);
			driver.navigate().refresh();

			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//p[contains(text(),'Participants Done: ')]")));

			topicMenu.executeScript("arguments[0].click();", SwitchToTopicIcon);
			Thread.sleep(2000);

			// wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("//button[contains(text(),'Enter')]")));

			WebElement actualTopicEnterBtn = driver.findElement(
					By.xpath("//div[@class='questions']/div/div[2]/div[@class='question_name'][contains(text(),'"
							+ topicName + "')]/following-sibling::button[@class='submit']"));
			JavascriptExecutor enteroldTopic = (JavascriptExecutor) driver;
			enteroldTopic.executeScript("arguments[0].click();", actualTopicEnterBtn);

			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//p[contains(text(),'Participants Done: ')]")));
			Thread.sleep(1000);

			if (doneCount.getText().equals(count)) {
				bl = true;
			} else {
				bl = false;
			}

		} else {
			bl = false;
		}
		return bl;

	}

	public Boolean checkTileNameAndNumber() throws Exception {

		//int nooftile = Integer.parseInt(tileCount);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		int noCount = 0;
		int nameCount = 0;
		for (WebElement tileNumberElement : tileNumbers) {
			if (tileNumberElement.getText() != null) {
				noCount++;
			}
		}
		for (WebElement tileNameElement : tileNames) {
			if (tileNameElement.getText() != null) {
				nameCount++;
			}
		}

		if (noCount == nameCount) {
			return true;
		} else {
			return false;
		}

	}

	public Boolean descPlusMinusMenus() throws Exception {

		Thread.sleep(1000);
		Boolean bl = false;
		JavascriptExecutor textArea = (JavascriptExecutor) driver;
		textArea.executeScript("arguments[0].click();", tileTextArea);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idea_comments")));
		if(driver.findElements(By.xpath("//img[@src='images/icons/greyMinus.svg']")).size()>0) {
			
		driver.findElement(By.xpath("//img[@src='images/icons/greyMinus.svg']")).click();

		}
		if(plusIconOfDescription.isDisplayed()) {

			JavascriptExecutor plus = (JavascriptExecutor) driver;
			plus.executeScript("arguments[0].click();", plusIconOfDescription);
			Thread.sleep(1000);

			if (minusIconOfDescription.isDisplayed() && descWithShowMore.isDisplayed()) {

				JavascriptExecutor minus = (JavascriptExecutor) driver;
				minus.executeScript("arguments[0].click();", minusIconOfDescription);
				Thread.sleep(1000);

				if (plusIconOfDescription.isDisplayed()) {
					bl = true;
					JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
					dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
					driver.navigate().refresh();
					return bl;
				} else {
					return bl;
				}
			} else {
				return bl;
			}
		} else {
			return bl;
		}

	}

	public Boolean enterIntoCommentsByClickingTileAnywhere() throws Exception {
		Thread.sleep(1000);

		int count = 0;

		JavascriptExecutor textArea = (JavascriptExecutor) driver;
		textArea.executeScript("arguments[0].click();", tileTextArea);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idea_comments")));

		if (writeACommentTextbox.isDisplayed()) {
			count++;
		}

		// dialogueCloseBtn.click();
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);

		driver.navigate().refresh();

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));

		JavascriptExecutor commentArea = (JavascriptExecutor) driver;
		commentArea.executeScript("arguments[0].click();", tileCommentArea);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idea_comments")));

		if (writeACommentTextbox.isDisplayed()) {
			count++;
		}

		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();

		if (count == 2) {
			return true;
		} else {
			return false;
		}

	}

	public void enterIntoSpecificTile(String tileno, String tilename) throws Exception {
		Actions actions=new Actions(driver);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));

		for (int i = 0; i < tileNames.size(); i++) {

			if (tileNames.get(i).getText().equals(tilename)) {
				if (tileNumbers.get(i).getText().equals(tileno)) {
					actions.moveToElement(tileNames.get(i));
					JavascriptExecutor textArea = (JavascriptExecutor) driver;
					textArea.executeScript("arguments[0].click();", tileNames.get(i));

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idea_comments")));
					Thread.sleep(1000);

				}
			}

		}
	}

	public Boolean addDescription(String tileno, String tilename, String description) throws Exception {

		Thread.sleep(1000);
		if (driver.findElements(By.xpath("//img[@src = 'images/icons/greyPlus.svg']")).size()>0) {

			JavascriptExecutor plus = (JavascriptExecutor) driver;
			plus.executeScript("arguments[0].click();", plusIconOfDescription);
			Thread.sleep(1000);
		}
		else {
			JavascriptExecutor descbox = (JavascriptExecutor) driver;
			descbox.executeScript("arguments[0].click();", editableDescriptionBox);
			// editableDescriptionBox.clear();
			editableDescriptionBox.sendKeys(Keys.CONTROL + "a");
			editableDescriptionBox.sendKeys(Keys.DELETE);

		}

		editableDescriptionBox.sendKeys(description);

		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));

		this.enterIntoSpecificTile(tileno, tilename);

		if (descriptionText.getText().equals(description)) {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		} else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}

	}

	public Boolean editDescription(String tileno, String tilename, String description) throws Exception {
		
		Thread.sleep(1000);
		if (driver.findElements(By.xpath("//img[@src = 'images/icons/greyPlus.svg']")).size()>0) {

			JavascriptExecutor plus = (JavascriptExecutor) driver;
			plus.executeScript("arguments[0].click();", plusIconOfDescription);
			Thread.sleep(1000);
		}

		Thread.sleep(1000);
		JavascriptExecutor descbox = (JavascriptExecutor) driver;
		descbox.executeScript("arguments[0].click();", editableDescriptionBox);
		// editableDescriptionBox.clear();
		editableDescriptionBox.sendKeys(Keys.CONTROL + "a");
		editableDescriptionBox.sendKeys(Keys.DELETE);

		editableDescriptionBox.sendKeys(description);

		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		// dialogueCloseBtn.click();

		driver.navigate().refresh();

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));

		this.enterIntoSpecificTile(tileno, tilename);

		if (descriptionText.getText().equals(description)) {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		} else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}

	}

	public Boolean addDescriptionForDiffAccount() throws Exception {

		Thread.sleep(1000);
		if (driver.findElements(By.xpath("//img[@src = 'images/icons/greyPlus.svg']")).size()>0) {

			JavascriptExecutor plus = (JavascriptExecutor) driver;
			plus.executeScript("arguments[0].click();", plusIconOfDescription);
			Thread.sleep(1000);
		}
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;

		if (driver.findElements(By.xpath("//div[@id='desc-no-edit']")).size()>0) {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		} else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
	}

	public Boolean editDescriptionForDiffAccount() throws Exception {
		
		

		Thread.sleep(1000);

		Thread.sleep(1000);
		if (driver.findElements(By.xpath("//img[@src = 'images/icons/greyPlus.svg']")).size()>0) {

			JavascriptExecutor plus = (JavascriptExecutor) driver;
			plus.executeScript("arguments[0].click();", plusIconOfDescription);
			Thread.sleep(1000);
		}

		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		
		if (driver.findElements(By.xpath("//div[@id='desc-no-edit']")).size()>0) {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		} else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
	}

	public Boolean isTileThere(String tileno, String tilename) throws Exception {
		Boolean bl = false;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		Thread.sleep(1000);

		for (int i = 0; i < tileNames.size(); i++) {

			if (tileNames.get(i).getText().equals(tilename)) {
				if (tileNumbers.get(i).getText().equals(tileno)) {
					bl = true;
					break;
				}

			}

		}
		return bl;
	}

	public Boolean editTile(String tileno, String tileNewname) throws Exception {
		Thread.sleep(1000);

		JavascriptExecutor titlebox = (JavascriptExecutor) driver;
		titlebox.executeScript("arguments[0].click();", editableTitleOfTile);

		editableTitleOfTile.sendKeys(Keys.CONTROL + "a");
		editableTitleOfTile.sendKeys(Keys.DELETE);
		editableTitleOfTile.sendKeys(tileNewname);

		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);

		driver.navigate().refresh();

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		Thread.sleep(2000);
		Boolean st = this.isTileThere(tileno, tileNewname);

		return st;
	}

	public Boolean editTileOfOthersTile() throws Exception {
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		int none = driver.findElements(By.xpath("//span[@class='num']/following-sibling::div[@class='title']")).size();
		if (none>0) {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			Thread.sleep(1500);
			return true;
		} else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			Thread.sleep(1500);
			return false;
		}
	}

	public Boolean addCommentForTile(String tileno,String comment) throws Exception {
		Thread.sleep(2000);

		int count = 0;
		int commentCountBeforeAdding = Integer.parseInt(commentCountOftile.getText());
		commentCountBeforeAdding++;

		JavascriptExecutor commentBox = (JavascriptExecutor) driver;
		commentBox.executeScript("arguments[0].click();", writeACommentTextBox);
		writeACommentTextBox.sendKeys(comment);

		postcommentButton.click();
		Thread.sleep(1500);
		int commentCountAfterAdding = Integer.parseInt(commentCountOftile.getText());
		if (commentCountBeforeAdding == commentCountAfterAdding) {

			for (WebElement ct : editableCommentBars) {

				if (ct.getText().equals(comment)) {
					count = count+1;
					break;
				}
			}

		}
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='noodle: ']")));
		Thread.sleep(1000);
		String commentNumOnTile = driver.findElement(By.xpath("//div[@class='ideaTxt']/span[1][contains(text(),'"+tileno+"')]/parent::div/following-sibling::div/div[@class='commentsNumber ideaComments']")).getText();
		int intcommentNumOnTile = Integer.parseInt(commentNumOnTile);
		if(intcommentNumOnTile == commentCountAfterAdding) {
			count = count+1;
		}
		
		if(count == 2) {
			return true;
		}
		else {
			return false;
		}
	
	}
	
	public Boolean editCommentForATile(String tileno,String tilename,String oldcomment, String newComment) throws Exception {
		Thread.sleep(2000);

		int count = 0;
		int commentCountBeforeEdition = Integer.parseInt(commentCountOftile.getText());
		
		WebElement textboxToedit = driver.findElement(By.xpath("//span[@data-text='true'][contains(text(),'"+oldcomment+"')]/ancestor::div[@role='textbox']"));
		
		JavascriptExecutor cb = (JavascriptExecutor) driver;
		cb.executeScript("arguments[0].click();", textboxToedit);

		textboxToedit.sendKeys(Keys.CONTROL + "a");
		textboxToedit.sendKeys(Keys.DELETE);
		textboxToedit.sendKeys(newComment);
		
		
		int commentCountAfterEdition = Integer.parseInt(commentCountOftile.getText());
		if (commentCountBeforeEdition == commentCountAfterEdition) {
			count=count+1;
		}

			
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		Thread.sleep(1000);
		String commentNumOnTile = driver.findElement(By.xpath("//div[@class='ideaTxt']/span[1][contains(text(),'"+tileno+"')]/parent::div/following-sibling::div/div[@class='commentsNumber ideaComments']")).getText();
		int intcommentNumOnTile = Integer.parseInt(commentNumOnTile);
		
		if(intcommentNumOnTile == commentCountAfterEdition) {
			count = count+1;
		}
		
		this.enterIntoSpecificTile(tileno, tilename);
		Thread.sleep(1000);
		for(WebElement ec : editableCommentBars) {
			if(ec.getText().equals(newComment)){
				count=count+1;
				break;
			}
		}
		
		if(count == 3) {
			return true;
		}
		else {
			return false;
		}
	
	}
	
	
	public Boolean editOthersCommentForATile(String oldcomment) throws Exception {
		Thread.sleep(2000);
		Boolean bl = false;
		for(WebElement uccb : unclickableCommentBars) {
			if(uccb.getText().equals(oldcomment)) {
				bl = true;
				break;
			}
		}
		
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		Thread.sleep(1000);
		return bl;
	
	}
	
	public Boolean addReply(String tileno, String tilename, String comment,String reply) throws Exception{
		Thread.sleep(2000);
		int count = 0;
		int commentCountBeforeAdding = Integer.parseInt(commentCountOftile.getText());
		commentCountBeforeAdding++;
		
		WebElement replyLink = driver.findElement(By.xpath("//span[@data-text='true'][contains(text(),'"+comment+"')]/ancestor::div[@class='DraftEditor']/following-sibling::span/button[@class='reply']"));
		replyLink.click();
		Thread.sleep(1000);
		
		JavascriptExecutor replyTextBox = (JavascriptExecutor) driver;
		replyTextBox.executeScript("arguments[0].click();", writeAReplyTextBox);		
		writeAReplyTextBox.sendKeys(reply);
		
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		Thread.sleep(1000);
		
		String commentNumOnTile = driver.findElement(By.xpath("//div[@class='ideaTxt']/span[1][contains(text(),'"+tileno+"')]/parent::div/following-sibling::div/div[@class='commentsNumber ideaComments']")).getText();
		int intcommentNumOnTile = Integer.parseInt(commentNumOnTile);
		
		if(intcommentNumOnTile == commentCountBeforeAdding) {
			count = count+1;
		}
		
		this.enterIntoSpecificTile(tileno, tilename);
		
		Thread.sleep(1000);
		for(WebElement ec : editableCommentBars) {
			if(ec.getText().equals(reply)){
				count=count+1;
				break;
			}
		}
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
				
		if(count == 2) {
			
			return true;
		}
		else {
			return false;
		}
		

	}
	
	public Boolean addReplyForOthersComment(String tileno, String tilename, String comment,String reply) throws Exception{
		Thread.sleep(2000);
		int count = 0;
		int commentCountBeforeAdding = Integer.parseInt(commentCountOftile.getText());
		commentCountBeforeAdding++;
		
		WebElement replyLink = driver.findElement(By.xpath("//p[contains(text(),'"+comment+"')]/parent::div[@class='static-comment']/following-sibling::span/button[contains(text(),'reply')]"));
		replyLink.click();
		Thread.sleep(1000);
		
		JavascriptExecutor replyTextBox = (JavascriptExecutor) driver;
		replyTextBox.executeScript("arguments[0].click();", writeAReplyTextBox);		
		writeAReplyTextBox.sendKeys(reply);
		
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		Thread.sleep(1000);
		
		String commentNumOnTile = driver.findElement(By.xpath("//div[@class='ideaTxt']/span[1][contains(text(),'"+tileno+"')]/parent::div/following-sibling::div/div[@class='commentsNumber ideaComments']")).getText();
		int intcommentNumOnTile = Integer.parseInt(commentNumOnTile);
		
		if(intcommentNumOnTile == commentCountBeforeAdding) {
			count = count+1;
		}
		
		this.enterIntoSpecificTile(tileno, tilename);
		
		Thread.sleep(1000);
		for(WebElement ec : editableCommentBars) {
			if(ec.getText().equals(reply)){
				count=count+1;
				break;
			}
		}
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
				
		if(count == 2) {
			
			return true;
		}
		else {
			return false;
		}
		

	}
	
	public Boolean editReply(String tileno, String tilename, String oldreply,String newreply) throws Exception{
		int count = 0;
		Thread.sleep(1000);
		WebElement replyBoxToEdit = driver.findElement(By.xpath("//span[@data-text='true'][contains(text(),'"+oldreply+"')]/ancestor::div[@role='textbox']"));
		
		JavascriptExecutor er = (JavascriptExecutor) driver;
		er.executeScript("arguments[0].click();", replyBoxToEdit);

		replyBoxToEdit.sendKeys(Keys.CONTROL + "a");
		replyBoxToEdit.sendKeys(Keys.DELETE);
		replyBoxToEdit.sendKeys(newreply);
		
		int commentCountAfterEdition = Integer.parseInt(commentCountOftile.getText());
		
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		Thread.sleep(1000);
		String commentNumOnTile = driver.findElement(By.xpath("//div[@class='ideaTxt']/span[1][contains(text(),'"+tileno+"')]/parent::div/following-sibling::div/div[@class='commentsNumber ideaComments']")).getText();
		int intcommentNumOnTile = Integer.parseInt(commentNumOnTile);
		
		if(intcommentNumOnTile == commentCountAfterEdition) {
			count = count+1;
		}
		
		this.enterIntoSpecificTile(tileno, tilename);
		Thread.sleep(1000);
		for(WebElement ec : editableCommentBars) {
			if(ec.getText().equals(newreply)){
				count=count+1;
				break;
			}
		}
		
		if(count == 2) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	public Boolean editReplyOfOthers(String oldreply) throws Exception{
		Thread.sleep(2000);
		Boolean bl = false;
		for(WebElement uccb : unclickableCommentBars) {
			if(uccb.getText().equals(oldreply)) {
				bl = true;
				break;
			}
		}
		
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		Thread.sleep(1000);
		return bl;
		}
	
	public Boolean commentPlusMinusMenus() throws Exception {
		
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;

		Thread.sleep(1000);
		Boolean bl = false;
		JavascriptExecutor textArea = (JavascriptExecutor) driver;
		textArea.executeScript("arguments[0].click();", tileTextArea);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idea_comments")));		

			if (minusIconOfComment.isDisplayed() && replyRow.isDisplayed()) {
				
				for(WebElement allminus: minusIconsOfComment) {					

					JavascriptExecutor minus = (JavascriptExecutor) driver;
					minus.executeScript("arguments[0].click();", allminus);
					Thread.sleep(500);
				}
				Thread.sleep(1000);
				

				if (plusIconOfComment.isDisplayed()) {
					
					bl = true;
					
					dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
					
					driver.navigate().refresh();
					return bl;
				} else {
					dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
					driver.navigate().refresh();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
					return bl;
				}
			} else {
				dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
				return bl;
			}
		
		}
	
	public Boolean boldsDescription(String description) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor descText = (JavascriptExecutor) driver;
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		if(driver.findElements(By.xpath("//img[@src = 'images/icons/greyPlus.svg']")).size()>0) {
			plusIconOfDescription.click();
			descText.executeScript("arguments[0].click();", editableDescriptionBox);
			Thread.sleep(1000);
		}
		
		else {		
		descText.executeScript("arguments[0].click();", editableDescriptionBox);	
		editableDescriptionBox.sendKeys(Keys.CONTROL + "a");
		editableDescriptionBox.sendKeys(Keys.DELETE);
		
		}
		
		editableDescriptionBox.sendKeys(description);
		editableDescriptionBox.sendKeys(Keys.CONTROL + "a");
		Thread.sleep(1000);
		
		boldIcon.click();
		Thread.sleep(1000);
		
		if(bolddescription.isDisplayed()) {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			 return false;
		}
		
		
	}
	
	public Boolean boldsComment(String comment) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		JavascriptExecutor commentBox = (JavascriptExecutor) driver;
		commentBox.executeScript("arguments[0].click();", writeACommentTextBox);
		writeACommentTextBox.sendKeys(comment);
		writeACommentTextBox.sendKeys(Keys.CONTROL + "a");
		Thread.sleep(1000);
		boldIcon.click();
		Thread.sleep(1000);
		postcommentButton.click();
		Thread.sleep(1000);
		WebElement boldedComment = driver.findElement(By.xpath("//div[@class='comment-row top']//div[@role='textbox']//span[@style='font-weight: bold;']/span[contains(text(),'"+comment+"')]"));
		if(boldedComment.isDisplayed()) {
			Actions action = new Actions(driver);			 
			action.moveToElement(boldedComment).build().perform();
			Thread.sleep(1000);
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
		
	}
	public Boolean boldsReply(String tileno,String tilename,String comment, String reply)throws Exception{
		Thread.sleep(1000);
		WebElement replyLink = driver.findElement(By.xpath("//span[@data-text='true'][contains(text(),'"+comment+"')]/ancestor::div[@class='DraftEditor']/following-sibling::span/button[@class='reply']"));
		replyLink.click();
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		JavascriptExecutor replyTextBox = (JavascriptExecutor) driver;
		replyTextBox.executeScript("arguments[0].click();", writeAReplyTextBox);
		Thread.sleep(1000);
		writeAReplyTextBox.sendKeys(reply);
		Thread.sleep(1000);
		WebElement replyToBold = driver.findElement(By.xpath("//span[contains(text(),'"+reply+"')]/ancestor::div[@role='textbox']"));
		replyTextBox.executeScript("arguments[0].click();", replyToBold);
		replyToBold.sendKeys(Keys.CONTROL + "a");
		Thread.sleep(1000);
		boldIcon.click();
		Thread.sleep(1000);
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		this.enterIntoSpecificTile(tileno, tilename);
		
		int boldedReply = driver.findElements(By.xpath("//div[@class='comment-row top']//div[@role='textbox']//span[@style='font-weight: bold;']/span[contains(text(),'"+reply+"')]")).size();
		if(boldedReply>0) {
			
			Thread.sleep(1000);
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
		
		
	}
	
	public Boolean italicDescription(String description) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor descText = (JavascriptExecutor) driver;
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		if(driver.findElements(By.xpath("//img[@src = 'images/icons/greyPlus.svg']")).size()>0) {
			plusIconOfDescription.click();
			descText.executeScript("arguments[0].click();", editableDescriptionBox);
			Thread.sleep(1000);
		}
		
		else {		
		descText.executeScript("arguments[0].click();", editableDescriptionBox);	
		editableDescriptionBox.sendKeys(Keys.CONTROL + "a");
		editableDescriptionBox.sendKeys(Keys.DELETE);
		
		}
		
		editableDescriptionBox.sendKeys(description);
		editableDescriptionBox.sendKeys(Keys.CONTROL + "a");
		Thread.sleep(1000);
		
		italicIcon.click();
		Thread.sleep(1000);
		int italiceddesc = driver.findElements(By.xpath("//div[@class='collapsible-header']/following-sibling::div//div[@contenteditable ='true']//span[contains(@style,'italic')]/span[contains(text(),'"+description+"')]")).size();
		if(italiceddesc>0) {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			 return false;
		}
		
		
	}
	
	public Boolean italicComment(String comment) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		JavascriptExecutor commentBox = (JavascriptExecutor) driver;
		commentBox.executeScript("arguments[0].click();", writeACommentTextBox);
		writeACommentTextBox.sendKeys(comment);
		writeACommentTextBox.sendKeys(Keys.CONTROL + "a");
		Thread.sleep(1000);
		italicIcon.click();
		Thread.sleep(1000);
		postcommentButton.click();
		Thread.sleep(1000);
		int italicedComment = driver.findElements(By.xpath("//div[@class='comment-row top']//div[@role='textbox']//span[contains(@style,'italic')]/span[contains(text(),'"+comment+"')]")).size();;
		if(italicedComment>0) {
			
			Thread.sleep(1000);
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
		
	}

	public Boolean italicReply(String tileno,String tilename,String comment, String reply)throws Exception{
		Thread.sleep(1000);
		WebElement replyLink = driver.findElement(By.xpath("//span[@data-text='true'][contains(text(),'"+comment+"')]/ancestor::div[@class='DraftEditor']/following-sibling::span/button[@class='reply']"));
		replyLink.click();
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		JavascriptExecutor replyTextBox = (JavascriptExecutor) driver;
		replyTextBox.executeScript("arguments[0].click();", writeAReplyTextBox);
		Thread.sleep(1000);
		writeAReplyTextBox.sendKeys(reply);
		Thread.sleep(1000);
		WebElement replyToItalic = driver.findElement(By.xpath("//span[contains(text(),'"+reply+"')]/ancestor::div[@role='textbox']"));
		replyTextBox.executeScript("arguments[0].click();", replyToItalic);
		replyToItalic.sendKeys(Keys.CONTROL + "a");
		Thread.sleep(1000);
		italicIcon.click();
		Thread.sleep(1000);
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		this.enterIntoSpecificTile(tileno, tilename);
		
		int italicedReply = driver.findElements(By.xpath("//div[@class='comment-row top']//div[@role='textbox']//span[contains(@style,'italic')]/span[contains(text(),'"+reply+"')]")).size();
		if(italicedReply>0) {
			
			Thread.sleep(1000);
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
		
		
	}
	
	public Boolean underlinedDescription(String description) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor descText = (JavascriptExecutor) driver;
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		if(driver.findElements(By.xpath("//img[@src = 'images/icons/greyPlus.svg']")).size()>0) {
			plusIconOfDescription.click();
			descText.executeScript("arguments[0].click();", editableDescriptionBox);
			Thread.sleep(1000);
		}
		
		else {		
		descText.executeScript("arguments[0].click();", editableDescriptionBox);	
		editableDescriptionBox.sendKeys(Keys.CONTROL + "a");
		editableDescriptionBox.sendKeys(Keys.DELETE);
		
		}
		
		editableDescriptionBox.sendKeys(description);
		editableDescriptionBox.sendKeys(Keys.CONTROL + "a");
		Thread.sleep(1000);
		
		underlineIcon.click();
		Thread.sleep(1000);
		int underlineddesc = driver.findElements(By.xpath("//div[@class='collapsible-header']/following-sibling::div//div[@contenteditable ='true']//span[contains(@style,'underline')]/span[contains(text(),'"+description+"')]")).size();
		if(underlineddesc>0) {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			 return false;
		}
		
		
	}
	
	public Boolean underlineComment(String comment) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		JavascriptExecutor commentBox = (JavascriptExecutor) driver;
		commentBox.executeScript("arguments[0].click();", writeACommentTextBox);
		writeACommentTextBox.sendKeys(comment);
		writeACommentTextBox.sendKeys(Keys.CONTROL + "a");
		Thread.sleep(1000);
		underlineIcon.click();
		Thread.sleep(1000);
		postcommentButton.click();
		Thread.sleep(1000);
		int underlinedComment = driver.findElements(By.xpath("//div[@class='comment-row top']//div[@role='textbox']//span[contains(@style,'underline')]/span[contains(text(),'"+comment+"')]")).size();;
		if(underlinedComment>0) {
			
			Thread.sleep(1000);
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
		
	}

	public Boolean underlineReply(String tileno,String tilename,String comment, String reply)throws Exception{
		Thread.sleep(1000);
		WebElement replyLink = driver.findElement(By.xpath("//span[@data-text='true'][contains(text(),'"+comment+"')]/ancestor::div[@class='DraftEditor']/following-sibling::span/button[@class='reply']"));
		replyLink.click();
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		JavascriptExecutor replyTextBox = (JavascriptExecutor) driver;
		replyTextBox.executeScript("arguments[0].click();", writeAReplyTextBox);
		Thread.sleep(1000);
		writeAReplyTextBox.sendKeys(reply);
		Thread.sleep(1000);
		WebElement replyToUnderline = driver.findElement(By.xpath("//span[contains(text(),'"+reply+"')]/ancestor::div[@role='textbox']"));
		replyTextBox.executeScript("arguments[0].click();", replyToUnderline);
		replyToUnderline.sendKeys(Keys.CONTROL + "a");
		Thread.sleep(1000);
		underlineIcon.click();
		Thread.sleep(1000);
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		this.enterIntoSpecificTile(tileno, tilename);
		
		int underlinedReply = driver.findElements(By.xpath("//div[@class='comment-row top']//div[@role='textbox']//span[contains(@style,'underline')]/span[contains(text(),'"+reply+"')]")).size();
		if(underlinedReply>0) {
			
			Thread.sleep(1000);
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
		
		
	}
	
	public Boolean bulletDescription(String description) throws Exception{
		Thread.sleep(1000);
		
		JavascriptExecutor descText = (JavascriptExecutor) driver;
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		if(driver.findElements(By.xpath("//img[@src = 'images/icons/greyPlus.svg']")).size()>0) {
			plusIconOfDescription.click();
			descText.executeScript("arguments[0].click();", editableDescriptionBox);
			Thread.sleep(1000);
		}
		
		else {		
		descText.executeScript("arguments[0].click();", editableDescriptionBox);	
		editableDescriptionBox.sendKeys(Keys.CONTROL + "a");
		editableDescriptionBox.sendKeys(Keys.DELETE);
		
		}
		
		editableDescriptionBox.sendKeys(description);
		editableDescriptionBox.sendKeys(Keys.CONTROL + "a");
		Thread.sleep(1000);
		//To check unordered list
		dotBulletIcon.click();
		Thread.sleep(1000);
		int dotBulleteddesc = driver.findElements(By.xpath("//div[@role='textbox']//ul//span/span[contains(text(),'"+description+"')]")).size();
		if(dotBulleteddesc>0) {
			Thread.sleep(2000);
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
		
		
	}
	
	public boolean orderedBulletInDesc(String description) throws Exception{
		Thread.sleep(1000);
		
		JavascriptExecutor descText = (JavascriptExecutor) driver;
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		if(driver.findElements(By.xpath("//img[@src = 'images/icons/greyPlus.svg']")).size()>0) {
			plusIconOfDescription.click();
			descText.executeScript("arguments[0].click();", editableDescriptionBox);
			Thread.sleep(1000);
		}
		
		else {		
		descText.executeScript("arguments[0].click();", editableDescriptionBox);	
		editableDescriptionBox.sendKeys(Keys.CONTROL + "a");
		editableDescriptionBox.sendKeys(Keys.DELETE);
		
		}
		
		editableDescriptionBox.sendKeys(description);
		editableDescriptionBox.sendKeys(Keys.CONTROL + "a");
		Thread.sleep(1000);
		numberBulletIcon.click();
		Thread.sleep(1000);
		int numberBulleteddesc = driver.findElements(By.xpath("//div[@role='textbox']//ol//span/span[contains(text(),'"+description+"')]")).size();
		if(numberBulleteddesc>0) {
			Thread.sleep(2000);
			
		
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
	}
	
	public Boolean hyperlinkedDescription(String tileno, String tilename,String description,String urllink) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor descText = (JavascriptExecutor) driver;
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		if(driver.findElements(By.xpath("//img[@src = 'images/icons/greyPlus.svg']")).size()>0) {
			plusIconOfDescription.click();
			descText.executeScript("arguments[0].click();", editableDescriptionBox);
			Thread.sleep(1000);
		}
		
		else {		
		descText.executeScript("arguments[0].click();", editableDescriptionBox);	
		editableDescriptionBox.sendKeys(Keys.CONTROL + "a");
		editableDescriptionBox.sendKeys(Keys.DELETE);
		Thread.sleep(1000);
		}
		descText.executeScript("arguments[0].click();", editableDescriptionBox);
		editableDescriptionBox.sendKeys(description);
		editableDescriptionBox.sendKeys(Keys.CONTROL + "a");
		Thread.sleep(1000);
		
		hyperlinkIcon.click();
		Thread.sleep(2000);
		JavascriptExecutor urltb = (JavascriptExecutor) driver;
		urltb.executeScript("arguments[0].click();", addUrlTextbox);
		urltb.executeScript("arguments[0].value='"+urllink+"';", addUrlTextbox);
		Thread.sleep(500);
		JavascriptExecutor tm = (JavascriptExecutor) driver;
		tm.executeScript("arguments[0].click();", tickMarkInAddUrl);
		//tickMarkInAddUrl.click();
		
		Thread.sleep(1500);
		
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		this.enterIntoSpecificTile(tileno, tilename);
		Thread.sleep(1000);
		int hyperlinkeddesc = driver.findElements(By.xpath("//div[@class='collapsible-header']/following-sibling::div//div[@contenteditable ='true']//a//span[contains(text(),'"+description+"')]")).size();
		
		
		if(hyperlinkeddesc>0) {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			
			return true;
		}
			
		
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			 return false;
		}
		
		
	}
	
	public Boolean hyperlinkedComment(String tileno,String tilename,String comment,String url) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		JavascriptExecutor commentBox = (JavascriptExecutor) driver;
		commentBox.executeScript("arguments[0].click();", writeACommentTextBox);
		writeACommentTextBox.sendKeys(comment);
		writeACommentTextBox.sendKeys(Keys.CONTROL + "a");
		Thread.sleep(1000);
		hyperlinkIcon.click();
		Thread.sleep(1000);
		
		JavascriptExecutor urltb = (JavascriptExecutor) driver;
		urltb.executeScript("arguments[0].click();", addUrlTextbox);
		urltb.executeScript("arguments[0].value='"+url+"';", addUrlTextbox);
		Thread.sleep(500);
		JavascriptExecutor tm = (JavascriptExecutor) driver;
		tm.executeScript("arguments[0].click();", tickMarkInAddUrl);
		//tickMarkInAddUrl.click();
		Thread.sleep(1500);
		postcommentButton.click();
		Thread.sleep(1000);
		int hyperlinkedcomment = driver.findElements(By.xpath("//div[@class='comment-row top']//div[@role='textbox']//a//span[contains(text(),'"+comment+"')]")).size();
		if(hyperlinkedcomment>0) {
			
			Thread.sleep(1000);
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			Thread.sleep(1000);
			this.enterIntoSpecificTile(tileno, tilename);
			if(driver.findElements(By.xpath("//div[@class='comment-row top']//div[@role='textbox']//a//span[contains(text(),'"+comment+"')]")).size()>0) {
				return true;
			}
			else {
				return false;
			}
			
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
		
	}

	public Boolean hyperlinkedReply(String tileno,String tilename,String comment, String reply,String url)throws Exception{
		Thread.sleep(1000);
		WebElement replyLink = driver.findElement(By.xpath("//span[text()='"+comment+"']/following-sibling::button[@class='reply']"));
		//replyLink.click();
		JavascriptExecutor rl = (JavascriptExecutor) driver;
		rl.executeScript("arguments[0].click();", replyLink);
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		JavascriptExecutor replyTextBox = (JavascriptExecutor) driver;
		replyTextBox.executeScript("arguments[0].click();", writeAReplyTextBox);
		Thread.sleep(1000);
		writeAReplyTextBox.sendKeys(reply);
		Thread.sleep(1000);
		WebElement replyToUnderline = driver.findElement(By.xpath("//span[contains(text(),'"+reply+"')]/ancestor::div[@role='textbox']"));
		replyTextBox.executeScript("arguments[0].click();", replyToUnderline);
		replyToUnderline.sendKeys(Keys.CONTROL + "a");
		Thread.sleep(1000);
		JavascriptExecutor hyper = (JavascriptExecutor) driver;
		hyper.executeScript("arguments[0].click();", hyperlinkIcon);
		//hyperlinkIcon.click();
		Thread.sleep(1000);
		JavascriptExecutor urltb = (JavascriptExecutor) driver;
		urltb.executeScript("arguments[0].click();", addUrlTextbox);
		urltb.executeScript("arguments[0].value='"+url+"';", addUrlTextbox);
		
		/*replyTextBox.executeScript("arguments[0].click();", replyToUnderline);
		replyToUnderline.sendKeys(Keys.CONTROL + "a");*/
		
		Thread.sleep(500);
		JavascriptExecutor tm = (JavascriptExecutor) driver;
		tm.executeScript("arguments[0].click();", tickMarkInAddUrl);
		//tickMarkInAddUrl.click();
		Thread.sleep(1500);
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		this.enterIntoSpecificTile(tileno, tilename);
		
		int hyperlinkedreply = driver.findElements(By.xpath("//div[@class='comment-row top']//div[@role='textbox']//a//span[contains(text(),'"+reply+"')]")).size();
		if(hyperlinkedreply>0) {
			
			Thread.sleep(1000);
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
		
		
	}
	
	public Boolean hyperlinkedTitle(String tilename,String url) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		JavascriptExecutor commentBox = (JavascriptExecutor) driver;
		commentBox.executeScript("arguments[0].click();", tileTextBoxInsideTile);
		tileTextBoxInsideTile.sendKeys(Keys.CONTROL + "a");
		tileTextBoxInsideTile.sendKeys(Keys.DELETE);
		Thread.sleep(1000);
		commentBox.executeScript("arguments[0].click();", tileTextBoxInsideTile);
		tileTextBoxInsideTile.sendKeys(tilename);
		tileTextBoxInsideTile.sendKeys(Keys.CONTROL + "a");
		Thread.sleep(1000);
		hyperlinkIcon.click();
		Thread.sleep(1000);
		
		JavascriptExecutor urltb = (JavascriptExecutor) driver;
		urltb.executeScript("arguments[0].click();", addUrlTextbox);
		urltb.executeScript("arguments[0].value='"+url+"';", addUrlTextbox);
		Thread.sleep(500);
		JavascriptExecutor tm = (JavascriptExecutor) driver;
		tm.executeScript("arguments[0].click();", tickMarkInAddUrl);
		//tickMarkInAddUrl.click();
		Thread.sleep(1500);
		
		int hyperlinkedtitle = driver.findElements(By.xpath("//a//span[contains(text(),'"+tilename+"')]")).size();
		if(hyperlinkedtitle>0) {
			
			Thread.sleep(1000);
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			Thread.sleep(1000);
			int linkInTileTitle = driver.findElements(By.xpath("//div[@id='ideas']//a[contains(text(),'"+tilename+"')]")).size();
			if(linkInTileTitle>0) {
				
				/*driver.findElement(By.xpath("//div[@id='ideas']/div[2]//div/span[2]/p//a[contains(text(),'"+tilename+"')]")).click();
				Thread.sleep(1000);
				if(driver.findElements(By.xpath("//span[@class='num']/following-sibling::div[1]//div[@role='textbox']//a//span[contains(text(),'"+tilename+"')]")).size()>0) {
					dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
					driver.navigate().refresh();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
					
					return true;
				}
				else {*/
					
					return true;
				}
			
				else {
					return false;
				}
			
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
		
	}
	
	public Boolean deleteComment(String tileno, String tilename, String commentNo) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		
		WebElement commentToDelete = driver.findElement(By.xpath("//span[text()='"+commentNo+"']/ancestor::span/preceding-sibling::button[@class='remove']"));
		Thread.sleep(1000);
		JavascriptExecutor cc = (JavascriptExecutor) driver;
		cc.executeScript("arguments[0].click();", commentToDelete);
		//commentToDelete.click();
		Thread.sleep(1000);
		confirmDeleteBtn.click();
		Thread.sleep(1000);
		int deletedComment = driver.findElements(By.xpath("//div[@class='comment-row top']//span[text()='"+commentNo+"']")).size();
		if(deletedComment==0) {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
	}
	
	public Boolean deleteReply(String replyno) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		//span[contains(text(),'cc')]/ancestor::div[@class='comment-row top']//div/following-sibling::button[@class='remove']
		WebElement replyToDelete = driver.findElement(By.xpath("//span[text()='"+replyno+"']//ancestor::span/preceding-sibling::button[@class='remove']"));
		Thread.sleep(1000);
		JavascriptExecutor rd = (JavascriptExecutor) driver;
		rd.executeScript("arguments[0].click();", replyToDelete);
		//replyToDelete.click();
		Thread.sleep(1000);
		confirmDeleteBtn.click();
		Thread.sleep(1000);
		int deletedreply = driver.findElements(By.xpath("//div[@class='comment-row top']//span[text()='"+replyno+"']")).size();
		if(deletedreply==0) {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
	}
	
	public Boolean deleteTile(String tileno, String tilename) throws Exception{
		Thread.sleep(1000);
		
		JavascriptExecutor dialogueDelete = (JavascriptExecutor) driver;
		dialogueDelete.executeScript("arguments[0].click();", tileDeleteIcon);		
		Thread.sleep(1000);
		
		deleteTileConfirmBtn.click();
		Thread.sleep(1000);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		Thread.sleep(1000);
		
		if(this.isTileThere(tileno, tilename)) {
			
			return false;
		}
		else {
			
			return true;
		}
	}
	
	public Boolean deleteOthersComment( String commentNo) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		
		int commentToDelete = driver.findElements(By.xpath("//span[text()='"+commentNo+"']/ancestor::span/preceding-sibling::button[@class='remove']")).size();
		Thread.sleep(1000);
		
		if(commentToDelete==0) {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
	}
	
	public Boolean deleteOthersReply( String replyNo) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		
		int replyToDelete = driver.findElements(By.xpath("//span[text()='"+replyNo+"']//ancestor::span/preceding-sibling::button[@class='remove']")).size();
		Thread.sleep(1000);
		
		if(replyToDelete==0) {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return true;
		}
		
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
	}
	
	public Boolean deleteOthersTile(String tileno, String tilename) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		int disableddelete = driver.findElements(By.xpath("//div[@class='dialog-controls']/button[@class='dialog-control delete disabled']")).size();
		if(disableddelete>0) {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			Thread.sleep(1000);
			if(this.isTileThere(tileno, tilename)) {
				
				return true;
			}
			else {
				
				return false;
			}
		}
		
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
		
		
	}
	
	public Boolean deleteCommentWhichHasReply(String commentNo, String replyNo)throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		//span[contains(text(),'cc')]/ancestor::div[@class='comment-row top']//div/following-sibling::button[@class='remove']
		WebElement commentToDelete = driver.findElement(By.xpath("//span[@class='number'][contains(text(),'"+commentNo+"')]/ancestor::span/preceding-sibling::button[@class='remove']"));
		Thread.sleep(1000);
		commentToDelete.click();
		Thread.sleep(1000);
		confirmDeleteBtn.click();
		Thread.sleep(1000);
		int deletedComment = driver.findElements(By.xpath("//div[@class='comment-row top']//div[@class='static-comment deleted']/following-sibling::span//span[@class='number'][contains(text(),'"+commentNo+"')]")).size();
		if(deletedComment>0) {
			int replyUnderComment = driver.findElements(By.xpath("//div[@class='comment-row top']//span[@class='number'][contains(text(),'"+replyNo+"')]")).size();
			if(replyUnderComment>0) {
				dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
				return true;
			}
			else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
			}
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			return false;
		}
	}
	
	public Boolean checkOnDisplayViewPanelToggle()throws Exception{
		Thread.sleep(1000);
		viewPanelToggle.click();
		Thread.sleep(2000);
		int isviewIconThere = driver.findElements(By.xpath("//div[@id='main']/ul/li[@class='viewfilter sub active']")).size();
		int isIdeaFilterThere = driver.findElements(By.xpath("//div[@id='ideasFilters']//div/h4[contains(text(),'Display')]")).size();
		
		if(isviewIconThere>0 && isIdeaFilterThere>0) {
			viewPanelToggle.click();
			Thread.sleep(2000);
			int isViewIconActive = driver.findElements(By.xpath("//div[@id='main']/ul/li[@class='viewfilter sub active']")).size();
			if(isViewIconActive==0) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
		
	}
	
	public void clickOnviewPanelToggle() throws Exception{
		Thread.sleep(1000);
		viewPanelToggle.click();
		Thread.sleep(1000);
	}
	
	public Boolean testListViewOfTiles() throws Exception{
		JavascriptExecutor listicon = (JavascriptExecutor) driver;
		listicon.executeScript("arguments[0].click();", listViewIcon);
		//listViewIcon.click();
		Thread.sleep(1500);
		int isTileListThere = driver.findElements(By.xpath("//div[@class='grid-layout list']")).size();
		if(isTileListThere>0) {
			return true;
		}
		
		else {
			return false;
		}
	}
	
	public Boolean testTileViewOfTiles() throws Exception{
		JavascriptExecutor listicon = (JavascriptExecutor) driver;
		listicon.executeScript("arguments[0].click();", tileViewIcon);
		//tileViewIcon.click();
		Thread.sleep(1500);
		int isTileListThere = driver.findElements(By.xpath("//div[@class='grid-layout list']")).size();
		if(isTileListThere==0) {
			return true;
		}
		
		else {
			return false;
		}
	}
	
	
	
	public Boolean testTiledescriptionWhilehavingCheckedShowdescription() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='ideasFilters']//div/label[@id='view-style-block-show-description_lbl']")));
		
		int isTileDescriptionThere = driver.findElements(By.xpath("//div[@class='idea']//div[@class='description-container']")).size();
		if(isTileDescriptionThere>0) {
			return true;
		}
		
		else {
			return false;
		}
	}
	
	public Boolean testTiledescriptionWhilehavingUnCheckedShowdescription() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='ideasFilters']//div/label[@id='view-style-block-show-description_lbl']")));
		JavascriptExecutor listicon = (JavascriptExecutor) driver;
		listicon.executeScript("arguments[0].click();", showDescriptionCheckbox);
		//showDescriptionCheckbox.click();
		Thread.sleep(1000);
		int isTileDescriptionThere = driver.findElements(By.xpath("//div[@class='idea']//div[@class='description-container']")).size();
		if(isTileDescriptionThere==0) {
			return true;
		}
		
		else {
			return false;
		}
	}
	
	public Boolean testMyTiles(String mytileno, String othertileno)throws Exception{
		Thread.sleep(1000);
		int count=0;
		int alltilecount = driver.findElements(By.xpath("//div[@class='idea']")).size();
		JavascriptExecutor listicon = (JavascriptExecutor) driver;
		listicon.executeScript("arguments[0].click();", myTilesIcon);
		//myTilesIcon.click();
		Thread.sleep(1000);
		int mytilecount = driver.findElements(By.xpath("//div[@class='idea']")).size();
		if(alltilecount>mytilecount) {
			
			for(WebElement tiles: tileNumbers) {
				if(tiles.getText().equals(mytileno)){
					count=count+1;
					
				}
				if(tiles.getText().equals(othertileno)) {
					count=count-1;
					
				}
			}
			if(count==1) {
				return true;
			}
			else {
				return false;
			}
			
		}
		else {
			
		return false;
		}
	}
	
	public Boolean testAllTiles(String mytileno, String othertileno)throws Exception{
		Thread.sleep(1000);
		int count=0;
		int alltilecount = driver.findElements(By.xpath("//div[@class='idea']")).size();
		JavascriptExecutor listicon = (JavascriptExecutor) driver;
		listicon.executeScript("arguments[0].click();", myTilesIcon);
		//myTilesIcon.click();
		int mytilecount = driver.findElements(By.xpath("//div[@class='idea']")).size();
		Thread.sleep(1000);
		JavascriptExecutor all = (JavascriptExecutor) driver;
		all.executeScript("arguments[0].click();", allTilesIcon);
		//allTilesIcon.click();
		Thread.sleep(1000);
		int allTilescountAfterAll = driver.findElements(By.xpath("//div[@class='idea']")).size();
		if(alltilecount==allTilescountAfterAll && allTilescountAfterAll>mytilecount) {
			
			for(WebElement tiles: tileNumbers) {
				if(tiles.getText().equals(mytileno)){
					count=count+1;
					
				}
				if(tiles.getText().equals(othertileno)) {
					count=count+1;
					
				}
			}
			if(count==2) {
				return true;
			}
			else {
				return false;
			}
			
		}
		else {
			
		return false;
		}
	}
	
	public String[] sortElementsInAlphabeticalOrder(List<WebElement> elementList ) throws Exception{
		int listSize = elementList.size();
		String sortedArray[] = new String[listSize];
		int i=0;
		for(WebElement e: elementList) {
			sortedArray[i]= e.getText().toLowerCase();
			i++;
		}
		String temp;
		 for (int x = 0; x < listSize; x++) 
	        {
	            for (int y = x + 1; y < listSize; y++) 
	            {
	                if (sortedArray[x].compareTo(sortedArray[y])>0) 
	                {
	                	
	                    temp = sortedArray[x];
	                    sortedArray[x] = sortedArray[y];
	                    sortedArray[y] = temp;
	                }
	            }
	        }
		 
		 return sortedArray;
	}
	public String[] sortElementsInAlphadescendingOrder(List<WebElement> elementList ) throws Exception{
		int listSize = elementList.size();
		String sortedArray[] = new String[listSize];
		int i=0;
		for(WebElement e: elementList) {
			sortedArray[i]= e.getText().toLowerCase();
			i++;
		}
		String temp;
		 for (int x = 0; x < listSize; x++) 
	        {
	            for (int y = x + 1; y < listSize; y++) 
	            {
	                if (sortedArray[x].compareTo(sortedArray[y])<0) 
	                {
	                	
	                    temp = sortedArray[x];
	                    sortedArray[x] = sortedArray[y];
	                    sortedArray[y] = temp;
	                }
	            }
	        }
		 
		 return sortedArray;
	}
	
	public Boolean alphabeticalAscendingTiles() throws Exception{
		int count = 0;
		JavascriptExecutor all = (JavascriptExecutor) driver;
		all.executeScript("arguments[0].click();", alphaAscendingIcon);
		//alphaAscendingIcon.click();
		Thread.sleep(2000);
		List<WebElement> tiles = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[2]/p"));
		int n =tiles.size();
		
		
		String alphabetOrder[] = this.sortElementsInAlphabeticalOrder(tiles);
		
		for(int i=0;i<n;i++) {
			if(tiles.get(i).getText().equalsIgnoreCase(alphabetOrder[i])) {
				count++;
			}
		}
		System.out.println(count);
		if(count == n) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Boolean alphabeticalDescendingTiles() throws Exception{
		int count = 0;
		JavascriptExecutor all = (JavascriptExecutor) driver;
		all.executeScript("arguments[0].click();", alphaDescendingIcon);
		alphaDescendingIcon.click();
		Thread.sleep(2000);
		List<WebElement> tiles = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[2]/p"));
		int n =tiles.size();
		
		
		String alphabetOrder[] = this.sortElementsInAlphadescendingOrder(tiles);
		
		for(int i=0;i<n;i++) {
			if(tiles.get(i).getText().equalsIgnoreCase(alphabetOrder[i])) {
				count++;
			}
		}
		System.out.println(count);
		if(count == n) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public int[] sortElementsInNumericAsc(List<WebElement> elementList ) throws Exception{
		int listSize = elementList.size();
		int sortedArray[] = new int[listSize];
		int i=0;
		for(WebElement e: elementList) {
			sortedArray[i]= Integer.parseInt(e.getText());
			i++;
		}
		int temp;
		 for (int x = 0; x < listSize; x++) 
	        {
	            for (int y = x + 1; y < listSize; y++) 
	            {
	                if (sortedArray[x]>sortedArray[y]) 
	                {
	                	
	                    temp = sortedArray[x];
	                    sortedArray[x] = sortedArray[y];
	                    sortedArray[y] = temp;
	                }
	            }
	        }
		 
		 return sortedArray;
	}
	
	public int[] sortElementsInNumericDesc(List<WebElement> elementList ) throws Exception{
		int listSize = elementList.size();
		int sortedArray[] = new int[listSize];
		int i=0;
		for(WebElement e: elementList) {
			sortedArray[i]= Integer.parseInt(e.getText());
			i++;
		}
		int temp;
		 for (int x = 0; x < listSize; x++) 
	        {
	            for (int y = x + 1; y < listSize; y++) 
	            {
	                if (sortedArray[x]<sortedArray[y]) 
	                {
	                	
	                    temp = sortedArray[x];
	                    sortedArray[x] = sortedArray[y];
	                    sortedArray[y] = temp;
	                }
	            }
	        }
		 
		 return sortedArray;
	}
	
	public Boolean tilenoAscendingOrder() throws Exception{
		int count = 0;
		JavascriptExecutor all = (JavascriptExecutor) driver;
		all.executeScript("arguments[0].click();", sortAscendingIcon);
		//sortAscendingIcon.click();
		Thread.sleep(2000);
		List<WebElement> tiles = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[1]"));
		int n =tiles.size();
		
		
		int alphabetOrder[] = this.sortElementsInNumericAsc(tiles);
		String stringNumber;
		for(int i=0;i<n;i++) {
			stringNumber = Integer.toString(alphabetOrder[i]);
			if(tiles.get(i).getText().equalsIgnoreCase(stringNumber)) {
				count++;
			}
		}
		System.out.println(count);
		if(count == n) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Boolean tilenoDescendingOrder() throws Exception{
		int count = 0;
		JavascriptExecutor all = (JavascriptExecutor) driver;
		all.executeScript("arguments[0].click();", sortDescendingIcon);
		//sortDescendingIcon.click();
		Thread.sleep(2000);
		List<WebElement> tiles = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[1]"));
		int n =tiles.size();
		
		
		int alphabetOrder[] = this.sortElementsInNumericDesc(tiles);
		String stringNumber;
		for(int i=0;i<n;i++) {
			stringNumber = Integer.toString(alphabetOrder[i]);
			if(tiles.get(i).getText().equalsIgnoreCase(stringNumber)) {
				count++;
			}
		}
		System.out.println(count);
		if(count == n) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Boolean tileshuffledOrder() throws Exception{
		int tilecount = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[1]")).size();
		JavascriptExecutor all = (JavascriptExecutor) driver;
		all.executeScript("arguments[0].click();", sortShuffleIcon);
		//sortShuffleIcon.click();
		Thread.sleep(2000);
		int tilecountAfterShuffle = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[1]")).size();
		if(tilecount ==tilecountAfterShuffle) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Boolean checkViewNoodleSettingsPanel() throws Exception{
		Thread.sleep(2000);
		JavascriptExecutor noodlesettingsicon = (JavascriptExecutor) driver;
		noodlesettingsicon.executeScript("arguments[0].click();", viewNoodleSettingsIcon);
		//viewNoodleSettingsIcon.click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='main']/ul/li[@class='activity_settings sub active']")));
		
		noodleCircle.click();
		Thread.sleep(1500);
		
		int isSettingsThere = driver.findElements(By.xpath("//div[contains(text(),'Noodle Settings')]")).size();
		if(isSettingsThere>0) {
			return true;
		}
		else {
		return false;
		}
	}
	
	public Boolean hideNoodleActivity() throws Exception{
		hideNoodleBtn.click();
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		/*driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));*/
		Thread.sleep(1000);
		JavascriptExecutor logout = (JavascriptExecutor) driver;
		logout.executeScript("arguments[0].click();", logoutIcon);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='Login to Powernoodle']")));
		int isLoginBtn = driver.findElements(By.xpath("//input[@value='Login to Powernoodle']")).size();
		if(isLoginBtn>0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Boolean showNoodleActivity() throws Exception{
		showNoodleBtn.click();
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
		/*driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));*/
		Thread.sleep(1000);
		JavascriptExecutor logout = (JavascriptExecutor) driver;
		logout.executeScript("arguments[0].click();", logoutIcon);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='Login to Powernoodle']")));
		int isLoginBtn = driver.findElements(By.xpath("//input[@value='Login to Powernoodle']")).size();
		if(isLoginBtn>0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean checkNoodleIconUnderTopic(String topic) throws Exception{
		//js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(1000);
		int isNoodleThere = driver.findElements(By.xpath("//h4[text()='"+topic+"']/following-sibling::ul[@class='activities']/li//span[contains(text(),'Noodle')]")).size();
		System.out.println(isNoodleThere);
		if(isNoodleThere>0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Boolean resetNoodling() throws Exception {
		Thread.sleep(1000);
		
		Actions actions = new Actions(driver);
		actions.moveToElement(resetNoodleBtn);
		
		actions.click().perform();
		Thread.sleep(1500);
		//div[@class='dialog reset-steps confirm']/div[@id='dialogTitle']
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialog reset-steps confirm']/div[@id='dialogTitle']")));
		resetNoodleCloseBtnOfAlert.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		int countOfTiles = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[1]")).size();
		int noodlecircleisthere = driver.findElements(By.xpath("//ul[@id='stepMap']/li[@id='noodle']/div[@class='circle']")).size();		
		if(noodlecircleisthere>0 && countOfTiles>0) {
			noodleCircle.click();
			Thread.sleep(1000);
			actions.moveToElement(resetNoodleBtn);
			
			actions.click().perform();
			Thread.sleep(1500);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialog reset-steps confirm']/div[@id='dialogTitle']")));
			confirmBtnItResetNoodleAlert.click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			Thread.sleep(1000);
			int countOfTilesAfterReset = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[1]")).size();
			if(countOfTilesAfterReset==0) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	
	public boolean addFileForTile(String filename) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		File file= new File(System.getProperty("user.dir") + "/Files/"+filename);
		String filepath = file.getAbsolutePath();
		addFile.sendKeys(filepath);
		
		Thread.sleep(4000);
		if(driver.findElements(By.xpath("//div[@class='error']/p[@class='message']/button[@class='ok']")).size()>0) {
			driver.findElement(By.xpath("//div[@class='error']/p[@class='message']/button[@class='ok']")).click();
			
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			Thread.sleep(1000);
			return false;
		}
		else {
		
		
		int isFileExist = driver.findElements(By.xpath("//div[@class='file locked']//a[contains(text(),'"+filename+"')]")).size();
		
		if(isFileExist>0) {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			Thread.sleep(1000);
			return true;
		}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			Thread.sleep(1000);
			return false;
		}
		}
	}
	
	public boolean addNamesForFile(String filename, String filedescription, String filenametoadd) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		if(driver.findElements(By.xpath("//div[@class='file locked']//a[contains(text(),'"+filename+"')]/following-sibling::div[@class='controls']/button[2]")).size()>0)
		{
			driver.findElement(By.xpath("//div[@class='file locked']//a[contains(text(),'"+filename+"')]/following-sibling::div[@class='controls']/button[2]")).click();
			Thread.sleep(1000);
			JavascriptExecutor fd = (JavascriptExecutor) driver;
			fd.executeScript("arguments[0].click();", fileDesc);
			fileDesc.sendKeys(filedescription);
			
			JavascriptExecutor fn = (JavascriptExecutor) driver;
			fn.executeScript("arguments[0].click();", fileNameOwn);
			fileNameOwn.sendKeys(filenametoadd);
			
			JavascriptExecutor pbtn = (JavascriptExecutor) driver;
			pbtn.executeScript("arguments[0].click();", postFileNameBtn);
			
			Thread.sleep(2000);
			int isFileDesc = driver.findElements(By.xpath("//div[@class='file locked']//a[contains(text(),'"+filename+"')]/parent::div/following-sibling::p")).size();
			if(isFileDesc>0) {
				dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
				Thread.sleep(1000);
				return true;
			}
			else {
				dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
				Thread.sleep(1000);
				return false;
			}
			
			
			}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			Thread.sleep(1000);
			return false;
		}
		}
	
	public boolean deleteAFile(String filename) throws Exception{
		Thread.sleep(1000);
		JavascriptExecutor dialogueClose = (JavascriptExecutor) driver;
		if(driver.findElements(By.xpath("//div[@class='file locked']//a[contains(text(),'"+filename+"')]/following-sibling::div[@class='controls']/button[1]")).size()>0)
		{
			driver.findElement(By.xpath("//div[@class='file locked']//a[contains(text(),'"+filename+"')]/following-sibling::div[@class='controls']/button[1]")).click();
			Thread.sleep(1000);
			JavascriptExecutor deleteFile = (JavascriptExecutor) driver;
			deleteFile.executeScript("arguments[0].click();", postFileNameBtn);
			
			
			Thread.sleep(2000);
			int isFileDesc = driver.findElements(By.xpath("//div[@class='file locked']//a[contains(text(),'"+filename+"')]")).size();
			if(isFileDesc==0) {
				dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
				Thread.sleep(1000);
				return true;
			}
			else {
				dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
				Thread.sleep(1000);
				return false;
			}
			
			
			}
		else {
			dialogueClose.executeScript("arguments[0].click();", dialogueCloseBtn);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
			Thread.sleep(1000);
			return false;
		}
		}
	
	public boolean editInstruction(String textToEdit) throws Exception{
		Thread.sleep(1000);
		
		editInstructionIcon.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='Participant']")));
		JavascriptExecutor participantarea = (JavascriptExecutor) driver;
		participantarea.executeScript("arguments[0].click();", participantTextArea);
		participantTextArea.sendKeys(Keys.END);
		participantTextArea.sendKeys(Keys.ENTER);
		participantTextArea.sendKeys(textToEdit);
		participantTextArea.sendKeys(Keys.ENTER);
		JavascriptExecutor okbtnedit = (JavascriptExecutor) driver;
		okbtnedit.executeScript("arguments[0].click();", editInstructionOKButton);
		Thread.sleep(1000);
		JavascriptExecutor tickmarkinresetnoodle = (JavascriptExecutor) driver;
		tickmarkinresetnoodle.executeScript("arguments[0].click();", tickOfResetNoodle);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		JavascriptExecutor ins = (JavascriptExecutor) driver;
		ins.executeScript("arguments[0].click();", instructionIcon);
		
		Thread.sleep(1000);
		int iseditedTextthere = driver.findElements(By.xpath("//div[@id='instructions-part']/em/p[text()='"+textToEdit+"']")).size();

		if(iseditedTextthere>0) {
			return true;
		}
		
		else {
			return false;
		}
		
		
		
	}
	
	public boolean addhyperLinkInInstruction(String text,String url) throws Exception{
		editInstructionIcon.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='Participant']")));
		JavascriptExecutor participantarea = (JavascriptExecutor) driver;
		participantarea.executeScript("arguments[0].click();", participantTextArea);
		participantTextArea.sendKeys(Keys.END);
		participantTextArea.sendKeys(Keys.ENTER);
		participantTextArea.sendKeys(text);
		participantTextArea.sendKeys(Keys.ENTER);
		
		WebElement textToAddLink = driver.findElement(By.xpath("//span[text()='"+text+"']"));
		
		Actions actions = new Actions(driver);
		
		actions.doubleClick(textToAddLink).perform();
		Thread.sleep(200);
		hyperlinkIcon.click();
		
		Thread.sleep(2000);
		JavascriptExecutor urltb = (JavascriptExecutor) driver;
		urltb.executeScript("arguments[0].click();", addUrlTextbox);
		urltb.executeScript("arguments[0].value='"+url+"';", addUrlTextbox);
		Thread.sleep(500);
		
		tickMarkInAddUrl.click();
		
		Thread.sleep(1500);
		JavascriptExecutor okbtnedit = (JavascriptExecutor) driver;
		okbtnedit.executeScript("arguments[0].click();", editInstructionOKButton);
		Thread.sleep(1000);
		JavascriptExecutor tickmarkinresetnoodle = (JavascriptExecutor) driver;
		tickmarkinresetnoodle.executeScript("arguments[0].click();", tickOfResetNoodle);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		JavascriptExecutor ins = (JavascriptExecutor) driver;
		ins.executeScript("arguments[0].click();", instructionIcon);
		
		Thread.sleep(1000);
		int iseditedTextthere = driver.findElements(By.xpath("//div[@id='instructions-part']/em/p/a[text()='"+text+"']")).size();

		if(iseditedTextthere>0) {
			driver.findElement(By.xpath("//div[@id='instructions-part']/em/p/a[text()='"+text+"']")).click();
			Thread.sleep(2000);
			ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs2.get(1));
			Thread.sleep(2000);
			String link = driver.getCurrentUrl();
			if(link.contains(url)) {
				driver.switchTo().window(tabs2.get(1));
				Thread.sleep(1000);
				return true;
			}
			else {
				System.out.println("inside else block");
				driver.switchTo().window(tabs2.get(1));
				Thread.sleep(1000);
				return false;
			}
		}
		
		else {
			return false;
		}
		
	}
	
	public boolean addbulletsInInstruction(String text) throws Exception{
		editInstructionIcon.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='Participant']")));
		JavascriptExecutor participantarea = (JavascriptExecutor) driver;
		participantarea.executeScript("arguments[0].click();", participantTextArea);
		participantTextArea.sendKeys(Keys.END);
		participantTextArea.sendKeys(Keys.ENTER);
		participantTextArea.sendKeys(text);
		participantTextArea.sendKeys(Keys.ENTER);
		
		WebElement textToAddLink = driver.findElement(By.xpath("//span[text()='"+text+"']"));
		
		Actions actions = new Actions(driver);
		
		actions.doubleClick(textToAddLink).perform();
		Thread.sleep(200);
		dotBulletIcon.click();
				
		Thread.sleep(1500);
		JavascriptExecutor okbtnedit = (JavascriptExecutor) driver;
		okbtnedit.executeScript("arguments[0].click();", editInstructionOKButton);
		Thread.sleep(1000);
		JavascriptExecutor tickmarkinresetnoodle = (JavascriptExecutor) driver;
		tickmarkinresetnoodle.executeScript("arguments[0].click();", tickOfResetNoodle);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		JavascriptExecutor ins = (JavascriptExecutor) driver;
		ins.executeScript("arguments[0].click();", instructionIcon);
		
		Thread.sleep(1000);
		int iseditedTextthere = driver.findElements(By.xpath("//ul/li[text()='"+text+"']")).size();

		if(iseditedTextthere>0) {
			
				return true;
			
			
		}
		
		else {
			return false;
		}
		
	}
	
	public boolean boldTextInInstruction(String text) throws Exception{
		editInstructionIcon.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='Participant']")));
		JavascriptExecutor participantarea = (JavascriptExecutor) driver;
		participantarea.executeScript("arguments[0].click();", participantTextArea);
		participantTextArea.sendKeys(Keys.END);
		participantTextArea.sendKeys(Keys.ENTER);
		participantTextArea.sendKeys(text);
		participantTextArea.sendKeys(Keys.ENTER);
		
		WebElement textToAddLink = driver.findElement(By.xpath("//span[text()='"+text+"']"));
		
		Actions actions = new Actions(driver);
		
		actions.doubleClick(textToAddLink).perform();
		Thread.sleep(200);
		boldIcon.click();
				
		Thread.sleep(1500);
		JavascriptExecutor okbtnedit = (JavascriptExecutor) driver;
		okbtnedit.executeScript("arguments[0].click();", editInstructionOKButton);
		Thread.sleep(1000);
		JavascriptExecutor tickmarkinresetnoodle = (JavascriptExecutor) driver;
		tickmarkinresetnoodle.executeScript("arguments[0].click();", tickOfResetNoodle);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		JavascriptExecutor ins = (JavascriptExecutor) driver;
		ins.executeScript("arguments[0].click();", instructionIcon);
		//div[@id='instructions-part']/em/p
		Thread.sleep(1000);
		int iseditedTextthere = driver.findElements(By.xpath("//strong[text()='"+text+"']")).size();

		if(iseditedTextthere>0) {
			
				return true;
			
			
		}
		
		else {
			return false;
		}
		
	}
	
	public boolean italicTextInInstruction(String text) throws Exception{
		editInstructionIcon.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='Participant']")));
		JavascriptExecutor participantarea = (JavascriptExecutor) driver;
		participantarea.executeScript("arguments[0].click();", participantTextArea);
		participantTextArea.sendKeys(Keys.END);
		participantTextArea.sendKeys(Keys.ENTER);
		participantTextArea.sendKeys(text);
		participantTextArea.sendKeys(Keys.ENTER);
		
		WebElement textToAddLink = driver.findElement(By.xpath("//span[text()='"+text+"']"));
		
		Actions actions = new Actions(driver);
		
		actions.doubleClick(textToAddLink).perform();
		Thread.sleep(200);
		italicIcon.click();
				
		Thread.sleep(1500);
		JavascriptExecutor okbtnedit = (JavascriptExecutor) driver;
		okbtnedit.executeScript("arguments[0].click();", editInstructionOKButton);
		Thread.sleep(1000);
		JavascriptExecutor tickmarkinresetnoodle = (JavascriptExecutor) driver;
		tickmarkinresetnoodle.executeScript("arguments[0].click();", tickOfResetNoodle);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		JavascriptExecutor ins = (JavascriptExecutor) driver;
		ins.executeScript("arguments[0].click();", instructionIcon);
		
		Thread.sleep(1000);
		int iseditedTextthere = driver.findElements(By.xpath("//div[@id='instructions-part']/em/p/em[text()='"+text+"']")).size();

		if(iseditedTextthere>0) {
			
				return true;
			
			
		}
		
		else {
			return false;
		}
		
	}
	
	public boolean underlineTextInInstruction(String text) throws Exception{
		editInstructionIcon.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='Participant']")));
		JavascriptExecutor participantarea = (JavascriptExecutor) driver;
		participantarea.executeScript("arguments[0].click();", participantTextArea);
		participantTextArea.sendKeys(Keys.END);
		participantTextArea.sendKeys(Keys.ENTER);
		participantTextArea.sendKeys(text);
		participantTextArea.sendKeys(Keys.ENTER);
		
		WebElement textToAddLink = driver.findElement(By.xpath("//span[text()='"+text+"']"));
		
		Actions actions = new Actions(driver);
		
		actions.doubleClick(textToAddLink).perform();
		Thread.sleep(200);
		underlineIcon.click();
				
		Thread.sleep(1500);
		JavascriptExecutor okbtnedit = (JavascriptExecutor) driver;
		okbtnedit.executeScript("arguments[0].click();", editInstructionOKButton);
		Thread.sleep(1000);
		JavascriptExecutor tickmarkinresetnoodle = (JavascriptExecutor) driver;
		tickmarkinresetnoodle.executeScript("arguments[0].click();", tickOfResetNoodle);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		JavascriptExecutor ins = (JavascriptExecutor) driver;
		ins.executeScript("arguments[0].click();", instructionIcon);
		
		Thread.sleep(1000);
		int iseditedTextthere = driver.findElements(By.xpath("//div[@id='instructions-part']/em/p/u[text()='"+text+"']")).size();

		if(iseditedTextthere>0) {
			
				return true;
			
			
		}
		
		else {
			return false;
		}
		
	}
	
	public boolean setOwnerTileVisibility() throws Exception{
		Thread.sleep(1000);
		tileVisibilityOwnerBtn.click();
		Thread.sleep(1000);
		JavascriptExecutor tickmarkinresetnoodle = (JavascriptExecutor) driver;
		tickmarkinresetnoodle.executeScript("arguments[0].click();", tickOfResetNoodle);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		Thread.sleep(1000);
		JavascriptExecutor logout = (JavascriptExecutor) driver;
		logout.executeScript("arguments[0].click();", logoutIcon);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='Login to Powernoodle']")));
		int isLoginBtn = driver.findElements(By.xpath("//input[@value='Login to Powernoodle']")).size();
		if(isLoginBtn>0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean setAllTileVisibility() throws Exception{
		Thread.sleep(1000);
		tileVisibilityAllBtn.click();
		Thread.sleep(1000);
		JavascriptExecutor tickmarkinresetnoodle = (JavascriptExecutor) driver;
		tickmarkinresetnoodle.executeScript("arguments[0].click();", tickOfResetNoodle);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addIdeaBtn")));
		Thread.sleep(1000);
		JavascriptExecutor logout = (JavascriptExecutor) driver;
		logout.executeScript("arguments[0].click();", logoutIcon);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='Login to Powernoodle']")));
		int isLoginBtn = driver.findElements(By.xpath("//input[@value='Login to Powernoodle']")).size();
		if(isLoginBtn>0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
	public boolean setaddtileVisibilityNo() throws Exception{
		Thread.sleep(1000);
		addTilesVisibilityNo.click();
		Thread.sleep(1000);
		JavascriptExecutor tickmarkinresetnoodle = (JavascriptExecutor) driver;
		tickmarkinresetnoodle.executeScript("arguments[0].click();", tickOfResetNoodle);
		Thread.sleep(2000);
		int isAddTile = driver.findElements(By.id("addIdeaBtn")).size();
		if(isAddTile==0) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	public boolean setaddtileVisibilityYes() throws Exception{
		Thread.sleep(1000);
		/*JavascriptExecutor at = (JavascriptExecutor) driver;
		at.executeScript("arguments[0].click();", addTilesVisibilityYes);*/
		addTilesVisibilityYes.click();
		Thread.sleep(1000);
		JavascriptExecutor tickmarkinresetnoodle = (JavascriptExecutor) driver;
		tickmarkinresetnoodle.executeScript("arguments[0].click();", tickOfResetNoodle);
		Thread.sleep(2000);
		driver.navigate().refresh();
		Thread.sleep(1000);
		int isAddTile = driver.findElements(By.id("addIdeaBtn")).size();
		if(isAddTile>0) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	public Boolean testListStyleOfTiles() throws Exception{
		listStyleIcon.click();
		Thread.sleep(1000);
		JavascriptExecutor tickmarkinresetnoodle = (JavascriptExecutor) driver;
		tickmarkinresetnoodle.executeScript("arguments[0].click();", tickOfResetNoodle);
		Thread.sleep(1500);
		int isTileListThere = driver.findElements(By.xpath("//div[@class='grid-layout list']")).size();
		if(isTileListThere>0) {
			return true;
		}
		
		else {
			return false;
		}
	}
	
	public Boolean testTileStyleOfTiles() throws Exception{
		JavascriptExecutor ts = (JavascriptExecutor) driver;
		ts.executeScript("arguments[0].click();", tileStyleIcon);
		//tileStyleIcon.click();
		Thread.sleep(1000);
		JavascriptExecutor tickmarkinresetnoodle = (JavascriptExecutor) driver;
		tickmarkinresetnoodle.executeScript("arguments[0].click();", tickOfResetNoodle);
		Thread.sleep(1500);
		int isTileListThere = driver.findElements(By.xpath("//div[@class='grid-layout list']")).size();
		if(isTileListThere==0) {
			return true;
		}
		
		else {
			return false;
		}
	}
	
	
	public int setcommentVisibilityOwners(String tileno) throws Exception{
		Thread.sleep(1000);
		
		commentVisibilityOwners.click();
		Thread.sleep(1000);
		JavascriptExecutor tickmarkinresetnoodle = (JavascriptExecutor) driver;
		tickmarkinresetnoodle.executeScript("arguments[0].click();", tickOfResetNoodle);
		Thread.sleep(1500);
		
		String commentNumOnTileAfterReset = driver.findElement(By.xpath("//div[@class='ideaTxt']/span[1][contains(text(),'"+tileno+"')]/parent::div/following-sibling::div/div[@class='commentsNumber ideaComments']")).getText();
		
			int commentcount = Integer.parseInt(commentNumOnTileAfterReset);
			return commentcount;
		
	}
	
	public int setcommentVisibilityAll(String tileno) throws Exception{
		Thread.sleep(1000);
		
		commentVisibilityOwners.click();
		Thread.sleep(1000);
		JavascriptExecutor tickmarkinresetnoodle = (JavascriptExecutor) driver;
		tickmarkinresetnoodle.executeScript("arguments[0].click();", tickOfResetNoodle);
		Thread.sleep(1500);
		
		String commentNumOnTileAfterReset = driver.findElement(By.xpath("//div[@class='ideaTxt']/span[1][contains(text(),'"+tileno+"')]/parent::div/following-sibling::div/div[@class='commentsNumber ideaComments']")).getText();
		
			int commentcount = Integer.parseInt(commentNumOnTileAfterReset);
			return commentcount;
		
	}
	
	public int takeCommentCountOfATile(String tileno) throws Exception{
		Thread.sleep(1000);
		String commentNumOnTileAfterReset = driver.findElement(By.xpath("//div[@class='ideaTxt']/span[1][contains(text(),'"+tileno+"')]/parent::div/following-sibling::div/div[@class='commentsNumber ideaComments']")).getText();
		
		int commentcount = Integer.parseInt(commentNumOnTileAfterReset);
		return commentcount;
		
	}
	
	public boolean tileStatus(String tileno) throws Exception{
		Thread.sleep(1000);
		int tilesize = driver.findElements(By.xpath("//div[@class='idea']//span[text()='"+tileno+"']")).size();
		if(tilesize>0) {
			System.out.println("tile is there");
			return true;
		}
		else {
			System.out.println("tile is not there");
			return false;
		}
	}










}
