package com.pageobjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Base.Testbase;

public class TagActivityPage extends Testbase {

	
	//********************open tagging**********************************
	@FindBy(id = "ds-topic-title")
	WebElement newTopicTextbox;
	
	@FindBy(id = "add-activity-btn")
	WebElement addTopicBtn;
	
	@FindBy(xpath = "//button[@id='open-btn']")
	WebElement openTagBtn;
	
	@FindBy(id= "dialog-close-btn")
	WebElement tickMarkOfActionSettings;
	
	//*************************Instruction panel****************************
	@FindBy(id = "instructions-btn")
	WebElement instructionPanelMenu;
	
	@FindBy(xpath="//div[@id='sub-menu']//a")
	List<WebElement> defaultLinksInInstructions;
	
	@FindBy(xpath = "//iframe[@class='pnvideo']")
	WebElement videoFrame;
	
	@FindBy(xpath = "//label[@for='participant_done']")
	WebElement iamDoneCheckBox;
	
	@FindBy(id="total_participants_done")
	WebElement iamDoneCount;
	
	@FindBy(id="switch-topics-btn")
	WebElement switchToTopicBtn;
	
	//****************************Edit instruction panel ************************
	@FindBy(id = "activity-settings-btn")
	WebElement activitySettingsMenu;
	
	@FindBy(xpath = "//ul[@id='stepMap']/li/h2[text()='Tag']")
	WebElement tagSettingsMenu;
	
	@FindBy(xpath = "//button[@id='instructions-btn']")
	WebElement editInstructionButton;
	
	@FindBy(xpath = "//h3[text()='Participant']/following-sibling::div//div[@role='textbox']")
	WebElement editParticipantInstructionTextbox;
	
	@FindBy(id= "dialog-close-ok-btn")
	WebElement editInstructionTickMark;
	
	@FindBy(xpath = "//button[@class='tools '][text()='B']")
	WebElement boldMenu;
	
	@FindBy(xpath = "//button[@class='tools '][text()='I']")
	WebElement italicMenu;
	
	@FindBy(xpath = "//button[@class='tools '][text()='U']")
	WebElement underlineMenu;
	
	@FindBy(xpath = "//button[@class='tools '][text()='•']")
	WebElement dotBulletMenu;
	
	@FindBy(xpath = "//button[@class='tools '][text()='1.']")
	WebElement numberBulletMenu;
	
	@FindBy(xpath = "//button[text()='#']")
	WebElement hyperlinkMenuMenu;
	
	@FindBy(xpath = "//input[@placeholder='paste or type a link']")
	WebElement addLinkTextbox;
	
	@FindBy(xpath = "//button[@class='edit glyphicon glyphicon-ok']")
	WebElement addLinkTickmark;
	
	//**********************************Settings panel*********************************
	//Show or hide tag settings
	
	@FindBy(xpath = "//label[@id='step_lbl_enabled']")
	WebElement showTagSettingsButton;
	
	@FindBy(xpath = "//label[@id='step_lbl_disabled']")
	WebElement hideTagSettingsButton;
	
	//Tile visibility settings
	@FindBy(xpath ="//label[@id='tile_visibility_lbl_owner']")
	WebElement ownerTileVisibilityButtonInTagSettings;
	
	@FindBy(xpath ="//label[@id='tile_visibility_lbl_all']")
	WebElement allTileVisibilityButtonInTagSettings;
	
	@FindBy(xpath ="//label[@id='setup_view_style_lbl_tile']")
	WebElement tileStyle;
	
	//Add tile option
	@FindBy(xpath ="//label[@id='hide_title_add_lbl_show']")
	WebElement yesInAddTileTagSettings;
	
	@FindBy(xpath ="//label[@id='hide_title_add_lbl_hide']")
	WebElement noInAddTileTagSettings;
	
	//Tags on tile front
	@FindBy(xpath ="//label[@id='hide_tag_lbl_true']")
	WebElement showTagsOnTileFrontSettings;
		
	@FindBy(xpath ="//label[@id='hide_tag_lbl_false']")
	WebElement hideTagsOnTileFrontSettings;
	
	//View style
	@FindBy(xpath ="//label[@id='setup_view_style_lbl_list']")
	WebElement listStyleSettings;
			
	@FindBy(xpath ="//label[@id='setup_view_style_lbl_tile']")
	WebElement tileStyleSettings;
	
	//Cooment visibility
	@FindBy(xpath = "//div[@class='add-comment']//div[@role='textbox']")
	WebElement writeACommentTextBox;
	
	@FindBy(xpath = "//button[contains(text(),'Post')]")
	WebElement postcommentButton;
	
	
	@FindBy(xpath ="//label[@id='hide_comments_lbl_show']")
	WebElement allCommentVisibility;
			
	@FindBy(xpath ="//label[@id='hide_comments_lbl_hide']")
	WebElement ownerCommentVisibility;
	
	//File visibility
	@FindBy(xpath ="//label[@id='hide_files_lbl_show']")
	WebElement showFileSettings;
				
	@FindBy(xpath ="//label[@id='hide_files_lbl_hide']")
	WebElement hideFileSettings;
	
	//Tagging ability
	@FindBy(xpath ="//label[@id='everyone_tags_lbl_yes']")
	WebElement allTaggingAbilityButton;
					
	@FindBy(xpath ="//label[@id='everyone_tags_lbl_no']")
	WebElement ownerTaggingAbilityButton;
	
	//Default sort order
	@FindBy(xpath ="//label[@for='sort_ascend_alpha']")
	WebElement alphaAscendingDefaultButton;
					
	@FindBy(xpath ="//label[@for='sort_descend_alpha']")
	WebElement alphaDescendingDefaultButton;
	
	@FindBy(xpath ="//label[@for='sort_ascend']")
	WebElement numericAscendingDefaultButton;
	
	@FindBy(xpath ="//label[@for='sort_descend']")
	WebElement numericDescendingDefaultButton;
	
	@FindBy(xpath ="//label[@for='sort_shuffle']")
	WebElement shuffleOrderDefaultButton;
	
	//**********************************Create tags and groups*********************************
		//Add tag group
		
	@FindBy(id = "add-tag-group-btn")
	WebElement addTagGroupButton;
		
	@FindBy(xpath = "//input[@placeholder='group name'][@value='']")
	WebElement emptyGroupnameTextbox;
	
	//Pick many and pick one tag
	
	@FindBy(xpath="//label[text()='Pick One']")
	List<WebElement> pickoneLabels;
	
	
	public TagActivityPage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}
	
	WebDriverWait wait = new WebDriverWait(driver, 40);
	JavascriptExecutor closeTickMark = (JavascriptExecutor) driver;
	
	public boolean addNewTopic(String topicname) throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ds-topic-title")));
		newTopicTextbox.sendKeys(topicname);
		Thread.sleep(1000);
		addTopicBtn.click();
		Thread.sleep(2000);
		
		
		int topicCount = driver.findElements(By.xpath("//ul[@id='questions']/li//input[@value='"+topicname+"']")).size();
		if(topicCount>0) {
			System.out.println("Topic added correctly");
			return true;
		}
		else {
			System.out.println("Topic not yet added in the list");
			return false;
		}
	}
	
	public boolean openTagActivityForATopic(String topic) throws Exception{
		
		
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li//button[contains(text(), 'Tag Settings')]")));
		WebElement ta = driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li//button[contains(text(), 'Tag Settings')]"));
		JavascriptExecutor eb = (JavascriptExecutor) driver;
		eb.executeScript("arguments[0].click();", ta);
		Thread.sleep(2000);
		
		int isopenTagthere = driver.findElements(By.xpath("//button[@id='open-btn']")).size();
		if(isopenTagthere>0) {
			openTagBtn.click();
		}
		else {
			System.out.println("Already the tag activity is opened for this topic");
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		}
		
		Thread.sleep(2000);
		
		int isTagEnabled = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'organizer tag active')]//span[text()= 'Tag']")).size();	
		if(isTagEnabled>0) {
			WebElement tagBtn = driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'organizer tag active')]//span[text()= 'Tag']"));
			JavascriptExecutor tb = (JavascriptExecutor) driver;
			tb.executeScript("arguments[0].click();", tagBtn);
			Thread.sleep(2000);
			int istagtitle = driver.findElements(By.xpath("//h3[text()='tag: ']")).size();
			if(istagtitle>0) {
				return true;
			}
			else {
				System.out.println("Tag page is not displayed");
				return false;
			}
		}
		else {
			System.out.println("Tag button is not clickable");
			return false;
		}
		
	}
	
	public boolean facilitatorClicksTagActivity(String topic) throws Exception{
		
		Thread.sleep(2000);
		int isTagEnabled = driver.findElements(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'organizer tag active')]//span[text()= 'Tag']")).size();	
		if(isTagEnabled>0) {
			WebElement tagBtn = driver.findElement(By.xpath("//input[@value='"+topic+"']/ancestor::div/following-sibling::ul[@class='activities']/li[contains(@class,'organizer tag active')]//span[text()= 'Tag']"));
			JavascriptExecutor ab = (JavascriptExecutor) driver;
			ab.executeScript("arguments[0].click();", tagBtn);
			Thread.sleep(2000);
			int istagtitle = driver.findElements(By.xpath("//h3[text()='tag: ']")).size();
			if(istagtitle>0) {
				return true;
			}
			else {
				System.out.println("Tag page is not displayed");
				return false;
			}
		}
		else {
			System.out.println("Tag button is not clickable");
			return false;
		}
	}
	
	public boolean participantClicksTagActivity(String topic) throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Home')]")));
				
		int isTagEnabled = driver.findElements(By.xpath("//li/h4[text()='"+topic+"']/following-sibling::ul[@class='activities']/li[@class='tag active']//span[text()= 'Tag']")).size();	
		if(isTagEnabled>0) {
			WebElement tagBtn = driver.findElement(By.xpath("//li/h4[text()='"+topic+"']/following-sibling::ul[@class='activities']/li[@class='tag active']//span[text()= 'Tag']"));
			JavascriptExecutor tb = (JavascriptExecutor) driver;
			tb.executeScript("arguments[0].click();", tagBtn);
			Thread.sleep(2000);
			int istagtitle = driver.findElements(By.xpath("//h3[text()='tag: ']")).size();
			if(istagtitle>0) {
				return true;
			}
			else {
				System.out.println("Tag page is not displayed");
				return false;
			}
		}
		else {
			System.out.println("Tag button is not clickable");
			return false;
		}
	}
	
	public Boolean checkInstructionsOfFacilitator() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		int isInstructionThere = driver.findElements(By.xpath("//div[@id='sub-menu'][contains(@style,'365px')]")).size();
		if(isInstructionThere<=0) {
			
			JavascriptExecutor ip = (JavascriptExecutor) driver;
			ip.executeScript("arguments[0].click();", instructionPanelMenu);
			
		}
		Thread.sleep(2000);
		int firstTitle = driver.findElements(By.xpath("//div[@id='sub-menu']//h3[text()='Instructions']")).size();
		int infoUnderFirstTitle = driver.findElements(By.xpath("//div[@id='sub-menu']//div[@id='instructions-part']")).size();
		
		int secondTitle = driver.findElements(By.xpath("//div[@id='sub-menu']//h3[text()='Facilitator Instructions']")).size();
		int infoUnderSecondTitle = driver.findElements(By.xpath("//div[@id='sub-menu']//div[@id='instructions-org']")).size();
		
		if(firstTitle>0 && infoUnderFirstTitle>0 && secondTitle>0 && infoUnderSecondTitle>0) {
			System.out.println("Instruction Panel displays the instructions correctly");
			return true;
		}
		
		else {
			System.out.println("Instruction Panel doesn't display the instructions correctly");
			return false;
		}
		
	}
	
	public Boolean checkInstructionsOfParticipant() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		int isInstructionThere = driver.findElements(By.xpath("//div[@id='sub-menu'][contains(@style,'365px')]")).size();
		if(isInstructionThere<=0) {
			
			JavascriptExecutor ip = (JavascriptExecutor) driver;
			ip.executeScript("arguments[0].click();", instructionPanelMenu);
			
		}
		Thread.sleep(2000);
		int firstTitle = driver.findElements(By.xpath("//div[@id='sub-menu']//h3[text()='Instructions']")).size();
		int infoUnderFirstTitle = driver.findElements(By.xpath("//div[@id='sub-menu']//div[@id='instructions-part']")).size();
		
		if(firstTitle>0 && infoUnderFirstTitle>0) {
			System.out.println("Instruction Panel displays the instructions correctly");
			return true;
		}
		
		else {
			System.out.println("Instruction Panel doesn't display the instructions correctly");
			return false;
		}
		
	}
	
	public boolean closeInstructionPanel() throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='sub-menu'][contains(@style,'365px')]")));
		Thread.sleep(1000);
		JavascriptExecutor ip = (JavascriptExecutor) driver;
		ip.executeScript("arguments[0].click();", instructionPanelMenu);
		
		Thread.sleep(1000);
		int firstTitle = driver.findElements(By.xpath("//div[@id='sub-menu'][contains(@style,'0px')]")).size();
		
		if(firstTitle>0) {
			System.out.println("Instruction Panel disappears immediately");
			return true;
		}
		else {
			System.out.println("Instruction Panel doesn't disappear from the page");
			return false;
		}
	}
	
	public Boolean checkHyperLinkInInstructions() throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		int isInstructionThere = driver.findElements(By.xpath("//div[@id='sub-menu'][contains(@style,'365px')]")).size();
		if(isInstructionThere<=0) {
			
			JavascriptExecutor ip = (JavascriptExecutor) driver;
			ip.executeScript("arguments[0].click();", instructionPanelMenu);
			
		}
		Thread.sleep(2000);
		int count = 0;
		for(int ii=0;ii<defaultLinksInInstructions.size();ii++) {
			defaultLinksInInstructions.get(ii).click();
			Thread.sleep(3000);
			
			ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs2.get(1));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Applications')]")));
			
			if (driver.findElements(By.xpath("//iframe[@class='pnvideo']")).size()>0) {
				driver.switchTo().window(tabs2.get(0));
				count++;
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='sub-menu'][contains(@style,'365px')]")));
			} else {
				driver.switchTo().window(tabs2.get(0));
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='sub-menu'][contains(@style,'365px')]")));
			}
		}
		
		if(count==defaultLinksInInstructions.size()) {
			System.out.println("Hyperlinks navigated the user to the new tabs");
			return true;
		}
		else {
			System.out.println("Hyperlinks didn't navigate the user to the new tabs respectively");
			return false;
		}
	}
	
	public int takeTotalDoneCount() throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(2000);
		int donecountInInt = Integer.parseInt(iamDoneCount.getText());
		return donecountInInt;
	}
	
	public void clickIamDoneCheckbox() throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		
		
		JavascriptExecutor iamdonebox = (JavascriptExecutor) driver;
		iamdonebox.executeScript("arguments[0].click();", iamDoneCheckBox);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'flash')]")));
	}
	
	public void switchForthAndBack(String topic) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		
		JavascriptExecutor switchbtn = (JavascriptExecutor) driver;
		switchbtn.executeScript("arguments[0].click();", switchToTopicBtn);
		
		Thread.sleep(1500);
		int isAnothertopicThere = driver.findElements(By.xpath("//div[@class='questions']//button[text()='Enter']")).size();
		if(isAnothertopicThere>0) {
			driver.findElement(By.xpath("//div[@class='questions']//button[text()='Enter']")).click();
			driver.navigate().refresh();
			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[contains(text(),': ')]")));
			Thread.sleep(1000);
			switchbtn.executeScript("arguments[0].click();", switchToTopicBtn);
			//switchToTopicBtn.click();
			Thread.sleep(1500);
			driver.findElement(By.xpath("//div[@class='questions']//div[text()='"+topic+"']/following-sibling::button[text()='Enter']")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		}
		
		else {
			System.out.println("There is no other topic in this decision space");
		}
	}
	
	public void goToEditTagInstruction() throws Exception {
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		
		JavascriptExecutor activitysettings = (JavascriptExecutor) driver;
		activitysettings.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1500);
		
		JavascriptExecutor tagsettings = (JavascriptExecutor) driver;
		tagsettings.executeScript("arguments[0].click();", tagSettingsMenu);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		Thread.sleep(500);
		
		
		JavascriptExecutor editinstructionbtn = (JavascriptExecutor) driver;
		editinstructionbtn.executeScript("arguments[0].click();", editInstructionButton);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='container-fluid instr-edit']")));
		Thread.sleep(1000);
		
	}
	
	public void addBoldTextInTagInstruction(String text) throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='container-fluid instr-edit']")));
		JavascriptExecutor editarea = (JavascriptExecutor) driver;
		editarea.executeScript("arguments[0].click();", editParticipantInstructionTextbox);
		Thread.sleep(2000);
		
		editParticipantInstructionTextbox.sendKeys(Keys.CONTROL,Keys.END);
		Thread.sleep(500);
		editParticipantInstructionTextbox.sendKeys(Keys.ENTER);
		Thread.sleep(500);
		editParticipantInstructionTextbox.sendKeys(text);
		Thread.sleep(500);
		//editParticipantInstructionTextbox.sendKeys(Keys.ENTER);
		List<WebElement> textsToAddBold = driver.findElements(By.xpath("//span[text()='"+text+"']"));
		int actualText = textsToAddBold.size()-1;
		WebElement textToAddBold = textsToAddBold.get(actualText);
		
		Actions actions = new Actions(driver);
		
		actions.doubleClick(textToAddBold).perform();
		Thread.sleep(500);
		JavascriptExecutor boldjs = (JavascriptExecutor) driver;
		
		if(driver.findElements(By.xpath("//button[@class='tools '][text()='B']")).size()>0) {
			
			boldjs.executeScript("arguments[0].click();", boldMenu);
		}
		else {
			WebElement boldedmenu = driver.findElement(By.xpath("//button[text()='B']"));
			boldjs.executeScript("arguments[0].click();", boldedmenu);
			Thread.sleep(500);
			boldjs.executeScript("arguments[0].click();", boldMenu);
		}
		
		
		Thread.sleep(1000);
		
		JavascriptExecutor editInstructionTickMarkjs = (JavascriptExecutor) driver;
		editInstructionTickMarkjs.executeScript("arguments[0].click();", editInstructionTickMark);
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
	}
	
	public boolean checkBoldedTextInTagInstructions(String text) throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		JavascriptExecutor ip = (JavascriptExecutor) driver;
		ip.executeScript("arguments[0].click();", instructionPanelMenu);
		Thread.sleep(1000);
		
		int isBoldedTextPresent = driver.findElements(By.xpath("//strong[text()='"+text+"']")).size();
		int isBoldedTextWithOtherFormatsPresent = driver.findElements(By.xpath("//strong//*[text()='"+text+"']")).size();
		if(isBoldedTextPresent>0 || isBoldedTextWithOtherFormatsPresent>0) {
			System.out.println("Bolded text is there");
			return true;
		}
		else {
			System.out.println("Bolded text is not there");
			return false;
		}
	}
	
	public void addItalicTextInTagInstruction(String text) throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='container-fluid instr-edit']")));
		JavascriptExecutor editarea = (JavascriptExecutor) driver;
		editarea.executeScript("arguments[0].click();", editParticipantInstructionTextbox);
		Thread.sleep(2000);
		
		editParticipantInstructionTextbox.sendKeys(Keys.CONTROL,Keys.END);
		Thread.sleep(500);
		editParticipantInstructionTextbox.sendKeys(Keys.ENTER);
		Thread.sleep(500);
		editParticipantInstructionTextbox.sendKeys(text);
		Thread.sleep(500);
		editParticipantInstructionTextbox.sendKeys(Keys.ENTER);
		List<WebElement> textsToAddItalic = driver.findElements(By.xpath("//span[text()='"+text+"']"));
		int actualText = textsToAddItalic.size()-1;
		WebElement textToAddItalic = textsToAddItalic.get(actualText);
		
		Actions actions = new Actions(driver);
		
		actions.doubleClick(textToAddItalic).perform();
		Thread.sleep(500);
		
		JavascriptExecutor italicjs = (JavascriptExecutor) driver;
		
		if(driver.findElements(By.xpath("//button[@class='tools '][text()='I']")).size()>0) {
			
			italicjs.executeScript("arguments[0].click();", italicMenu);
		}
		else {
			WebElement italicizedMenu = driver.findElement(By.xpath("//button[text()='I']"));
			italicjs.executeScript("arguments[0].click();", italicizedMenu);
			Thread.sleep(500);
			italicjs.executeScript("arguments[0].click();", italicMenu);
		}
		
		
		Thread.sleep(1000);
		
		JavascriptExecutor editInstructionTickMarkjs = (JavascriptExecutor) driver;
		editInstructionTickMarkjs.executeScript("arguments[0].click();", editInstructionTickMark);
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
	}
	
	public boolean checkItalicizedTextInTagInstructions(String text) throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		JavascriptExecutor ip = (JavascriptExecutor) driver;
		ip.executeScript("arguments[0].click();", instructionPanelMenu);
		Thread.sleep(1000);
		
		int isItalicizedTextPresent = driver.findElements(By.xpath("//em[text()='"+text+"']")).size();
		int isItalicizedTextWithSomeOtherFormatsPresent = driver.findElements(By.xpath("//em//*[text()='"+text+"']")).size();
		if(isItalicizedTextPresent>0 || isItalicizedTextWithSomeOtherFormatsPresent>0) {
			System.out.println("Italicized text is there");
			return true;
		}
		else {
			System.out.println("Italicized text is not there");
			return false;
		}
	}
	
	public void addUnderlineTextInTagInstruction(String text) throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='container-fluid instr-edit']")));
		JavascriptExecutor editarea = (JavascriptExecutor) driver;
		editarea.executeScript("arguments[0].click();", editParticipantInstructionTextbox);
		Thread.sleep(2000);
		
		editParticipantInstructionTextbox.sendKeys(Keys.CONTROL,Keys.END);
		Thread.sleep(500);
		editParticipantInstructionTextbox.sendKeys(Keys.ENTER);
		Thread.sleep(500);
		editParticipantInstructionTextbox.sendKeys(text);
		Thread.sleep(500);
		//editParticipantInstructionTextbox.sendKeys(Keys.ENTER);
		List<WebElement> textsToUnderline = driver.findElements(By.xpath("//span[text()='"+text+"']"));
		int actualText = textsToUnderline.size()-1;
		System.out.println(actualText);
		WebElement textToUnderline = textsToUnderline.get(actualText);
		
		Actions actions = new Actions(driver);
		
		actions.doubleClick(textToUnderline).perform();
		Thread.sleep(1000);
		
		JavascriptExecutor underlinejs = (JavascriptExecutor) driver;
		
		if(driver.findElements(By.xpath("//button[@class='tools '][text()='U']")).size()>0) {
			
			underlinejs.executeScript("arguments[0].click();", underlineMenu);
		}
		else {
			WebElement underlinedMenu = driver.findElement(By.xpath("//button[text()='U']"));
			underlinejs.executeScript("arguments[0].click();", underlinedMenu);
			Thread.sleep(500);
			underlinejs.executeScript("arguments[0].click();", underlineMenu);
		}
		
		
		Thread.sleep(1000);
		
		JavascriptExecutor editInstructionTickMarkjs = (JavascriptExecutor) driver;
		editInstructionTickMarkjs.executeScript("arguments[0].click();", editInstructionTickMark);
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
	}
	
	public boolean checkUnderlinedTextInTagInstructions(String text) throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		JavascriptExecutor ip = (JavascriptExecutor) driver;
		ip.executeScript("arguments[0].click();", instructionPanelMenu);
		Thread.sleep(1000);
		
		int isUnderlinedTextPresent = driver.findElements(By.xpath("//u[text()='"+text+"']")).size();
		int isUnderlinedTextWithSomeOtherFormatsPresent = driver.findElements(By.xpath("//u//*[text()='"+text+"']")).size();
		if(isUnderlinedTextPresent>0 || isUnderlinedTextWithSomeOtherFormatsPresent>0) {
			System.out.println("Unterlined text is there");
			return true;
		}
		else {
			System.out.println("Underlined text is not there");
			return false;
		}
	}
	
	public void addDotBulletTextInTagInstruction(String text) throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='container-fluid instr-edit']")));
		JavascriptExecutor editarea = (JavascriptExecutor) driver;
		editarea.executeScript("arguments[0].click();", editParticipantInstructionTextbox);
		Thread.sleep(2000);
		
		editParticipantInstructionTextbox.sendKeys(Keys.CONTROL,Keys.END);
		Thread.sleep(500);
		editParticipantInstructionTextbox.sendKeys(Keys.ENTER);
		Thread.sleep(500);
		editParticipantInstructionTextbox.sendKeys(text);
		Thread.sleep(500);
		editParticipantInstructionTextbox.sendKeys(Keys.ENTER);
		List<WebElement> textsToAddBullet = driver.findElements(By.xpath("//span[text()='"+text+"']"));
		int actualText = textsToAddBullet.size()-1;
		System.out.println(actualText);
		WebElement textToAddBullets = textsToAddBullet.get(actualText);
		
		Actions actions = new Actions(driver);
		
		actions.doubleClick(textToAddBullets).perform();
		Thread.sleep(1000);
		
		JavascriptExecutor bulletjs = (JavascriptExecutor) driver;
		
		if(driver.findElements(By.xpath("//button[@class='tools '][text()='•']")).size()>0) {
			
			bulletjs.executeScript("arguments[0].click();", dotBulletMenu);
		}
		else {
			WebElement bulletedMenu = driver.findElement(By.xpath("//button[text()='•']"));
			bulletjs.executeScript("arguments[0].click();", bulletedMenu);
			Thread.sleep(500);
			bulletjs.executeScript("arguments[0].click();", dotBulletMenu);
		}
		
		
		Thread.sleep(1000);
		
		JavascriptExecutor editInstructionTickMarkjs = (JavascriptExecutor) driver;
		editInstructionTickMarkjs.executeScript("arguments[0].click();", editInstructionTickMark);
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
	}
	
	public boolean checkDotBulletedTextInTagInstructions(String text) throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		JavascriptExecutor ip = (JavascriptExecutor) driver;
		ip.executeScript("arguments[0].click();", instructionPanelMenu);
		Thread.sleep(1000);
		
		int isDotBulletedTextPresent = driver.findElements(By.xpath("//ul//*[text()='"+text+"']")).size();
		
		if(isDotBulletedTextPresent>0) {
			System.out.println("Bulleted text is there");
			return true;
		}
		else {
			System.out.println("Bulleted text is not there");
			return false;
		}
	}
	
	public void addNumberBulletTextInTagInstruction(String text) throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='container-fluid instr-edit']")));
		JavascriptExecutor editarea = (JavascriptExecutor) driver;
		editarea.executeScript("arguments[0].click();", editParticipantInstructionTextbox);
		Thread.sleep(2000);
		
		editParticipantInstructionTextbox.sendKeys(Keys.CONTROL,Keys.END);
		Thread.sleep(500);
		editParticipantInstructionTextbox.sendKeys(Keys.ENTER);
		Thread.sleep(500);
		editParticipantInstructionTextbox.sendKeys(text);
		Thread.sleep(500);
		editParticipantInstructionTextbox.sendKeys(Keys.ENTER);
		List<WebElement> textsToAddBullet = driver.findElements(By.xpath("//span[text()='"+text+"']"));
		int actualText = textsToAddBullet.size()-1;
		System.out.println(actualText);
		WebElement textToAddBullets = textsToAddBullet.get(actualText);
		
		Actions actions = new Actions(driver);
		
		actions.doubleClick(textToAddBullets).perform();
		Thread.sleep(500);
		
		JavascriptExecutor bulletjs = (JavascriptExecutor) driver;
		
		if(driver.findElements(By.xpath("//button[@class='tools '][text()='1.']")).size()>0) {
			
			bulletjs.executeScript("arguments[0].click();", numberBulletMenu);
		}
		else {
			WebElement bulletedMenu = driver.findElement(By.xpath("//button[text()='1.']"));
			bulletjs.executeScript("arguments[0].click();", bulletedMenu);
			Thread.sleep(500);
			bulletjs.executeScript("arguments[0].click();", numberBulletMenu);
		}
		
		
		Thread.sleep(1000);
		
		JavascriptExecutor editInstructionTickMarkjs = (JavascriptExecutor) driver;
		editInstructionTickMarkjs.executeScript("arguments[0].click();", editInstructionTickMark);
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
	}
	
	public boolean checkNumberBulletedTextInTagInstructions(String text) throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		JavascriptExecutor ip = (JavascriptExecutor) driver;
		ip.executeScript("arguments[0].click();", instructionPanelMenu);
		Thread.sleep(1000);
		
		int isNumberBulletedTextPresent = driver.findElements(By.xpath("//ol//*[text()='"+text+"']")).size();
		
		if(isNumberBulletedTextPresent>0) {
			System.out.println("Bulleted text is there");
			return true;
		}
		else {
			System.out.println("Bulleted text is not there");
			return false;
		}
	}
	
	public void addHyperlinkInTagInstruction(String text, String link) throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='container-fluid instr-edit']")));
		JavascriptExecutor editarea = (JavascriptExecutor) driver;
		editarea.executeScript("arguments[0].click();", editParticipantInstructionTextbox);
		Thread.sleep(2000);
		
		editParticipantInstructionTextbox.sendKeys(Keys.CONTROL,Keys.END);
		Thread.sleep(500);
		editParticipantInstructionTextbox.sendKeys(Keys.ENTER);
		Thread.sleep(500);
		editParticipantInstructionTextbox.sendKeys(text);
		Thread.sleep(500);
		//editParticipantInstructionTextbox.sendKeys(Keys.ENTER);
		List<WebElement> textsToAddLink = driver.findElements(By.xpath("//span[text()='"+text+"']"));
		int actualText = textsToAddLink.size()-1;
		System.out.println(actualText);
		WebElement textToAddLink = textsToAddLink.get(actualText);
		
		Actions actions = new Actions(driver);
		
		actions.doubleClick(textToAddLink).perform();
		Thread.sleep(500);
		
		JavascriptExecutor linkjs = (JavascriptExecutor) driver;		
		linkjs.executeScript("arguments[0].click();", hyperlinkMenuMenu);		
		Thread.sleep(1000);		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='paste or type a link']")));
		
		
		JavascriptExecutor addlinkjs = (JavascriptExecutor) driver;		
		addlinkjs.executeScript("arguments[0].click();", addLinkTextbox);	
		
		addLinkTextbox.sendKeys(link);
		Thread.sleep(500);
		
		
		JavascriptExecutor addlinktickjs = (JavascriptExecutor) driver;		
		addlinktickjs.executeScript("arguments[0].click();", addLinkTickmark);
		
		Thread.sleep(1500);
		
		JavascriptExecutor editInstructionTickMarkjs = (JavascriptExecutor) driver;
		editInstructionTickMarkjs.executeScript("arguments[0].click();", editInstructionTickMark);
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
	}
	
	public boolean checkHyperlinkInTagInstructions(String text,String link,String texttobepresentinthepage) throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		JavascriptExecutor ip = (JavascriptExecutor) driver;
		ip.executeScript("arguments[0].click();", instructionPanelMenu);
		Thread.sleep(1000);
		
		int isLinkTextPresent = driver.findElements(By.xpath("//a[text()='"+text+"']")).size();
		
		if(isLinkTextPresent>0) {
			List<WebElement> links = driver.findElements(By.xpath("//a[text()='"+text+"']"));
			System.out.println("hyperlink text is there");
			links.get(isLinkTextPresent-1).click();
			Thread.sleep(3000);
			ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs2.get(1));
			Thread.sleep(3000);
			String currentpageurl = driver.getCurrentUrl();
			
			if(currentpageurl.contains(link)) {
				System.out.println("Link is there in the new tab");
				int isTextPresent = driver.findElements(By.xpath("//*[contains(text(),'"+texttobepresentinthepage+"')]")).size();
				if(isTextPresent>0) {
					System.out.println("User is able to see the web page successfully");
					driver.switchTo().window(tabs2.get(0));
					return true;
				}
				else {
					
					System.out.println("User is unable to see the web page");
					driver.switchTo().window(tabs2.get(0));
					return false;
				}
			}
			
			else {
				System.out.println("Link is not there in the new tab");
				driver.switchTo().window(tabs2.get(0));
				return false;
			}
			
						
		}
		else {
			System.out.println("hyperlink text is not there");
			return false;
		}
	}
	
	public void goToTagSettingsPanel() throws Exception {
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		
		JavascriptExecutor activitysettings = (JavascriptExecutor) driver;
		activitysettings.executeScript("arguments[0].click();", activitySettingsMenu);
		Thread.sleep(1500);
		
		JavascriptExecutor tagsettings = (JavascriptExecutor) driver;
		tagsettings.executeScript("arguments[0].click();", tagSettingsMenu);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		Thread.sleep(500);	
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		Thread.sleep(1000);
		
	}
	
	public void enableShowTagButton() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));		
		
		JavascriptExecutor showtagjs = (JavascriptExecutor) driver;
		showtagjs.executeScript("arguments[0].click();", showTagSettingsButton);
		Thread.sleep(1000);
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
	}
	
	public void enableHideTagButton() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));		
		
		JavascriptExecutor hidetagjs = (JavascriptExecutor) driver;
		hidetagjs.executeScript("arguments[0].click();", hideTagSettingsButton);
		Thread.sleep(1000);
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
	}
	
	public boolean isTagThere(String topic) throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[text()='"+topic+"']")));
		
		int isPresent = driver.findElements(By.xpath("//h4[text()='"+topic+"']/following-sibling::ul//span[text()='Tag']")).size();
		if(isPresent>0) {
			System.out.println("Tag activity is there");
			return true;
		}
		
		else {
			System.out.println("Tag activity is not there");
			return false;
		}
	}
	
	public void setAlltileVisibilitySettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));	
		
		
		JavascriptExecutor tilestylejs = (JavascriptExecutor) driver;
		tilestylejs.executeScript("arguments[0].click();", tileStyle);
		Thread.sleep(500);
		
		JavascriptExecutor owntilesjs = (JavascriptExecutor) driver;
		owntilesjs.executeScript("arguments[0].click();", allTileVisibilityButtonInTagSettings);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
	}
	
	public void setownertileVisibilitySettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));	
		
		
		JavascriptExecutor tilestylejs = (JavascriptExecutor) driver;
		tilestylejs.executeScript("arguments[0].click();", tileStyle);
		Thread.sleep(500);
		
		JavascriptExecutor owntilesjs = (JavascriptExecutor) driver;
		owntilesjs.executeScript("arguments[0].click();", ownerTileVisibilityButtonInTagSettings);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
	}
	
	public boolean isTilePresent(String tileno) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		int isPresent = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[1][text()='"+tileno+"']")).size();
		if(isPresent>0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void setNoAddTileSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));	
		
		JavascriptExecutor noaddtilejs = (JavascriptExecutor) driver;
		noaddtilejs.executeScript("arguments[0].click();", noInAddTileTagSettings);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
	}
	
	public void setYesAddTileSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));	
		
		JavascriptExecutor yesaddtilejs = (JavascriptExecutor) driver;
		yesaddtilejs.executeScript("arguments[0].click();", yesInAddTileTagSettings);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
	}
	
	public boolean isAddTilePresent() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		int isPresent = driver.findElements(By.xpath("//div[@id='addIdeaBtn']")).size();
		if(isPresent>0) {
			return true;
		}
		else {
			return false;
		}
	} 
	
	public void setShowTagInSettings() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));	
		
		JavascriptExecutor showtagjs = (JavascriptExecutor) driver;
		showtagjs.executeScript("arguments[0].click();", showTagsOnTileFrontSettings);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
		
		
	}
	
	public void setHideTagInSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));	
		
		JavascriptExecutor hidetagjs = (JavascriptExecutor) driver;
		hidetagjs.executeScript("arguments[0].click();", hideTagsOnTileFrontSettings);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
		
	}
	
	public boolean isTagPresent() throws Exception{
		int tagThereCount = driver.findElements(By.xpath("//span[@class='title']/p/ancestor::div[@class='ideaTxt']/following-sibling::div//div[@class='tag-group']")).size();
		if(tagThereCount>0) {
			System.out.println("Tag is displaying on front of tile");
			return true;
		}
		else {
			System.out.println("Tag is not displaying on front of tile");
			return false;
		}
	}
	
	public void setListStyleInSettings() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));	
		
		JavascriptExecutor showtagjs = (JavascriptExecutor) driver;
		showtagjs.executeScript("arguments[0].click();", listStyleSettings);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
		
		
	}
	
	public void setTileStyleInSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));	
		
		JavascriptExecutor hidetagjs = (JavascriptExecutor) driver;
		hidetagjs.executeScript("arguments[0].click();", tileStyleSettings);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
		
	}
	
	public boolean isListViewPresent() throws Exception{
		int listThereCount = driver.findElements(By.xpath("//div[@class='grid-layout list']")).size();
		if(listThereCount>0) {
			System.out.println("Ideas are displaying in a list");
			return true;
		}
		else {
			System.out.println("Ideas are displaying in a tile style");
			return false;
		}
	}
	
	public void setAllCommentVisibilitySettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));	
		
		JavascriptExecutor alltilejs = (JavascriptExecutor) driver;
		alltilejs.executeScript("arguments[0].click();", allTileVisibilityButtonInTagSettings);		
		Thread.sleep(500);
		
		JavascriptExecutor hidetagjs = (JavascriptExecutor) driver;
		hidetagjs.executeScript("arguments[0].click();", allCommentVisibility);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
		
	}
	
	public void setOwnerCommentVisibilitySettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		
		JavascriptExecutor alltilejs = (JavascriptExecutor) driver;
		alltilejs.executeScript("arguments[0].click();", allTileVisibilityButtonInTagSettings);		
		Thread.sleep(500);
		
		JavascriptExecutor hidetagjs = (JavascriptExecutor) driver;
		hidetagjs.executeScript("arguments[0].click();", ownerCommentVisibility);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
		
	}
	
	public int takeCommentCount(String tileno) throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")));
		
		String commentcount = driver.findElement(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']//ancestor::div[@class='idea']//div[@class='commentsNumber ideaComments']")).getText();
		return Integer.parseInt(commentcount);		
		
	}
	
	public boolean postAComment(String tileno, String comment) throws Exception {
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")));
		int countbeforeadding = this.takeCommentCount(tileno);
		driver.findElement(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']//ancestor::div[@class='idea']//div[@class='commentsNumber ideaComments']")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='idea_comments']")));
		JavascriptExecutor commentBox = (JavascriptExecutor) driver;
		commentBox.executeScript("arguments[0].click();", writeACommentTextBox);
		writeACommentTextBox.sendKeys(comment);
		Thread.sleep(500);
		postcommentButton.click();
		Thread.sleep(1000);
		tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")));
		Thread.sleep(1000);
		int countafteradding = this.takeCommentCount(tileno);
		if(countbeforeadding+1 == countafteradding) {
			System.out.println("Comment added successfully");
			return true;
		}
		else {
			System.out.println("Comment not added successfully");
			return false;
		}
	}
	
	public void setShowFilesInSettings() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));	
		
		JavascriptExecutor showtagjs = (JavascriptExecutor) driver;
		showtagjs.executeScript("arguments[0].click();", showFileSettings);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
		
		
	}
	
	public void setHideFilesInSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));	
		
		JavascriptExecutor hidetagjs = (JavascriptExecutor) driver;
		hidetagjs.executeScript("arguments[0].click();", hideFileSettings);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
		
	}
	
	public void clickOnATile() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		
		int isTileThere = driver.findElements(By.xpath("//div[@class='idea']/div[@class='sticky']")).size();
		
		if(isTileThere>0) {
			System.out.println("Tile is present");
			WebElement tile = driver.findElement(By.xpath("//div[@class='idea']/div[@class='sticky']"));
			
			JavascriptExecutor tilejs = (JavascriptExecutor) driver;
			tilejs.executeScript("arguments[0].click();", tile);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dialog-close-btn")));
		}
		else {
			System.out.println("No tile is present in this topic");
		}
		
	}
	
	public boolean isAddFilePresent() throws Exception{
		int tagThereCount = driver.findElements(By.id("add-file-lbl")).size();
		if(tagThereCount>0) {
			System.out.println("Add file button is displaying");
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			return true;
		}
		else {
			System.out.println("Add file button is not displaying");
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			return false;
		}
	}
	
	public void setAllTaggingAbilitySettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));	
		
		JavascriptExecutor alltilejs = (JavascriptExecutor) driver;
		alltilejs.executeScript("arguments[0].click();", allTileVisibilityButtonInTagSettings);		
		Thread.sleep(500);
		
		JavascriptExecutor hidetagjs = (JavascriptExecutor) driver;
		hidetagjs.executeScript("arguments[0].click();", allTaggingAbilityButton);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
		
	}
	
	public void setOwnerTaggingAbilitySettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		
		JavascriptExecutor alltilejs = (JavascriptExecutor) driver;
		alltilejs.executeScript("arguments[0].click();", allTileVisibilityButtonInTagSettings);		
		Thread.sleep(500);
		
		JavascriptExecutor hidetagjs = (JavascriptExecutor) driver;
		hidetagjs.executeScript("arguments[0].click();", ownerTaggingAbilityButton);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
		
	}
	
	public boolean checkTaggingAbilityOfATile(String tileno) throws Exception{
		JavascriptExecutor tickmark = (JavascriptExecutor) driver;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")));
		driver.findElement(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='idea_tags']")));
		
		Thread.sleep(1000);
		int isTaggingAbility = driver.findElements(By.xpath("//div[@class='tag-display selector disabled']")).size();
		if(isTaggingAbility>0) {
			System.out.println("Tagging ability of this tile is restricted for this user");
			tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
			Thread.sleep(1000);
			return false;
		}
		else {
			System.out.println("User can able to tag this tile");
			tickmark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
			Thread.sleep(1000);
			return true;
		}
	}
	
	public void setAlphaAscendingTagSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		
		JavascriptExecutor alltilejs = (JavascriptExecutor) driver;
		alltilejs.executeScript("arguments[0].click();", allTileVisibilityButtonInTagSettings);		
		Thread.sleep(500);
		
		JavascriptExecutor hidetagjs = (JavascriptExecutor) driver;
		hidetagjs.executeScript("arguments[0].click();", alphaAscendingDefaultButton);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
	}
	
	public Boolean alphabeticalAscendingTiles() throws Exception{
		int count = 0;
		NoodleActivity noodle = new NoodleActivity();
		
		Thread.sleep(2000);
		List<WebElement> tiles = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[2]/p"));
		int n =tiles.size();
		
		
		String alphabetOrder[] = noodle.sortElementsInAlphabeticalOrder(tiles);
		
		for(int i=0;i<n;i++) {
			System.out.println(alphabetOrder[i]);
			System.out.println("original order: "+tiles.get(i).getText());
			if(tiles.get(i).getText().equalsIgnoreCase(alphabetOrder[i])) {
				count++;
			}
		}
		System.out.println(count);
		if(count == n) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void setAlphaDescendingTagSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		
		JavascriptExecutor alltilejs = (JavascriptExecutor) driver;
		alltilejs.executeScript("arguments[0].click();", allTileVisibilityButtonInTagSettings);		
		Thread.sleep(500);
		
		JavascriptExecutor hidetagjs = (JavascriptExecutor) driver;
		hidetagjs.executeScript("arguments[0].click();", alphaDescendingDefaultButton);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
	}
	
	public Boolean alphabeticalDescendingTiles() throws Exception{
		int count = 0;
		NoodleActivity noodle = new NoodleActivity();
		Thread.sleep(2000);
		List<WebElement> tiles = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[2]/p"));
		int n =tiles.size();
		
		
		String alphabetOrder[] = noodle.sortElementsInAlphadescendingOrder(tiles);
		
		for(int i=0;i<n;i++) {
			if(tiles.get(i).getText().equalsIgnoreCase(alphabetOrder[i])) {
				count++;
			}
		}
		System.out.println(count);
		if(count == n) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void setNumericAscendingTagSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		
		JavascriptExecutor alltilejs = (JavascriptExecutor) driver;
		alltilejs.executeScript("arguments[0].click();", allTileVisibilityButtonInTagSettings);		
		Thread.sleep(500);
		
		JavascriptExecutor hidetagjs = (JavascriptExecutor) driver;
		hidetagjs.executeScript("arguments[0].click();", numericAscendingDefaultButton);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
	}
	
	public Boolean tilenoAscendingOrder() throws Exception{
		int count = 0;
		NoodleActivity noodle = new NoodleActivity();
		Thread.sleep(2000);
		List<WebElement> tiles = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[1]"));
		int n =tiles.size();
		
		
		int alphabetOrder[] = noodle.sortElementsInNumericAsc(tiles);
		String stringNumber;
		for(int i=0;i<n;i++) {
			stringNumber = Integer.toString(alphabetOrder[i]);
			if(tiles.get(i).getText().equalsIgnoreCase(stringNumber)) {
				count++;
			}
		}
		System.out.println(count);
		if(count == n) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void setNumericDescendingTagSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		
		JavascriptExecutor alltilejs = (JavascriptExecutor) driver;
		alltilejs.executeScript("arguments[0].click();", allTileVisibilityButtonInTagSettings);		
		Thread.sleep(500);
		
		JavascriptExecutor hidetagjs = (JavascriptExecutor) driver;
		hidetagjs.executeScript("arguments[0].click();", numericDescendingDefaultButton);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
	}
	
	public Boolean tilenoDescendingOrder() throws Exception{
		int count = 0;
		NoodleActivity noodle = new NoodleActivity();
		Thread.sleep(2000);
		List<WebElement> tiles = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[1]"));
		int n =tiles.size();
		
		
		int alphabetOrder[] = noodle.sortElementsInNumericDesc(tiles);
		String stringNumber;
		for(int i=0;i<n;i++) {
			stringNumber = Integer.toString(alphabetOrder[i]);
			if(tiles.get(i).getText().equalsIgnoreCase(stringNumber)) {
				count++;
			}
		}
		System.out.println(count);
		if(count == n) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void setShuffledTagSettings() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		
		JavascriptExecutor alltilejs = (JavascriptExecutor) driver;
		alltilejs.executeScript("arguments[0].click();", allTileVisibilityButtonInTagSettings);		
		Thread.sleep(500);
		
		JavascriptExecutor hidetagjs = (JavascriptExecutor) driver;
		hidetagjs.executeScript("arguments[0].click();", shuffleOrderDefaultButton);		
		Thread.sleep(1000);
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
	}
	
	public int tilesCount() throws Exception{
		int tilecount = driver.findElements(By.xpath("//div[@class='ideaTxt']/span[1]")).size();
		return tilecount;
	}
	
	public boolean createNewTagGroup(String groupname) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		
		JavascriptExecutor addgroupnamejs = (JavascriptExecutor) driver;
		addgroupnamejs.executeScript("arguments[0].click();", addTagGroupButton);		
		Thread.sleep(500);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='group name'][@value='']")));
		
		JavascriptExecutor groupnamejs = (JavascriptExecutor) driver;
		groupnamejs.executeScript("arguments[0].click();", emptyGroupnameTextbox);		
		Thread.sleep(500);
		
		emptyGroupnameTextbox.sendKeys(groupname);
		Thread.sleep(1000);
		
		int isGroupAdded = driver.findElements(By.xpath("//input[@placeholder='group name'][@value='"+groupname+"']")).size();
		
		if(isGroupAdded>0) {
			System.out.println("New group added successfully");
			return true;
		}
		else {
			System.out.println("Newly added group is not displayed");
			return false;
		}
	}
	
	public boolean addTagsUnderTaggroup(String taggroup, String tagname) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		
		WebElement addTagButton = driver.findElement(By.xpath("//input[@placeholder='group name'][@value='"+taggroup+"']//ancestor::div[@class='row no-gutter groupName']/following-sibling::div//button[@id='add-tag-btn']"));
		
		JavascriptExecutor addtagbtnjs = (JavascriptExecutor) driver;
		addtagbtnjs.executeScript("arguments[0].click();", addTagButton);		
		Thread.sleep(500);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='group name'][@value='"+taggroup+"']//ancestor::div[@class='row no-gutter groupName']/following-sibling::div//input[@placeholder='tag name'][@value='']")));
		
		WebElement tagTextbox = driver.findElement(By.xpath("//input[@placeholder='group name'][@value='"+taggroup+"']//ancestor::div[@class='row no-gutter groupName']/following-sibling::div//input[@placeholder='tag name'][@value='']"));
		JavascriptExecutor addtagtextjs = (JavascriptExecutor) driver;
		addtagtextjs.executeScript("arguments[0].click();", tagTextbox);		
		
		tagTextbox.sendKeys(tagname);
		Thread.sleep(1000);
		
		int isTagAdded = driver.findElements(By.xpath("//input[@placeholder='group name'][@value='"+taggroup+"']//ancestor::div[@class='row no-gutter groupName']/following-sibling::div//input[@placeholder='tag name'][@value='"+tagname+"']")).size();
		
		if(isTagAdded>0) {
			System.out.println("New tag added under the tag group "+taggroup+" successfully");
			return true;
		}
		else {
			System.out.println("Newly added tag is not displayed under the tag group "+taggroup);
			return false;
		}
		
	}     
	
	public void saveSettingsChanges() throws Exception{
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
	}
	
	public boolean AddTagForATile(String tileno, String groupname, String tagname) throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")));
		driver.findElement(By.xpath("//span[@class='ideaNumber'][text()='"+tileno+"']")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='idea_tags']")));
		
		Thread.sleep(1000);
		int isTaggingAbility = driver.findElements(By.xpath("//div[@class='tag-display selector disabled']")).size();
		if(isTaggingAbility>0) {
			System.out.println("Tagging ability of this tile is restricted for this user");
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
			Thread.sleep(1000);
			return false;
		}
		else {
			System.out.println("User can able to add tag for this tile");
			int isTagThere = driver.findElements(By.xpath("//div[@class='tag-group']/div[text()='"+groupname+"']/following::div[@class='tag-group-wrapper']//span[text()='"+tagname+"']")).size();
			
			if(isTagThere>0) {
				System.out.println("Tag is there");
				int isTagNotYetSelected = driver.findElements(By.xpath("//div[@class='tag-group']/div[text()='"+groupname+"']/following::div[@class='tag-group-wrapper']//span[text()='"+tagname+"'][@data-selected='false']")).size();
				if(isTagNotYetSelected>0) {
				WebElement tagToAdd = driver.findElement(By.xpath("//div[@class='tag-group']/div[text()='"+groupname+"']/following::div[@class='tag-group-wrapper']//span[text()='"+tagname+"']"));
				tagToAdd.click();
				Thread.sleep(1000);
				
				int isTagSelected = driver.findElements(By.xpath("//div[@class='tag-group']/div[text()='"+groupname+"']/following::div[@class='tag-group-wrapper']//span[text()='"+tagname+"'][@data-selected='true']")).size();
				
				if(isTagSelected>0) {
					System.out.println("Tag is added for this tile successfully");
					closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
					driver.navigate().refresh();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
					return true;
				}
				else {
					System.out.println("Tag is not added for this tile");
					closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
					driver.navigate().refresh();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
					return false;
				}
			}
				else {
					System.out.println("Tag is already selected for this tile");
					closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
					driver.navigate().refresh();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
					return true;
				}
			}
			
			else {
				System.out.println("There is no tag in this name. Please give a correct tag name.");
				closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
				return false;
			}
			
		}
	}
	
	public void setPickOneTagSettings(String groupname) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		
		JavascriptExecutor hidetagjs = (JavascriptExecutor) driver;
		hidetagjs.executeScript("arguments[0].click();", allTaggingAbilityButton);			
		Thread.sleep(500);
		
		List<WebElement> pickOneButtons = driver.findElements(By.xpath("//input[@value='"+groupname+"']//ancestor::div[@class='container-fluid']/following-sibling::div//label[text()='Pick One']"));
		
		for(int i=0;i<pickOneButtons.size();i++) {
			JavascriptExecutor pickonejs = (JavascriptExecutor) driver;
			pickonejs.executeScript("arguments[0].click();", pickOneButtons.get(i));		
			Thread.sleep(500);
		}
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
	}
	
	public void setPickManyTagSettings(String groupname) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		
		JavascriptExecutor hidetagjs = (JavascriptExecutor) driver;
		hidetagjs.executeScript("arguments[0].click();", allTaggingAbilityButton);			
		Thread.sleep(500);
		
		List<WebElement> pickManyButtons = driver.findElements(By.xpath("//input[@value='"+groupname+"']//ancestor::div[@class='container-fluid']/following-sibling::div//label[text()='Pick Many']"));
		
		for(int i=0;i<pickManyButtons.size();i++) {
			JavascriptExecutor pickonejs = (JavascriptExecutor) driver;
			pickonejs.executeScript("arguments[0].click();", pickManyButtons.get(i));		
			Thread.sleep(500);
		}
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		Thread.sleep(1000);
	}
	
	public boolean checkPickOneType(String groupname) throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[@id='tags']")));
		
		if(driver.findElements(By.xpath("//li[@id='tags'][@class='selected']")).size()==0) {
			WebElement tagLabel = driver.findElement(By.xpath("//li[@id='tags']"));
			JavascriptExecutor tagjs = (JavascriptExecutor) driver;
			tagjs.executeScript("arguments[0].click();", tagLabel);			
			Thread.sleep(1000);
		}
		Thread.sleep(1000);
		
		
		int countOfSelectOneLabel = driver.findElements(By.xpath("//div[text()='"+groupname+"']/span[text()='(Select one)']")).size();
		int countOfSelectOneDot = driver.findElements(By.xpath("//div[text()='"+groupname+"']/following-sibling::div/span[@class='tag_idea_type single']")).size();
		if(countOfSelectOneLabel>0 && countOfSelectOneDot>0) {
			
			if(driver.findElements(By.xpath("//div[@title='"+groupname+"']/span")).size()>=2) {
				List<WebElement> tags = driver.findElements(By.xpath("//div[@title='"+groupname+"']/span"));
				for(int i=0;i<2;i++) {
					JavascriptExecutor tagundergroupjs = (JavascriptExecutor) driver;
					tagundergroupjs.executeScript("arguments[0].click();", tags.get(i));			
					Thread.sleep(500);
				}
				
				int selectedTags = driver.findElements(By.xpath("//div[@title='"+groupname+"']/span[@data-selected='true']")).size();
				if(selectedTags==1) {
					System.out.println("User is able to select only one tag from this group");
					closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
					driver.navigate().refresh();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
					return true;
				}
				
				else {
					System.out.println("User is able to select more than one tags from this group");
					closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
					driver.navigate().refresh();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
					return false;
				}
			}
			else {
				System.out.println("Tag count is lesser than two in this group. So, we couldn't able to test this feature.");
				closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
				return false;
			}
		}
		else {
			System.out.println("Select one in the Tag group name label or dot in the Tag idea type is not displaying correctly");
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
			return false;
		}
		
	}
	
	public boolean checkPickManyType(String groupname) throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[@id='tags']")));
		
		if(driver.findElements(By.xpath("//li[@id='tags'][@class='selected']")).size()==0) {
			WebElement tagLabel = driver.findElement(By.xpath("//li[@id='tags']"));
			JavascriptExecutor tagjs = (JavascriptExecutor) driver;
			tagjs.executeScript("arguments[0].click();", tagLabel);			
			Thread.sleep(1000);
		}
		Thread.sleep(1000);
		
		
		int countOfSelectManyLabel = driver.findElements(By.xpath("//div[text()='"+groupname+"']/span[text()='(Select all that apply)']")).size();
		int countOfSelectManyDot = driver.findElements(By.xpath("//div[text()='"+groupname+"']/following-sibling::div/span[@class='tag_idea_type multi']")).size();
		if(countOfSelectManyLabel>0 && countOfSelectManyDot>0) {
			
			if(driver.findElements(By.xpath("//div[@title='"+groupname+"']/span")).size()>=2) {
				List<WebElement> tags = driver.findElements(By.xpath("//div[@title='"+groupname+"']/span"));
				for(int i=0;i<tags.size();i++) {
					if(tags.get(i).getAttribute("data-selected").equals("false")) {
						JavascriptExecutor tagundergroupjs = (JavascriptExecutor) driver;
						tagundergroupjs.executeScript("arguments[0].click();", tags.get(i));			
						Thread.sleep(500);
					}
					
				}
				
				int selectedTags = driver.findElements(By.xpath("//div[@title='"+groupname+"']/span[@data-selected='true']")).size();
				if(selectedTags>=2) {
					System.out.println("User is able to select more than one tag from this group");
					closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
					driver.navigate().refresh();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
					return true;
				}
				
				else {
					System.out.println("User is unable to select more than one tag from this group");
					closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
					driver.navigate().refresh();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
					return false;
				}
			}
			else {
				System.out.println("Tag count is lesser than two in this group. So, we couldn't able to test this feature.");
				closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
				return false;
			}
		}
		else {
			System.out.println("Select all that apply in the Tag group name label or infinity in the Tag idea type is not displaying correctly");
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
			return false;
		}
		
	}
	
	
	
	public boolean clickEyetoggleOfTagGroup(String groupname) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		
		int isgroupThere = driver.findElements(By.xpath("//input[@name='tag_group' and @value='"+groupname+"']")).size();
		if(isgroupThere>0) {
			WebElement eyeToggle = driver.findElement(By.xpath("//input[@value='"+groupname+"']/parent::div/following-sibling::div/label[text()='Lock']"));
			JavascriptExecutor eyetogglejs = (JavascriptExecutor) driver;
			eyetogglejs.executeScript("arguments[0].click();", eyeToggle);
			Thread.sleep(1000);
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
			return true;
		}
		else {
			System.out.println("There is no group with this name");
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
			return false;
		}
	}
	
	
	
	public int checkTagGroupInTheTile(String groupname) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		if(driver.findElements(By.xpath("//div[@class='idea']")).size()>0) {
			driver.findElement(By.xpath("//div[@class='idea']//div[@class='ideaTxt']")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idea_tags")));
			int isTagGroupThere = driver.findElements(By.xpath("//div[@class='name'][text()='"+groupname+"']")).size();
			closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
			return isTagGroupThere;
		}
		else {
			System.out.println("There is no idea present in this topic");
			return -1;
		}
	}
	
	
	
	
	public boolean checkDownArrowOfTaggroup(String groupname) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		List<WebElement> taggroups = driver.findElements(By.xpath("//input[@name='tag_group']"));
		int sizeOfTagGroup = taggroups.size();
		int positionOfSearchedGroup=1;
		for(int i=0;i<sizeOfTagGroup;i++) {
			if(taggroups.get(i).getAttribute("value").equals(groupname)) {
				positionOfSearchedGroup = i+1;
				System.out.println("Searched group's position "+positionOfSearchedGroup);
				break;
			}
			else if(i==sizeOfTagGroup-1) {
				System.out.println("Group name is not there");
				return false;
			}
		}
		if(positionOfSearchedGroup==sizeOfTagGroup) {
			System.out.println("The searched group is the last one. So the down arrow is not clickable");
		}
		for(int j=positionOfSearchedGroup;j<sizeOfTagGroup;j++) {
			WebElement downArrow = driver.findElement(By.xpath("//div[@class='tag_list control TagGroup']["+j+"]//input[@name='tag_group']/parent::div/following-sibling::div/button[@class='down']"));
			/*JavascriptExecutor downarrowjs = (JavascriptExecutor) driver;
			downarrowjs.executeScript("arguments[0].click();", downArrow);*/
			downArrow.click();
			Thread.sleep(2000);
			int nextOfDown = j+1;
			String downGroup = driver.findElement(By.xpath("//div[@class='tag_list control TagGroup']["+nextOfDown+"]//input[@name='tag_group']")).getAttribute("value");
			System.out.println("group name after clicking on the down arrow "+downGroup);
			if(downGroup.equals(groupname)) {
				continue;
			}
			else {
				System.out.println("Down arrow is not working correctly");
				return false;
			}
		}
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		return true;
	}
	
	public boolean checkUpArrowOfTaggroup(String groupname) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		List<WebElement> taggroups = driver.findElements(By.xpath("//input[@name='tag_group']"));
		int sizeOfTagGroup = taggroups.size();
		int positionOfSearchedGroup=1;
		for(int i=0;i<sizeOfTagGroup;i++) {
			if(taggroups.get(i).getAttribute("value").equals(groupname)) {
				positionOfSearchedGroup = i+1;
				System.out.println("Searched group's position "+positionOfSearchedGroup);
				break;
			}
			else if(i==sizeOfTagGroup-1) {
				System.out.println("Group name is not there");
				return false;
			}
		}
		if(positionOfSearchedGroup==1) {
			System.out.println("The searched group is the first one. So the up arrow is not clickable");
		}
		for(int j=positionOfSearchedGroup;j>1;j--) {
			WebElement upArrow = driver.findElement(By.xpath("//div[@class='tag_list control TagGroup']["+j+"]//input[@name='tag_group']/parent::div/following-sibling::div/button[@class='up']"));
			JavascriptExecutor downarrowjs = (JavascriptExecutor) driver;
			downarrowjs.executeScript("arguments[0].click();", upArrow);
			//upArrow.click();
			Thread.sleep(2000);
			int nextup = j-1;
			String upperGroup = driver.findElement(By.xpath("//div[@class='tag_list control TagGroup']["+nextup+"]//input[@name='tag_group']")).getAttribute("value");
			System.out.println("group name after clicking on the up arrow "+upperGroup);
			if(upperGroup.equals(groupname)) {
				continue;
			}
			else {
				System.out.println("Up arrow is not working correctly");
				return false;
			}
		}
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		return true;
	}
	
	public boolean checkTagGroupOrder() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		List<WebElement> taggroups = driver.findElements(By.xpath("//input[@name='tag_group']"));
		int sizeOfTagGroups = taggroups.size();
		List<String> groupNames = new ArrayList<String>();
		for(int i=0;i<sizeOfTagGroups;i++) {
			String gptext = taggroups.get(i).getAttribute("value");
			System.out.println("Tag group names "+gptext);
			groupNames.add(gptext);
		}
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		
		if(driver.findElements(By.xpath("//div[@class='idea']")).size()>0) {
			driver.findElement(By.xpath("//div[@class='idea']//div[@class='ideaTxt']")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idea_tags")));
			for(int j=0;j<sizeOfTagGroups;j++) {
				int jj=j+1;
				String gpname = driver.findElement(By.xpath("//div[@class='tag-group']["+jj+"]/div[@class='name']")).getText().split("\\n")[0];
				System.out.println("Group "+gpname);
				if(gpname.equals(groupNames.get(j))) {
					continue;
				}
				else if(j==sizeOfTagGroups-1){
					return false;
				}
			}
			System.out.println("Groups are displaying in the same order");
			return true;
			
		}
		else {
			System.out.println("There is no idea present in this topic");
			return false;
		}
	}
	
	
	public boolean checkDownArrowOfTags(String groupname) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		List<WebElement> tags = driver.findElements(By.xpath("//input[@name='tag_group' and @value='"+groupname+"']/ancestor::div[@class='row no-gutter groupName']/following-sibling::div//input[@name='tag_name']"));
		int sizeOfTags = tags.size();
		if(sizeOfTags>=2) {
			String tagname = driver.findElement(By.xpath("//input[@name='tag_group' and @value='"+groupname+"']/ancestor::div[@class='row no-gutter groupName']/following-sibling::div//li[1]//input[@name='tag_name']")).getAttribute("value");
			for(int i=1;i<sizeOfTags;i++) {
				WebElement downArrow = driver.findElement(By.xpath("//input[@name='tag_group' and @value='"+groupname+"']/ancestor::div[@class='row no-gutter groupName']/following-sibling::div//li["+i+"]//input[@name='tag_name']/following-sibling::button[@class='down']"));
				downArrow.click();
				Thread.sleep(2000);
				int ii=i+1;
				String downtag = driver.findElement(By.xpath("//input[@name='tag_group' and @value='"+groupname+"']/ancestor::div[@class='row no-gutter groupName']/following-sibling::div//li["+ii+"]//input[@name='tag_name']")).getAttribute("value");
				
				if(downtag.equals(tagname)) {
					continue;
				}
				else {
					System.out.println("Down arrow of the tag is not working properly");
					return false;
				}
			}
		}
		else {
			System.out.println("This tag group contains less than two tags. So we can't check the down arrow.");
			return true;
		}
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		return true;
	}
	
	public boolean checkUpArrowOfTags(String groupname) throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dialogTitle'][text()='Tag Settings']")));
		List<WebElement> tags = driver.findElements(By.xpath("//input[@name='tag_group' and @value='"+groupname+"']/ancestor::div[@class='row no-gutter groupName']/following-sibling::div//input[@name='tag_name']"));
		int sizeOfTags = tags.size();
		if(sizeOfTags>=2) {
			String tagname = driver.findElement(By.xpath("//input[@name='tag_group' and @value='"+groupname+"']/ancestor::div[@class='row no-gutter groupName']/following-sibling::div//li["+sizeOfTags+"]//input[@name='tag_name']")).getAttribute("value");
			for(int i=sizeOfTags;i>1;i--) {
				WebElement upArrow = driver.findElement(By.xpath("//input[@name='tag_group' and @value='"+groupname+"']/ancestor::div[@class='row no-gutter groupName']/following-sibling::div//li["+i+"]//input[@name='tag_name']/following-sibling::button[@class='up']"));
				upArrow.click();
				Thread.sleep(2000);
				int ii=i-1;
				String downtag = driver.findElement(By.xpath("//input[@name='tag_group' and @value='"+groupname+"']/ancestor::div[@class='row no-gutter groupName']/following-sibling::div//li["+ii+"]//input[@name='tag_name']")).getAttribute("value");
				
				if(downtag.equals(tagname)) {
					continue;
				}
				else {
					System.out.println("Up arrow of the tag is not working properly");
					return false;
				}
			}
		}
		else {
			System.out.println("This tag group contains less than two tags. So we can't check the up arrow.");
			return true;
		}
		
		closeTickMark.executeScript("arguments[0].click();", tickMarkOfActionSettings);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='tag: ']")));
		return true;
	}
	

	
	



}
