package com.pageobjects;

import java.util.ArrayList;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.Base.Testbase;

public class Forgotpassword extends Testbase {

	@FindBy(xpath = "//a[contains(text(),'Forgot Password?')]")
	WebElement clickonforgotpassword;

	@FindBy(id = "email")
	WebElement usermail;

	@FindBy(xpath = "//input[@value='Reset Password']")
	WebElement submit;
	@FindBy(id = "identifierId")
	WebElement username;
	@FindBy(id = "identifierNext")
	WebElement clicknext;
	@FindBy(xpath = "//input[@type='password']")
	WebElement password;
	@FindBy(id = "passwordNext")
	WebElement next;
	@FindBy(xpath = "//a[contains(text(),'https://app.powernoodle.com/')]")
	WebElement passwordlink;
	@FindBy(xpath = "//form[@id='password_reset']//input[@placeholder='New Password']")
	WebElement newpassword;
	@FindBy(id = "passwordconfirm")
	WebElement confirmpassword;
	@FindBy(xpath = "//form[@id='password_reset']//input[@id='submit']")
	WebElement submitnewpswd;
	@FindBy(xpath = "//form[@id='password_reset']/div/p")
	WebElement errormsg;
	@FindBy(xpath="//form[@id='password_reset']/div/ul/li[1]/span")
	WebElement tooShortErrorMsg;
	@FindBy(xpath = "//div[@id='container']//a[contains(text(),'Try returning to the page')]")
	WebElement backToResetPswd;
	@FindBy(xpath = "//div[@id='container']//div[2]")
	WebElement errorInBackToResetPage;

	public Forgotpassword() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}

	public void validate_email(String email) {
		clickonforgotpassword.click();
		usermail.sendKeys(email);
		submit.click();
	}

	public void email_validations(String un, String pswd) throws InterruptedException {
		username.sendKeys(un);
		clicknext.click();
		Thread.sleep(2000);
		password.sendKeys(pswd);
		Thread.sleep(1000);
		next.click();
	}

	public void new_tabToResetPassword() throws Exception {
		passwordlink.click();
		Thread.sleep(2000);

		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));

	}

	public void setPassword() throws Exception {

		Thread.sleep(1000);
		JavascriptExecutor ln = (JavascriptExecutor) driver;
		ln.executeScript("arguments[0].click();", newpassword);
		newpassword.sendKeys("Test@62!0$8");

		JavascriptExecutor confirmpswd = (JavascriptExecutor) driver;
		confirmpswd.executeScript("arguments[0].click();", confirmpassword);
		confirmpassword.sendKeys("Test@62!0$8");

		JavascriptExecutor passwordsubmit = (JavascriptExecutor) driver;
		passwordsubmit.executeScript("arguments[0].click();", submitnewpswd);
		Thread.sleep(1000);
	}

	public Boolean setPasswordWithEmptyFields() throws Exception {

		Thread.sleep(1000);
		JavascriptExecutor passwordsubmit = (JavascriptExecutor) driver;
		passwordsubmit.executeScript("arguments[0].click();", submitnewpswd);
		//clickResetLinkIfItPresent();
		Thread.sleep(1000);
		return errormsg.isDisplayed();
	}

	public Boolean setPasswordWithEmptyConfirmswdField() throws Exception {

		Thread.sleep(1000);
		JavascriptExecutor ln = (JavascriptExecutor) driver;
		ln.executeScript("arguments[0].click();", newpassword);
		newpassword.sendKeys("Test@62!0$8");

		JavascriptExecutor passwordsubmit = (JavascriptExecutor) driver;
		passwordsubmit.executeScript("arguments[0].click();", submitnewpswd);
		Thread.sleep(1000);

		return errorInBackToResetPage.isDisplayed();
	}

	public Boolean setPasswordWithMismatchPasswords() throws Exception {

		Thread.sleep(1000);
		JavascriptExecutor ln = (JavascriptExecutor) driver;
		ln.executeScript("arguments[0].click();", newpassword);
		newpassword.sendKeys("Test@62!0$8");

		JavascriptExecutor confirmpswd = (JavascriptExecutor) driver;
		confirmpswd.executeScript("arguments[0].click();", confirmpassword);
		confirmpassword.sendKeys("Test@62!0@0");

		JavascriptExecutor passwordsubmit = (JavascriptExecutor) driver;
		passwordsubmit.executeScript("arguments[0].click();", submitnewpswd);
		//clickResetLinkIfItPresent();
		Thread.sleep(1000);

		return errormsg.isDisplayed();
	}

	public Boolean setInvalidPassword() throws Exception {

		Thread.sleep(1000);
		JavascriptExecutor ln = (JavascriptExecutor) driver;
		ln.executeScript("arguments[0].click();", newpassword);
		newpassword.sendKeys("Test");

		JavascriptExecutor confirmpswd = (JavascriptExecutor) driver;
		confirmpswd.executeScript("arguments[0].click();", confirmpassword);
		confirmpassword.sendKeys("Test");

		JavascriptExecutor passwordsubmit = (JavascriptExecutor) driver;
		passwordsubmit.executeScript("arguments[0].click();", submitnewpswd);
		//clickResetLinkIfItPresent();
		Thread.sleep(1000);

		return tooShortErrorMsg.isDisplayed();
	}
	
	public void clickResetLinkIfItPresent() throws Exception {
		Thread.sleep(1000);
		if(backToResetPswd.isDisplayed()==true) {
			
			//linkToSetPassword.executeScript("arguments[0].click();", backToResetPswd);
			backToResetPswd.click();
			Thread.sleep(1000);
		}
	}
	public void clickBackToResetLink() throws Exception{
		Thread.sleep(1000);
		backToResetPswd.click();
	}
}
