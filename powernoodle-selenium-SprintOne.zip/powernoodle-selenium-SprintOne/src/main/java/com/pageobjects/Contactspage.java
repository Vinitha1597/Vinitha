package com.pageobjects;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Base.Testbase;

public class Contactspage extends Testbase {
	
	WebDriverWait wait = new WebDriverWait(driver, 40);

	@FindBy(xpath = "//*[@id='user-settings-btn']")
	WebElement usersettings;
	@FindBy(xpath = "//*[@id='contacts-btn']")
	WebElement contactsmenu;

	@FindBy(xpath = "//button[@id='addContact']")
	WebElement Addcontactbutton;
	@FindBy(xpath = "//*[@id='contact_first_name']")
	WebElement firstname;
	@FindBy(xpath = "//*[@id='contact_last_name']")
	WebElement lastname;
	@FindBy(xpath = "//*[@id='contact_email']")
	WebElement contact_email;
	@FindBy(xpath = "//input[@placeholder='Company']")
	WebElement company;
	@FindBy(xpath = "//button[@class='blue_bg add-contact'][contains(text(),'Add Contact')]")
	WebElement clickaddcontact;
	@FindBy(xpath = "//input[@placeholder='First name']")
	WebElement firstNameInEditContact;
	@FindBy(xpath = "//div[@class='PositionRight DialogControl CloseOk']")
	WebElement okButton;
	@FindBy(xpath = "//div[@id='contactList']//div[@class='ioslist-group-container']/ul/li/h3")
	List<WebElement> allContactsList;
	
	@FindBy(id = "dialog-delete-btn")
	WebElement deleteIcon;
	@FindBy(id = "confirm-btn")
	WebElement confirmDeleteBtn;
	
	/*@FindBy(xpath = "//*[@id='contact-']/button[contains(text(),'Add Contact')]")
	WebElement clickaddcontact;
*/
	
	@FindBy(xpath = "//div[@class='PositionRight DialogControl CloseOk']")
	WebElement submit;
	public Contactspage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}

	public void Menu() throws InterruptedException {
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Use a Model')]")));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", usersettings);
		Thread.sleep(2000);

		JavascriptExecutor cn = (JavascriptExecutor) driver;
		cn.executeScript("arguments[0].click();", contactsmenu);

		Addcontactbutton.click();
	}

	public Boolean add_details(String fname,String lname,String email,String companyname) throws InterruptedException {
		Boolean found = false;
		JavascriptExecutor fn = (JavascriptExecutor) driver;
		firstname.clear();
		fn.executeScript("arguments[0].click();", firstname);
		firstname.sendKeys(fname);
		Thread.sleep(1000);
		
		JavascriptExecutor ln = (JavascriptExecutor) driver;
		lastname.clear();
		ln.executeScript("arguments[0].click();", lastname);
		lastname.sendKeys(lname);
		Thread.sleep(1000);

		JavascriptExecutor ce = (JavascriptExecutor) driver;
		contact_email.clear();
		ce.executeScript("arguments[0].click();", contact_email);
		ce.executeScript("arguments[0].value='"+email+"';", contact_email);
		Thread.sleep(1000);
		
		JavascriptExecutor cmpny = (JavascriptExecutor) driver;
		company.clear();
		cmpny.executeScript("arguments[0].click();", company);
		cmpny.executeScript("arguments[0].value='"+companyname+"';", company);
		Thread.sleep(1000);
		
		JavascriptExecutor ac = (JavascriptExecutor) driver;
		ac.executeScript("arguments[0].click();",clickaddcontact);
		Thread.sleep(2000);
		
		for(WebElement element: allContactsList) {
			System.out.println(fname+" "+lname);
			System.out.println(element.getText());
			if(element.getText().equals(fname+" "+lname)) {
				found = true;
				System.out.println(found);
				break;
				
			}
			
		}
		return found;

	}
	
	public void viewContacts() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Use a Model')]")));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", usersettings);
		Thread.sleep(2000);

		JavascriptExecutor cn = (JavascriptExecutor) driver;
		cn.executeScript("arguments[0].click();", contactsmenu);
		Thread.sleep(1000);

	}
	
	public Boolean editFN(String name,String fname,String lname) throws Exception {
		Thread.sleep(2000);
		Boolean found = false;
		char firstLetter = name.charAt(0);
		driver.findElement(By.xpath("//div[@id='contactList']//div[contains(text(),'"+firstLetter+"')]/following-sibling::ul/li/h3")).click();
		Thread.sleep(1000);
		firstNameInEditContact.clear();
		JavascriptExecutor fnEdit = (JavascriptExecutor) driver;
		fnEdit.executeScript("arguments[0].click();", firstNameInEditContact);
		fnEdit.executeScript("arguments[0].value='"+fname+"';", firstNameInEditContact);
		
		JavascriptExecutor okBtn = (JavascriptExecutor) driver;
		okBtn.executeScript("arguments[0].click();",okButton);
		Thread.sleep(1000);
		for(WebElement element: allContactsList) {
			if(element.getText().equals(fname + " "+ lname)) {
				found = true;
				
			}
			
		}
		return found;
		
	}
	
	public Boolean deleteContact(String name) throws Exception {
		Boolean unfound = true;
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[@id='contactList']//div[@class='ioslist-group-container']/ul/li/h3[contains(text(),'"+name+"')]")).click();
		Thread.sleep(1000);
		//deleteIcon.click();
		
		JavascriptExecutor delIcon = (JavascriptExecutor) driver;
		delIcon.executeScript("arguments[0].click();",deleteIcon);
		Thread.sleep(500);
		confirmDeleteBtn.click();
		Thread.sleep(1000);
		
		for(WebElement element2 : allContactsList) {
			if(element2.getText().equals(name)) {
				unfound = false;
				break;
			}
		}
		return unfound;
	}
}
