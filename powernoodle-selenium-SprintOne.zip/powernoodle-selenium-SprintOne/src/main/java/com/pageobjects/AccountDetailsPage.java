package com.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.Base.Testbase;

public class AccountDetailsPage extends Testbase {

	@FindBy(xpath = "//*[@id='user-settings-btn']")
	WebElement usersettings;

	@FindBy(id = "userDetailsPhone")
	WebElement phonenumber;

	@FindBy(id = "userDetailsAddress")
	WebElement address;

	@FindBy(id = "userDetailsCity")
	WebElement city;

	@FindBy(id = "userDetailsProvince")
	WebElement state;

	@FindBy(id = "userDetailsCountry")
	WebElement country;

	@FindBy(id = "userDetailsPostal")
	WebElement zipcode;

	@FindBy(id = "userDetailsCompany")
	WebElement companyname;

	@FindBy(id = "userDetailsIndustry")
	WebElement industry;

	@FindBy(id = "userDetailsTimeZone")
	WebElement timezone;

	public AccountDetailsPage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}

	public void menu() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", usersettings);
	}

	public void user_info() throws InterruptedException {

		JavascriptExecutor phn = (JavascriptExecutor) driver;
		phn.executeScript("arguments[0].click();", phonenumber);
		phonenumber.clear();
		phn.executeScript("arguments[0].value='7788996655';", phonenumber);
		Thread.sleep(1000);		

		JavascriptExecutor Address = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		Address.executeScript("arguments[0].click();", address);
		address.clear();
		address.sendKeys("No.36/2,3rdfloor,Kotturpuram");		

		JavascriptExecutor City = (JavascriptExecutor) driver;
		City.executeScript("arguments[0].click();", city);
		city.clear();
		city.sendKeys("Chennai");		

		JavascriptExecutor province = (JavascriptExecutor) driver;
		province.executeScript("arguments[0].click();", state);
		state.clear();
		state.sendKeys("TamilNadu");		

		JavascriptExecutor cntry = (JavascriptExecutor) driver;
		cntry.executeScript("arguments[0].click();", country);
		country.clear();
		cntry.executeScript("arguments[0].value='India';", country);		

		JavascriptExecutor zip = (JavascriptExecutor) driver;
		zip.executeScript("arguments[0].scrollIntoView(true);",zipcode);
		zip.executeScript("arguments[0].click();", zipcode);
		zipcode.clear();
		zipcode.sendKeys("600085");
		
		JavascriptExecutor name = (JavascriptExecutor) driver;
		name.executeScript("arguments[0].click();", companyname);
		companyname.clear();
		name.executeScript("arguments[0].value='CloudNow';", companyname);
		
		JavascriptExecutor indus = (JavascriptExecutor) driver;
		indus.executeScript("arguments[0].click();", industry);
		industry.clear();
		indus.executeScript("arguments[0].value='IT-Industry';", industry);
		
		JavascriptExecutor zone = (JavascriptExecutor) driver;
		zone.executeScript("arguments[0].click();", timezone);
		timezone.clear();
		timezone.sendKeys("UTC +5:30");

		
	}

}
