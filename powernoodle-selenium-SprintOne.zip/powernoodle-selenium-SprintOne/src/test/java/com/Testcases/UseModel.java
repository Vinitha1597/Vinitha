package com.Testcases;

import org.testng.annotations.Test;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.Usemodel;

public class UseModel extends Testbase {
	LoginPage login;
	Usemodel um;

	@BeforeTest

	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("UseModel", "Adding use model");
		Assert.assertTrue(true);
	}

	@Test(priority = 1)
	public void login_admin() throws InterruptedException {
		login = new LoginPage();
		login.Login(prop.getProperty("adminusername"), prop.getProperty("adminpassword"));
		Thread.sleep(500);
		test.log(Status.INFO, "Login as Admin");
	}

	@Test(priority = 2)
	public void create_decision_space() throws InterruptedException {
		um = new Usemodel();
		um.decisionspace();
		Thread.sleep(500);
		test.log(Status.INFO, "Create DecisionSpace");
	}

	@Test(priority = 3)

	public void use_model() throws InterruptedException {
		um = new Usemodel();
		um.model();
		// Thread.sleep(1000);
		driver.navigate().refresh();
		Thread.sleep(6000);
		test.log(Status.INFO, "Add Model-Information");
	}

	@Test(priority = 4)
	public void dashboard_model() throws InterruptedException {
		um.dashboard();
		test.log(Status.INFO, "Model added successfully");
		Thread.sleep(1000);

	}

	@AfterTest

	public void teardown() {
		driver.quit();
	}
}
