package com.Testcases.nextaction.actionfilters;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class CheckTagsFilter extends Testbase {
	LoginPage login;
	
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("User checks tag filters", "User checks tag filters");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void checkTagFilters() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_checkt_tilecontributor")),prop.getProperty("expected_domainspace_to_checkt_tilecontributor"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");	
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_to_checkt_tilecontributor")));
		test.log(Status.INFO, "Set tile visibility as All from the settings dialogue");	
		test.log(Status.INFO, "Click on the filter menu");	
		test.log(Status.INFO, "Click on each tag button and check the tiles");		
		Assert.assertTrue(nac.viewTagVice());
		test.log(Status.PASS, "User is able to see all the tiles tag vice");	
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}