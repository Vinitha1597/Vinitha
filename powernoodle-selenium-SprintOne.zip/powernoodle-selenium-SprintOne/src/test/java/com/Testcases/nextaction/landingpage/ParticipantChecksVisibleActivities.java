package com.Testcases.nextaction.landingpage;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class ParticipantChecksVisibleActivities extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@Test
	public void participantChecksVisibleActivities() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Participant checks the visible activities", "Participant checks the visible activities");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
		dashboard = new DashboardPage();
	
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_visibleactivities")),prop.getProperty("expected_domainspace_for_visibleactivities"));
		test.log(Status.INFO, "Show all activities under a topic");
		Assert.assertTrue(nac.enableAllActivitiesExceptAction(prop.getProperty("topic_for_hiddenactivities")));
		test.log(Status.INFO, "Logout from this session");
		Assert.assertTrue(dashboard.logoutMenu());
		
		test.log(Status.INFO, "Login as Participant");
		login.Login(prop.getProperty("participant_email_for_nextaction"), prop.getProperty("participant_password_for_nextaction"));
		Thread.sleep(3000);	
		
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_editactiondialogue")),prop.getProperty("expected_domainspace_for_editactiondialogue"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");
		Assert.assertTrue(nac.participantclickNextActionBasedOnTopic(prop.getProperty("topic_for_visibleactivities")));
		test.log(Status.INFO, "Click on the activity settings icon and check the menus");
		Assert.assertTrue(nac.checkVisibleActivities());
		test.log(Status.PASS, "Participant is able to see all the activities which were enabled by the facilitator");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}