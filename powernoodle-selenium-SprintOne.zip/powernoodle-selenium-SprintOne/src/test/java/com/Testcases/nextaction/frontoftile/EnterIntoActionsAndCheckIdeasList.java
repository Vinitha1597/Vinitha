package com.Testcases.nextaction.frontoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class EnterIntoActionsAndCheckIdeasList extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Checking the view of ideas which are there in the actions page ", "Checking the view of ideas which are there in the actions page ");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void enterIntoActionAndCheckTheListIdeas() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_getinto_actionpage")),prop.getProperty("expected_space_header_for_enterinto_actionpage"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_to_enterinto_next_action")));
		test.log(Status.INFO, "Check the ideas view");
		Assert.assertTrue(nac.isListView());
		test.log(Status.PASS, "Ideas in the Action page is/are displayed in a list format");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}