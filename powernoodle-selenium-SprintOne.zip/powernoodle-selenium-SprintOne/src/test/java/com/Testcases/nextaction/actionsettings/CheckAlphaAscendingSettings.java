package com.Testcases.nextaction.actionsettings;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class CheckAlphaAscendingSettings extends Testbase {
	LoginPage login;
	
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Set sort by alpha ascending as the default sort order", "Set sort by alpha ascending as the default sort order");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void checkSortByAlphaAscendingSettings() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_sort_actionsettings")),prop.getProperty("expected_domainspace_to_check_sort_actionsettings"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");	
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_to_check_sort_actionsettings")));
		test.log(Status.INFO, "Set alpha ascending for the default sort order ");	
		nac.setAlphaAscendingSettings();
		test.log(Status.INFO, "Verify the tile's order");	
		Assert.assertTrue(nac.alphabeticalAscendingTiles());
		test.log(Status.PASS, "Tiles are displaying in an alpha ascending order");	
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}