package com.Testcases.nextaction.exporttiles;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class FacilitatorChecksExportTilesDialogue extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks the export tiles dialogue", "Facilitator checks the export tiles dialogue");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void facilitatorChecksExportTilesDialogue() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_checkExportDialoguebox")),prop.getProperty("expected_domainspace_to_checkExportDialoguebox"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");	
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_to_checkExportDialoguebox")));
		test.log(Status.INFO, "Click on the view filter menu");
		test.log(Status.INFO, "Click on the Export visible tiles button and check the dialogue box");
		Assert.assertTrue(nac.checkExportTilesDialogue());
		test.log(Status.PASS, "Export visible tiles dialoguebox has all the elements correctly");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}