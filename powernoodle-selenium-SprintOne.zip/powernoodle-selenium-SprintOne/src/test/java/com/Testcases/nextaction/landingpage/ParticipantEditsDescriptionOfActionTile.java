package com.Testcases.nextaction.landingpage;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class ParticipantEditsDescriptionOfActionTile extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		
		login = new LoginPage();
		
		login.Login(prop.getProperty("participant_email_for_nextaction"), prop.getProperty("participant_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_editactiondescription")),prop.getProperty("expected_domainspace_for_editactiondescription"));
		Assert.assertTrue(nac.participantclickNextActionBasedOnTopic(prop.getProperty("topic_for_editactiondescription")));
	}

	@Test(priority = 1)
	public void participantEditsDescriptionForHisorHerOwnAction() throws Exception {
		test = extent.createTest("Participant edits description for his/her own action", "Participant edits description for his/her own action");
		test.log(Status.INFO, "Login as a participant");
		test.log(Status.INFO, "Enter into a domain space");		
		test.log(Status.INFO, "Enter into the next action activity of a topic");		
		test.log(Status.INFO, "Edit description of an idea which was create by himself/herself and check the changes");		
		Assert.assertTrue(nac.editActionDescription(prop.getProperty("tileno_toedit_description_ofownaction_byparticipant"),prop.getProperty("description_toedit_description_ofownaction_byparticipant")));
		test.log(Status.PASS, "Participant edited the action description of his/her own tile successfully");		
	}
	
	@Test(priority = 2)
	public void participantEditsDescriptionForFacilitatorsAction() throws Exception {
		test = extent.createTest("Participant edits description for facilitator's action", "Participant edits description for facilitator's action");
		test.log(Status.INFO, "Login as a Participant");
		test.log(Status.INFO, "Enter into a domain space");		
		test.log(Status.INFO, "Enter into the next action activity of a topic");		
		test.log(Status.INFO, "Edit description of an idea which was create by the facilitator and check the changes");		
		Assert.assertFalse(nac.editActionDescription(prop.getProperty("tileno_toedit_description_of_facilitatorsaction_byparticipant"),prop.getProperty("description_toedit_description_of_facilitatorsaction_byparticipant")));
		test.log(Status.PASS, "Participant is unable to edit the action description of facilitator's tile");		
	}
	
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}