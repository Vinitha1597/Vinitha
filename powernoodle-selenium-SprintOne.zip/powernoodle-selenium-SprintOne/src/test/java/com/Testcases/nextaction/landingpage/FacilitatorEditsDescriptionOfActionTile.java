package com.Testcases.nextaction.landingpage;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class FacilitatorEditsDescriptionOfActionTile extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		
		login = new LoginPage();
		
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_editactiondescription")),prop.getProperty("expected_domainspace_for_editactiondescription"));
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_for_editactiondescription")));
	}

	@Test(priority = 1)
	public void facilitatorEditsDescriptionForHisorHerOwnAction() throws Exception {
		test = extent.createTest("Facilitator edits description for his/her own action", "Facilitator edits description for his/her own action");
		test.log(Status.INFO, "Login as Facilitator");
		test.log(Status.INFO, "Enter into a domain space");		
		test.log(Status.INFO, "Enter into the next action activity of a topic");		
		test.log(Status.INFO, "Edit description of an idea which was create by himself/herself and check the changes");		
		Assert.assertTrue(nac.editActionDescription(prop.getProperty("tileno_toedit_description_ofownaction_byfacilitator"),prop.getProperty("description_toedit_description_ofownaction_byfacilitator")));
		test.log(Status.PASS, "Facilitator edited the action description of his/her own tile successfully");		
	}
	
	@Test(priority = 2)
	public void facilitatorEditsDescriptionForParticipantsAction() throws Exception {
		test = extent.createTest("Facilitator edits description for participant's action", "Facilitator edits description for participant's action");
		test.log(Status.INFO, "Login as Facilitator");
		test.log(Status.INFO, "Enter into a domain space");		
		test.log(Status.INFO, "Enter into the next action activity of a topic");		
		test.log(Status.INFO, "Edit description of an idea which was create by the participant and check the changes");		
		Assert.assertTrue(nac.editActionDescription(prop.getProperty("tileno_toedit_description_of_participantsaction_byfacilitator"),prop.getProperty("description_toedit_description_of_participantsaction_byfacilitator")));
		test.log(Status.PASS, "Facilitator edited the action description of participant's tile successfully");		
	}
	
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}