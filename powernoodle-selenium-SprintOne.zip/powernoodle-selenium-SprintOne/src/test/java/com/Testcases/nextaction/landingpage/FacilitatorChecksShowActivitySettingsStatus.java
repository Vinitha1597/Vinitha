package com.Testcases.nextaction.landingpage;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class FacilitatorChecksShowActivitySettingsStatus extends Testbase {
	LoginPage login;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks show status of activities based on the eye icon", "Facilitator checks show status of activities based on the eye icon");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void facilitatorchecksShowStatus() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_showorhidestatus")),prop.getProperty("expected_domainspace_for_showorhidestatus"));
		test.log(Status.INFO, "Show all activities under a topic");
		Assert.assertTrue(nac.enableAllActivitiesExceptAction(prop.getProperty("topic_for_showorhidestatus")));
		test.log(Status.INFO, "Click on the settings icon of all activities and check the status");
		Assert.assertTrue(nac.checkShowStatus(prop.getProperty("topic_for_showorhidestatus")));
		test.log(Status.PASS, "All activities are having enabled show toggle button");

	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}