package com.Testcases.nextaction.editaction;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class ParticipantEditsFacilitatorAction extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Participant edits the facilitator's action", "Participant edits the facilitator's action");
		login = new LoginPage();
		test.log(Status.INFO, "Login as a participant");
		login.Login(prop.getProperty("participant_email_for_nextaction"), prop.getProperty("participant_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void participantEditsFacilitatorAction() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_editactiondialogue")),prop.getProperty("expected_domainspace_for_editactiondialogue"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");
		Assert.assertTrue(nac.participantclickNextActionBasedOnTopic(prop.getProperty("topic_for_editactiondialogue")));
		test.log(Status.INFO, "Search the edit action icon for the action which was created by the facilitator and check");
		
		Assert.assertFalse(nac.isEditactionPresent(prop.getProperty("tileno_to_edit_facilitatoraction_byparticipant"), prop.getProperty("actiontextselected_to_edit_facilitatoraction_byparticipant")));
		test.log(Status.PASS, "Participant is unable to edit the action which was created by the facilitator");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
