package com.Testcases.nextaction.frontoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class CheckParticipantDoneCount extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@Test
	public void checkDoneCount() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Check participant done count", "Check participant done count");
		login = new LoginPage();
		dashboard= new DashboardPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_allaction")),prop.getProperty("expected_domainspace_for_allaction"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_for_all_action")));		
		test.log(Status.INFO, "Check the participant done count");
		String donecountbefore = nac.doneCountNow();
		//Assert.assertEquals(nac.doneCountNow(), prop.getProperty("participant_donecount_beforeuserDone_forNextAction"));
		test.log(Status.INFO, "Participant done count before change is "+nac.doneCountNow());
		test.log(Status.INFO, "Logout from the facilitator account");
		Assert.assertTrue(dashboard.logoutMenu());
		
		test.log(Status.INFO, "Login from a participant account");
		login.Login(prop.getProperty("participant_email_for_nextaction"), prop.getProperty("participant_password_for_nextaction"));
		
		test.log(Status.INFO, "Enter into the domain space");
		
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_allaction")),prop.getProperty("expected_domainspace_for_allaction"));
		test.log(Status.INFO, "Enter into the next action activity of the same topic");
		Assert.assertTrue(nac.participantclickNextActionBasedOnTopic(prop.getProperty("topic_for_all_action")));
		test.log(Status.INFO, "Click the I'm done checkbox");
		nac.putIamDone();
		test.log(Status.INFO, "Logout from the participant account");
		Assert.assertTrue(dashboard.logoutMenu());
		
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_allaction")),prop.getProperty("expected_domainspace_for_allaction"));
		test.log(Status.INFO, "Enter into the next action activity of the same topic");
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_for_all_action")));
		test.log(Status.INFO, "Check the participant done count");
		String donecountafter = nac.doneCountNow();
		//Assert.assertEquals(nac.doneCountNow(), prop.getProperty("participant_donecount_afteruserDone_forNextAction"));
		test.log(Status.INFO, "Participant done count is "+nac.doneCountNow());
		
		Assert.assertNotEquals(donecountbefore,donecountafter);
		
		test.log(Status.PASS, "Participant done count gets changed when particpant checks and unchecks the I'm done checkbox..");
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}