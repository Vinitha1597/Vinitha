package com.Testcases.nextaction.actionsettings;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class CheckAllCommentVisibilitySettings extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks all comments visibility settings", "Facilitator checks all comments visibility settings");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
		dashboard = new DashboardPage();
	}

	@Test(priority = 1)
	public void checkAllCommentsVisibility() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_checkt_commentvisibility_actionsettings")),prop.getProperty("expected_domainspace_to_checkt_commentvisibility_actionsettings"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");	
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_to_checkt_commentvisibility_actionsettings")));
		test.log(Status.INFO, "Set All option for the comment visibility toggle from the activity settings window");		
		nac.setAllCommentVisibilitySettings();
		test.log(Status.INFO, "Take comment count from a tile");
		int commentsInFacilitatorTile = nac.takeCommentCount(prop.getProperty("tileno_to_checkt_commentvisibility_actionsettings"));
		test.log(Status.INFO, "Logout from the facilitator account");
		dashboard.logoutMenu();
		test.log(Status.INFO, "Login with a participant account");
		login.Login(prop.getProperty("participant_email_for_nextaction"), prop.getProperty("participant_password_for_nextaction"));
		Thread.sleep(3000);
		test.log(Status.INFO, "Enter into the same domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_checkt_commentvisibility_actionsettings")),prop.getProperty("expected_domainspace_to_checkt_commentvisibility_actionsettings"));
		test.log(Status.INFO, "Enter into the next action activity of the topic");	
		Assert.assertTrue(nac.participantclickNextActionBasedOnTopic(prop.getProperty("topic_to_checkt_commentvisibility_actionsettings")));			
		test.log(Status.INFO, "Take comment count of the same tile from which facilitator took the comment count");
		int commentsInParticipantTile = nac.takeCommentCount(prop.getProperty("tileno_to_checkt_commentvisibility_actionsettings"));
		test.log(Status.INFO, "Compare the counts which were taken from both the sessions");
		Assert.assertEquals(commentsInFacilitatorTile, commentsInParticipantTile);
		test.log(Status.PASS, "Participant is able to see all the comments of tiles");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}