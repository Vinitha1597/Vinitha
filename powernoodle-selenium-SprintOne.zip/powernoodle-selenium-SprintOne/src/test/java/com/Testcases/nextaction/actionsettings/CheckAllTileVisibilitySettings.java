package com.Testcases.nextaction.actionsettings;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class CheckAllTileVisibilitySettings extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	

	@Test
	public void checkFirstTagGroupFilters() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks all tile visibility settings", "Facilitator checks all tile visibility settings");
		login = new LoginPage();
		dashboard = new DashboardPage();
		nac = new NextActionPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);		
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_checkt_tilevisibility_actionsettings")),prop.getProperty("expected_domainspace_to_checkt_tilevisibility_actionsettings"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");	
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_to_checkt_tilevisibility_actionsettings")));
		test.log(Status.INFO, "Click on the action menu");
		test.log(Status.INFO, "Set tile visibility as All from the Action settings window");
		nac.setalltileVisibilitySettings();
		test.log(Status.INFO, "Logout from the facilitator account");
		dashboard.logoutMenu();
		
		test.log(Status.INFO, "Login with a participant account");
		login.Login(prop.getProperty("participant_email_for_nextaction"), prop.getProperty("participant_password_for_nextaction"));
		Thread.sleep(3000);	
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_checkt_tilevisibility_actionsettings")),prop.getProperty("expected_domainspace_to_checkt_tilevisibility_actionsettings"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");	
		Assert.assertTrue(nac.participantclickNextActionBasedOnTopic(prop.getProperty("topic_to_checkt_tilevisibility_actionsettings")));
		test.log(Status.INFO, "Check the tile which was created by himself");
		Assert.assertTrue(nac.isTilePresent(prop.getProperty("owntileno_to_checkt_tilevisibility_actionsettings")));
		test.log(Status.INFO, "Check the tile which was created by the facilitator or by an another participant");
		Assert.assertTrue(nac.isTilePresent(prop.getProperty("otherstileno_to_checkt_tilevisibility_actionsettings")));
		test.log(Status.PASS, "The participant is able to see all tiles of this topic");
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}