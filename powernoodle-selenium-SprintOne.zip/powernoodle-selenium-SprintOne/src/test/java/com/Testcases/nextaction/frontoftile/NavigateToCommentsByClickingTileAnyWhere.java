package com.Testcases.nextaction.frontoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class NavigateToCommentsByClickingTileAnyWhere extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		
		login = new LoginPage();
		
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_getinto_action_comment")),prop.getProperty("expected_space_header_for_enterinto_action_comment"));
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_to_enterinto_next_action_comment")));
	}

	@Test(priority = 1)
	public void viewCommentsByClickingOnTileNumber() throws Exception {
		test = extent.createTest("View comments window by clicking on a tile number area", "View comments window by clicking on a tile number area");
		test.log(Status.INFO, "Login as Facilitator");
		test.log(Status.INFO, "Enter into a domain space");		
		test.log(Status.INFO, "Enter into the next action activity of a topic");		
		test.log(Status.INFO, "Click on an idea's tile number and check");
		Assert.assertTrue(nac.clickTileNoAndCheck());
		test.log(Status.PASS, "Comments window is displaying");
	}
	
	@Test(priority = 2)
	public void viewCommentsByClickingOnTileName() throws Exception {
		test = extent.createTest("View comments window by clicking on a tile name area", "View comments window by clicking aon a tile name area");
		test.log(Status.INFO, "Login as Facilitator");
		test.log(Status.INFO, "Enter into a domain space");		
		test.log(Status.INFO, "Enter into the next action activity of a topic");		
		test.log(Status.INFO, "Click on an idea's tile name and check");
		Assert.assertTrue(nac.clickTileNameAndCheck());
		test.log(Status.PASS, "Comments window is displaying");
	}
	
	@Test(priority = 3)
	public void viewCommentsByClickingOncommentcount() throws Exception {
		test = extent.createTest("View comments window by clicking on comment count of a tile", "View comments window by clicking on comment count of a tile");
		test.log(Status.INFO, "Login as Facilitator");
		test.log(Status.INFO, "Enter into a domain space");		
		test.log(Status.INFO, "Enter into the next action activity of a topic");		
		test.log(Status.INFO, "Click on an idea's comment count and check");
		Assert.assertTrue(nac.clickTilesCommentCountAndCheck());
		test.log(Status.PASS, "Comments window is displaying");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}