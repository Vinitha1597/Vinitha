package com.Testcases.nextaction.actionfilters;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.NoodleActivity;

public class CheckNumericDescendingFilter extends Testbase {

	LoginPage login;
	NoodleActivity na;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();			
		na = new NoodleActivity();
		nac = new NextActionPage();
		test = extent.createTest("Sort by numeric descending", "Sort by numeric descending");
		test.log(Status.INFO, "Login with a valid account");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);	
		

	}

		
		@Test(priority = 1)
		public void sortByNumericDescending() throws Exception {
			test.log(Status.INFO, "Enter into a domain space");
			Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_checkt_sortingfilters")),prop.getProperty("expected_domainspace_to_checkt_sortingfilters"));		
			test.log(Status.INFO, "Enter into the next action activity of a topic");	
			Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_to_checkt_sortingfilters")));	
			test.log(Status.INFO, "Click on the filter menu");
			nac.clickFilterIcon();
			test.log(Status.INFO, "Click on the numeric descending icon and check order of the tiles");
			Assert.assertTrue(na.tilenoDescendingOrder());
			test.log(Status.PASS, "User is able to see the tiles in a numeric descending order");
			}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
}
