package com.Testcases.nextaction.editaction;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class ParticipantEditsOwnAction extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Participant edits his/her own action", "Participant edits his/her own action");
		login = new LoginPage();
		test.log(Status.INFO, "Login as a participant");
		login.Login(prop.getProperty("participant_email_for_nextaction"), prop.getProperty("participant_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void participantEditshisorherOwnAction() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_editactiondialogue")),prop.getProperty("expected_domainspace_for_editactiondialogue"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");
		Assert.assertTrue(nac.participantclickNextActionBasedOnTopic(prop.getProperty("topic_for_editactiondialogue")));
		test.log(Status.INFO, "Click on the edit action icon of an action which was created by himself/herself");
		test.log(Status.INFO, "Make changes in the field values and check");
		Assert.assertTrue(nac.editAction(prop.getProperty("tileno_to_edit_ownaction_byparticipant"), prop.getProperty("actiontextselected_to_edit_ownaction_byparticipant"),prop.getProperty("actiontext_to_edit_ownaction_byparticipant"), prop.getProperty("assignedtotext_to_edit_ownaction_byparticipant"), prop.getProperty("prioritytext_to_edit_ownaction_byparticipant"), prop.getProperty("statustext_to_edit_ownaction_byparticipant"), prop.getProperty("duedate_to_edit_ownaction_byparticipant"),prop.getProperty("duetime_to_edit_ownaction_byparticipant"), prop.getProperty("complete_to_edit_ownaction_byparticipant")));
		test.log(Status.PASS, "Participant edited his/her own action successfully");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}