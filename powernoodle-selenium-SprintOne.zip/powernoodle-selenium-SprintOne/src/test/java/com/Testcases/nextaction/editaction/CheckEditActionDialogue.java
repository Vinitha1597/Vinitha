package com.Testcases.nextaction.editaction;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class CheckEditActionDialogue extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("User checks an edit action dialogue window", "User checks an edit action dialogue window");
		login = new LoginPage();
		test.log(Status.INFO, "Login with a valid account");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void userChecksEditActionDialogue() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_editactiondialogue")),prop.getProperty("expected_domainspace_for_editactiondialogue"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_for_editactiondialogue")));
		test.log(Status.INFO, "Click on the pencil icon to enter into the edit action dialogue and check the page");
		nac.checkEditActionDialogue(prop.getProperty("textboxes_count_in_editaction_dialogue"));
		test.log(Status.PASS, "Edit action dialogue window is displaying with all the page contents.");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}