package com.Testcases.nextaction.exporttiles;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class FacilitatorChecksCommentsOfExportedTopic extends Testbase {
	LoginPage login;
	
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks comment of exported tiles in the new topic", "Facilitator checks comment of exported tiles in the new topic");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void facilitatorChecksCommentOfExportedTiles() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_checkcomment")),prop.getProperty("expected_domainspace_to_checkcomment"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");	
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_to_checkcomment")));
		test.log(Status.INFO, "Click on the view filter menu");
		test.log(Status.INFO, "Click on the Export visible tiles button and check the dialogue box");
		test.log(Status.INFO, "Select a domain space from the dropdown box");
		test.log(Status.INFO, "Add a new topic and Export the tiles");
		Assert.assertTrue(nac.exportTilesToNewTopic(prop.getProperty("domainspace_towhich_checkcomment"),prop.getProperty("newtopic_towhich_checkcomment")));
		test.log(Status.INFO, "Check the tiles of new topic and compare it with the tiles of exported topic");
		test.log(Status.INFO, "Check the comments of each tile which are exported");
		Assert.assertTrue(nac.checkCommentsOfExportedTiles(prop.getProperty("domainspace_inupperecase_towhich_checkcomment"),prop.getProperty("newtopic_towhich_checkcomment"),prop.getProperty("domainspace_to_checkcomment"),prop.getProperty("topic_to_checkcomment")));
		test.log(Status.PASS, "Comment of the exported topic are persist correctly in the new topic too");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
