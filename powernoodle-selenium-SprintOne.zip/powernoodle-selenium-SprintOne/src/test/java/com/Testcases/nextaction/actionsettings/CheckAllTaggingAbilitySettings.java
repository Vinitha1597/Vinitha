package com.Testcases.nextaction.actionsettings;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class CheckAllTaggingAbilitySettings extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;
	

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks All tagging ability settings", "Facilitator checks All tagging ability settings");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
		dashboard = new DashboardPage();
		
	}

	@Test(priority = 1)
	public void checkAllTaggingAbility() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_taggingability_actionsettings")),prop.getProperty("expected_domainspace_to_check_taggingability_actionsettings"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");	
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_to_check_taggingability_actionsettings")));
		test.log(Status.INFO, "Set all option for the tagging ability toggle from the activity settings window");		
		nac.setAllTaggingAbilitySettings();		
		test.log(Status.INFO, "Logout from the facilitator account");
		dashboard.logoutMenu();
		test.log(Status.INFO, "Login with a participant account");
		login.Login(prop.getProperty("participant_email_for_nextaction"), prop.getProperty("participant_password_for_nextaction"));
		Thread.sleep(3000);
		test.log(Status.INFO, "Enter into the same domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_taggingability_actionsettings")),prop.getProperty("expected_domainspace_to_check_taggingability_actionsettings"));
		test.log(Status.INFO, "Enter into the next action activity of the topic");	
		Assert.assertTrue(nac.participantclickNextActionBasedOnTopic(prop.getProperty("topic_to_check_taggingability_actionsettings")));			
		test.log(Status.INFO, "Enter into the tag area of a tile which was created by own and check the tagging ability");
		Assert.assertTrue(nac.checkTaggingAbilityOfATile(prop.getProperty("owntileno_to_check_taggingability_actionsettings")));
		test.log(Status.INFO, "Enter into the tag area of a tile which was created by a facilitator or any other participant and check the tagging ability");
		Assert.assertTrue(nac.checkTaggingAbilityOfATile(prop.getProperty("othertileno_to_check_taggingability_actionsettings")));
		test.log(Status.PASS, "Participant is able to tag any tiles which was created by own and by others");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
