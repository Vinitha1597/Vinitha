package com.Testcases.nextaction.addaction;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class FacilitatorAddsAnAction extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator adds an action for the idea", "Facilitator adds an action for the idea");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void facilitatorAddingAction() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_addactiondialogue")),prop.getProperty("expected_domainspace_for_addactiondialogue"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_for_addactiondialogue")));
		test.log(Status.INFO, "Click on the add action button of an idea and fill the fields");
		test.log(Status.INFO, "Click on the Add button and check");
		Assert.assertTrue(nac.addAction(prop.getProperty("tileno_to_addaction_byfacilitator"), prop.getProperty("actiontext_to_addaction_byfacilitator"), prop.getProperty("assignedtotext_to_addaction_byfacilitator"), prop.getProperty("prioritytext_to_addaction_byfacilitator"), prop.getProperty("statustext_to_addaction_byfacilitator"), prop.getProperty("duedate_to_addaction_byfacilitator"),prop.getProperty("duetime_to_addaction_byfacilitator"), prop.getProperty("complete_to_addaction_byfacilitator")));
		test.log(Status.PASS, "Facilitator is added an action for the tile successfully");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}