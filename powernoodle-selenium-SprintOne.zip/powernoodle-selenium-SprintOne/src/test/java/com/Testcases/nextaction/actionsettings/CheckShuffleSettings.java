package com.Testcases.nextaction.actionsettings;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class CheckShuffleSettings extends Testbase {
	LoginPage login;
	
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Set shuffled order as the default sort order", "Set shuffled order as the default sort order");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void checkShuffleSettings() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_sort_actionsettings")),prop.getProperty("expected_domainspace_to_check_sort_actionsettings"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");	
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_to_check_sort_actionsettings")));
		test.log(Status.INFO, "Set shuffle option for the default sort order ");	
		nac.setShuffleSettings();
		test.log(Status.INFO, "Verify the tile's order");	
		Assert.assertTrue(nac.tileshuffledOrder());
		test.log(Status.PASS, "Tiles are displaying in a shuffled order");	
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}