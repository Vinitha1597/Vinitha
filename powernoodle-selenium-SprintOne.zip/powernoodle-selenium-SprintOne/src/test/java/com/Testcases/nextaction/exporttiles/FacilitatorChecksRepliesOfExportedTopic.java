package com.Testcases.nextaction.exporttiles;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class FacilitatorChecksRepliesOfExportedTopic extends Testbase {
	LoginPage login;
	
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks replies of exported tiles in the new topic", "Facilitator checks replies of exported tiles in the new topic");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void facilitatorChecksRepliesOfExportedTiles() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_checkreplies")),prop.getProperty("expected_domainspace_to_checkreplies"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");	
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_to_checkreplies")));
		test.log(Status.INFO, "Click on the view filter menu");
		test.log(Status.INFO, "Click on the Export visible tiles button and check the dialogue box");
		test.log(Status.INFO, "Select a domain space from the dropdown box");
		test.log(Status.INFO, "Add a new topic and Export the tiles");
		Assert.assertTrue(nac.exportTilesToNewTopic(prop.getProperty("domainspace_towhich_checkreplies"),prop.getProperty("newtopic_towhich_checkreplies")));
		test.log(Status.INFO, "Check the tiles of new topic and compare it with the tiles of exported topic");
		test.log(Status.INFO, "Check the replies of each tile which are exported");
		Assert.assertTrue(nac.checkRepliesOfExportedTiles(prop.getProperty("domainspace_inupperecase_towhich_checkreplies"),prop.getProperty("newtopic_towhich_checkreplies"),prop.getProperty("domainspace_to_checkreplies"),prop.getProperty("topic_to_checkreplies")));
		test.log(Status.PASS, "Replies of the exported topic are persist correctly in the new topic too");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
