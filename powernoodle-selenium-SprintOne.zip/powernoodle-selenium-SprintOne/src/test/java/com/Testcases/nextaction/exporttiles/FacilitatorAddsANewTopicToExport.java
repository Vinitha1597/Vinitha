package com.Testcases.nextaction.exporttiles;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class FacilitatorAddsANewTopicToExport extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator adds a new topic to export visible tiles", "Facilitator adds a new topic to export visible tiles");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void facilitatorAddsNewTopicToExport() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_checkExportDialoguebox")),prop.getProperty("expected_domainspace_to_checkExportDialoguebox"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");	
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_to_checkExportDialoguebox")));
		test.log(Status.INFO, "Click on the view filter menu");
		test.log(Status.INFO, "Click on the Export visible tiles button and check the dialogue box");
		test.log(Status.INFO, "Select a domain space from the dropdown box");
		test.log(Status.INFO, "Add a new topic and check");
		Assert.assertTrue(nac.addANewTopicToExport(prop.getProperty("domainspacename_tochoose_fromdropdown"),prop.getProperty("newtopicname_toaddanewtopic")));
		test.log(Status.PASS, "Facilitator added a new topic to export visible tiles successfully");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}