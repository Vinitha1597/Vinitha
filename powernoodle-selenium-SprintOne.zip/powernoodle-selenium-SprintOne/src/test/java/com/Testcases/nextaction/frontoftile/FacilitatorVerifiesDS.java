package com.Testcases.nextaction.frontoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;

public class FacilitatorVerifiesDS extends Testbase {
	LoginPage login;
	DashboardPage dashboard;

	@BeforeTest
	public void startup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator verifies the account", "Facilitator checks the session");
		login = new LoginPage();
		test.log(Status.INFO, "Login as a facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		
	}

	@Test(priority = 1)
	public void checkDashboard() throws Exception {
		Thread.sleep(1000);
		dashboard= new DashboardPage();
		test.log(Status.INFO, "Checking of help menu");
		Assert.assertTrue(dashboard.checkHelpMenu());
		test.log(Status.INFO, "Checking of facilitator session's Dashboard menus");
		Assert.assertTrue(dashboard.checkAreMenusThere());
		test.log(Status.INFO, "Checking of elements in all decision space");
		Assert.assertTrue(dashboard.checkAllDecisionSpace());
		test.log(Status.INFO, "Checking of a space's elements");
		Assert.assertTrue(dashboard.checkSpaces());
		test.log(Status.INFO, "Checking of menus under settings icon");
		Assert.assertTrue(dashboard.checkSettingsMenus());
		test.log(Status.INFO, "Checking of Account details icon");
		Assert.assertTrue(dashboard.checkAccountDetailsMenu());
		test.log(Status.INFO, "Checking of contacts menu");
		Assert.assertTrue(dashboard.checkContactsMenu());		
		test.log(Status.INFO, "Checking of logout menus");
		Assert.assertTrue(dashboard.logoutMenu());
		test.log(Status.PASS, "Facilitator's dashboard page validated successfully");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
