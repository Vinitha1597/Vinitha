package com.Testcases.nextaction.actionsettings;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class CheckHideFileVisibilitySettings extends Testbase {
	LoginPage login;
	
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks hide option of File visibility toggle", "Facilitator checks hide option of File visibility toggle");
		test.log(Status.INFO, "Login as  a Facilitator");
		login = new LoginPage();
		
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
		
	}

	
	
	@Test(priority = 1)
	public void checkHideFileVisibility() throws Exception {
		
		test.log(Status.INFO, "Enter into a domain space");	
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_checkt_filevisibility_actionsettings")),prop.getProperty("expected_domainspace_to_checkt_filevisibility_actionsettings"));		
		test.log(Status.INFO, "Enter into the next action activity of a topic");
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_to_checkt_filevisibility_actionsettings")));
		test.log(Status.INFO, "Set hide option for the File visibility toggle in the activity settings window");	
		test.log(Status.INFO, "Click on a tile and check the Add File button");
		Assert.assertTrue(nac.checkHideFileVisibility());
		test.log(Status.PASS, "User is not able to see the Add file button in the tiles. File visibility hidden successfully.");	
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}