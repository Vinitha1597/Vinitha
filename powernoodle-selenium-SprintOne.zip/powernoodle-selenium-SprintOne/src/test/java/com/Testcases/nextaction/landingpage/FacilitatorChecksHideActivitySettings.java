package com.Testcases.nextaction.landingpage;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class FacilitatorChecksHideActivitySettings extends Testbase {
	LoginPage login;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks hide status of activities based on the eye icon", "Facilitator checks hide status of activities based on the eye icon");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void facilitatorchecksHideStatus() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_showorhidestatus")),prop.getProperty("expected_domainspace_for_showorhidestatus"));
		test.log(Status.INFO, "Hide all activities under a topic");
		Assert.assertTrue(nac.hideAllActivitiesExceptAction(prop.getProperty("topic_for_showorhidestatus")));
		test.log(Status.INFO, "Click on the settings icon of all activities and check the status");
		Assert.assertTrue(nac.checkHideStatus(prop.getProperty("topic_for_showorhidestatus")));
		test.log(Status.PASS, "All activities are having enabled Hide toggle button");

	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}