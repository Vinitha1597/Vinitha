package com.Testcases.nextaction.frontoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class CheckAddActionButton extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Check add action button of an idea", "Check add action button of an idea");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void enterIntoActionAndCheckTheListIdeas() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_getinto_addaction")),prop.getProperty("expected_space_header_for_enterinto_addaction"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_to_enterinto_addaction")));		
		test.log(Status.INFO, "Click on the Add action button of an idea and check");
		Assert.assertTrue(nac.checkAddActionButton());
		test.log(Status.PASS, "The user is able to see the add action dialogue window successfully");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}