package com.Testcases.nextaction.landingpage;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class ParticipantChecksHiddenActivities extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@Test
	public void participantChecksHiddenActivities() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Participant checks the hidden activities", "Participant checks the hidden activities");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
		dashboard = new DashboardPage();
	
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_hiddenactivities")),prop.getProperty("expected_domainspace_for_hiddenactivities"));
		test.log(Status.INFO, "Hide all activities under a topic except next action activity");
		Assert.assertTrue(nac.hideAllActivitiesExceptAction(prop.getProperty("topic_for_hiddenactivities")));
		test.log(Status.INFO, "Logout from this session");
		Assert.assertTrue(dashboard.logoutMenu());
		
		test.log(Status.INFO, "Login as Participant");
		login.Login(prop.getProperty("participant_email_for_nextaction"), prop.getProperty("participant_password_for_nextaction"));
		Thread.sleep(3000);	
		
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_editactiondialogue")),prop.getProperty("expected_domainspace_for_editactiondialogue"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");
		Assert.assertTrue(nac.participantclickNextActionBasedOnTopic(prop.getProperty("topic_for_editactiondialogue")));
		test.log(Status.INFO, "Click on the activity settings icon and check the menus");
		Assert.assertTrue(nac.checkHiddenActivities());
		test.log(Status.PASS, "Participant is unable to see the hidden activities");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}