package com.Testcases.nextaction.frontoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;


public class FacilitatorOpensNextActionActivity extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator opens the next action activity for a topic", "Facilitator opens the next action activity for a topic");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void enablesNextActionActivity() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_enabling_actionicon")),prop.getProperty("expected_space_header_for_enabling_actionicon"));
		test.log(Status.INFO, "Click on the actions settings icon of a topic to which you want to open the Actions");
		test.log(Status.INFO, "Open the next action activity for a topic and verify the Actions button");
		Assert.assertTrue(nac.openNextActionForATopic(prop.getProperty("topic_to_enable_next_action")));
		test.log(Status.INFO, "Action button is clickable now.");
		test.log(Status.PASS, "Action activity is opened for the topic successfully");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}

