package com.Testcases.nextaction.editaction;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class FacilitatorDeletesParticipantsAction extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator deletes participant's action", "Facilitator deletes participant's action");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void facilitatorDeletesParticipantsAction() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_deleteactione")),prop.getProperty("expected_domainspace_for_deleteaction"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_for_deleteaction")));
		test.log(Status.INFO, "Click on the edit action icon of an action which was created by a participant");
		test.log(Status.INFO, "Click on the delete icon and check");
		Assert.assertTrue(nac.deleteAction(prop.getProperty("tileno_to_delete_participantsaction_byfacilitator"), prop.getProperty("actiontextselected_to_delete_participantsaction_byfacilitator")));
		test.log(Status.PASS, "Facilitator deleted the participant's action successfully");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
