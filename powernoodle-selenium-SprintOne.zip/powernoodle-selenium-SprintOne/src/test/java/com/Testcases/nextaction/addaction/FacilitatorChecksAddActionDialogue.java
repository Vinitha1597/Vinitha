package com.Testcases.nextaction.addaction;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;

public class FacilitatorChecksAddActionDialogue extends Testbase {
	LoginPage login;
	DashboardPage dashboard;
	NextActionPage nac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks add action button of an idea", "Facilitator checks add action button of an idea");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_nextaction"), prop.getProperty("facilitator_password_for_nextaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
	}

	@Test(priority = 1)
	public void facilitatorchecksAddActionFrame() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_for_addactiondialogue")),prop.getProperty("expected_domainspace_for_addactiondialogue"));
		test.log(Status.INFO, "Enter into the next action activity of a topic");
		Assert.assertTrue(nac.clickNextActionBasedOnTopic(prop.getProperty("topic_for_addactiondialogue")));		
		test.log(Status.INFO, "Click on the Add action button of an idea and check the textboxes and add action button");
		Assert.assertTrue(nac.checkActionDialogue(prop.getProperty("textboxes_count_in_addaction_dialogue")));
		test.log(Status.PASS, "The facilitator is able to see the add action dialogue window successfully");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}