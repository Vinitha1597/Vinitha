package com.Testcases;

import org.testng.annotations.Test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.Forgotpassword;

public class ForgotPassword extends Testbase {

	Forgotpassword pswd;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();

		pswd = new Forgotpassword();
		pswd.validate_email(prop.getProperty("forgot_accounts_email"));

		driver.navigate().to("https://mail.google.com/");
		pswd = new Forgotpassword();
		pswd.email_validations(prop.getProperty("userid"), prop.getProperty("pswd"));
		Thread.sleep(4000);
		List<WebElement> a = driver.findElements(By.xpath("//*[@class='yW']/span"));
		// System.out.println(a.size());
		for (int i = 0; i < a.size(); i++) {
			// System.out.println(a.get(i).getText());
			if (a.get(i).getText().equals("no-reply")) {
				a.get(i).click();
				break;
			}
		}
		Thread.sleep(10000);

		pswd = new Forgotpassword();
		((JavascriptExecutor) driver).executeScript("scroll(0,250);");
		Thread.sleep(2000);
		pswd.new_tabToResetPassword();
		
	}
	@Test(priority = 0)
	public void setPasswordWithEmptyFields()throws Exception{

		test = extent.createTest("Reset password with empty fields", "Password reset with empty fields");
		test.log(Status.INFO, "Left all fields as empty");
		Assert.assertTrue(pswd.setPasswordWithEmptyFields());
		test.log(Status.INFO, "Error message displayed correctly");
		Thread.sleep(1000);
	}

	@Test(priority = 1)
	public void setPasswordWithEmptyConfirmPswdField() throws Exception {
		
		test = extent.createTest("Reset password with empty confirm password field",
				"Password reset with empty confirm password field");
		test.log(Status.INFO, "Left confirm password field as empty");
		Assert.assertTrue(pswd.setPasswordWithEmptyConfirmswdField());
		test.log(Status.INFO, "Error message displayed correctly");
		pswd.clickBackToResetLink();
	}

	@Test(priority = 2)
	public void setPasswordWithMismatchPswds() throws Exception {
		
		test = extent.createTest("Reset password with mismatch passwords",
				"Password reset with mismatch value in the new password and confirm password fields");
		test.log(Status.INFO, "Fill the fields with mismatch values");
		Assert.assertTrue(pswd.setPasswordWithMismatchPasswords());
		test.log(Status.INFO, "Error message displayed correctly");
	}

	@Test(priority = 3)
	public void setPasswordWithInvalidPassword() throws Exception {
		
		test = extent.createTest("Reset password with invalid password", "Password reset with an invalid password");
		test.log(Status.INFO, "Filled the fields with an invalid password");
		Assert.assertTrue(pswd.setInvalidPassword());
		test.log(Status.INFO, "Error message displayed correctly");
	}

	@Test(priority = 4)
	public void setPassword() throws Exception {
		
		pswd.setPassword();
	}

	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
