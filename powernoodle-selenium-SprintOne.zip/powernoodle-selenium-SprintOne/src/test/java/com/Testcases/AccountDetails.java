package com.Testcases;

import org.testng.annotations.Test;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;


import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.AccountDetailsPage;
import com.pageobjects.LoginPage;

public class AccountDetails extends Testbase {
	LoginPage login;
	AccountDetailsPage ad;
	@BeforeTest

	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("AccountInformation", "Adding account details");
		Assert.assertTrue(true);
	}

	@Test(priority = 1)
	public void user_login() throws InterruptedException {
		login = new LoginPage();
		login.Login(prop.getProperty("username_to_add_details"), prop.getProperty("password_for_account_details"));
		Thread.sleep(3000);
		 test.log(Status.INFO, "Login as User");

	}

	@Test(priority = 2)
	public void menu_settings() {
		ad = new AccountDetailsPage();
		ad.menu();
		 test.log(Status.INFO, "Click on Settings to navigate Account Information Page ");


	}
	@Test(priority = 3)
	public void add_information() throws InterruptedException {
		test.log(Status.INFO, "Fill the Information of user");
		ad.user_info();
		test.log(Status.INFO, "Account details updated successfully");

	}
	@AfterTest
	public void teardown() {
		driver.quit();
	}
}
