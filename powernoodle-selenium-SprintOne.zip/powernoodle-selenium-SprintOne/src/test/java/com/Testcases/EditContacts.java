package com.Testcases;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.Contactspage;
import com.pageobjects.LoginPage;

public class EditContacts extends Testbase {
	LoginPage login;
	Contactspage cn;

	@BeforeTest

	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Edit Contacts", "Edit Contact");
		Assert.assertTrue(true);

	}

	@Test(priority = 1)
	public void user_login() throws InterruptedException {
		login = new LoginPage();
		login.Login(prop.getProperty("adminusername"), prop.getProperty("adminpassword"));
		Thread.sleep(3000);
		test.log(Status.INFO, "Login as Admin");
	}

	@Test(priority = 2)
	public void Goto_Settings_contact() throws Exception {
		cn = new Contactspage();
		cn.viewContacts();
		Thread.sleep(500);
		test.log(Status.INFO, "Navigate to Contacts Page");
	}

	@Test(priority = 3)
	public void edit_contact_details() throws Exception {
		cn = new Contactspage();
		test.log(Status.INFO, "Change Details to edit the contact");
		Assert.assertTrue(cn.editFN(prop.getProperty("nameofcontacttoedit"), prop.getProperty("newfname"),prop.getProperty("lastnameoftheeditedaccount")));
		test.log(Status.INFO, "Contact edited successfully");
	}

	@AfterTest

	public void teardown() {
		driver.quit();
	}
}

