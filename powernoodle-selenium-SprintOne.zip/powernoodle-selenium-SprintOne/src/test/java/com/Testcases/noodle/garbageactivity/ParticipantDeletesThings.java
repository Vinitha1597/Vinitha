package com.Testcases.noodle.garbageactivity;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class ParticipantDeletesThings extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("user_email_for_noodle"), prop.getProperty("user_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);

	}

		
	@Test(priority = 1)
	public void participantDeleteAnOwnComment() throws Exception {
		test = extent.createTest("Participant deleting his/her own comment", "Participant deleting his/her own comment");
		test.log(Status.INFO, "Login as a participant");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on a tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_toDelete_Owncomment_fromParticipant_Account"),prop.getProperty("tilename_toDelete_Owncomment_fromParticipant_Account"));
		test.log(Status.INFO, "Click on a delete icon of the comment and check it");
		Assert.assertTrue(na.deleteComment(prop.getProperty("tileno_toDelete_Owncomment_fromParticipant_Account"),prop.getProperty("tilename_toDelete_Owncomment_fromParticipant_Account"),prop.getProperty("commentNo_toDelete_Owncomment_fromParticipant_Account")));
		test.log(Status.INFO, "Participant deleted his/her own comment for a tile successfully");
		
	}
		
	@Test(priority = 2)
	public void participantDeleteAFacilitatorsComment() throws Exception {
		test = extent.createTest("Participant deleting a facilitator's comment", "Participant deleting a facilitator's comment");
		test.log(Status.INFO, "Login as a participant");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on a tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_toDelete_Facilitatorscomment_fromParticipant_Account"),prop.getProperty("tilename_toDelete_Facilitatorscomment_fromParticipant_Account"));
		test.log(Status.INFO, "Click on a delete icon of the comment which was posted by the facilitator and check it");
		Assert.assertTrue(na.deleteOthersComment(prop.getProperty("commentNo_toDelete_Facilitatorcomment_fromParticipant_Account")));
		test.log(Status.INFO, "Participant is restricted to delete other's comments");
		
	}
		
	@Test(priority = 3)
		public void participantDeleteAnOwnReply() throws Exception {
		test = extent.createTest("Participant deleting his/her own reply", "Participant deleting his/her own reply");
		test.log(Status.INFO, "Login as a participant");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on a tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_toDelete_OwnReply_fromParticipant_Account"),prop.getProperty("tilename_toDelete_OwnReply_fromParticipant_Account"));
		test.log(Status.INFO, "Click on a delete icon of the reply and check it");
		Assert.assertTrue(na.deleteReply(prop.getProperty("replyNo_toDelete_OwnReply_fromParticipant_Account")));
		test.log(Status.INFO, "Participant deleted his/her own reply for a comment successfully");
			
		}
		
		@Test(priority = 4)
				public void participantDeleteAFacilitatorsReply() throws Exception {
			test = extent.createTest("Participant deleting a facilitator's reply", "Participant deleting a facilitator's reply");
			test.log(Status.INFO, "Login as a participant");
			test.log(Status.INFO, "Navigate to Noodle page");
			test.log(Status.INFO, "Click on a tile");
			na.enterIntoSpecificTile(prop.getProperty("tileno_toDelete_FacilitatorsReply_fromParticipant_Account"),prop.getProperty("tilename_toDelete_FacilitatorsReply_fromParticipant_Account"));
			test.log(Status.INFO, "Click on a delete icon of the reply which was posted by the facilitator and check it");
			Assert.assertTrue(na.deleteOthersReply(prop.getProperty("replyNo_toDelete_FacilitatorReply_fromParticipant_Account")));
			test.log(Status.INFO, "Participant is restricted to delete other's reply");
					
				}
				@Test(priority = 5)
				public void participantDeleteAnOwnTile() throws Exception {
					test = extent.createTest("Participant deleting his/her own tile", "Participant deleting his/her own tile");
					test.log(Status.INFO, "Login as a participant");
					test.log(Status.INFO, "Navigate to Noodle page");
					test.log(Status.INFO, "Click on a tile");
					na.enterIntoSpecificTile(prop.getProperty("tileno_toDelete_OwnTile_fromParticipant_Account"),prop.getProperty("tilename_toDelete_OwnTile_fromParticipant_Account"));
					test.log(Status.INFO, "Click on a delete icon of the tile and check it");
					Assert.assertTrue(na.deleteTile(prop.getProperty("tileno_toDelete_OwnTile_fromParticipant_Account"),prop.getProperty("tilename_toDelete_OwnTile_fromParticipant_Account")));
					test.log(Status.INFO, "Participant deleted his/her own tile successfully");
					
				}
				
				@Test(priority = 6)
				public void participantDeleteAFacilitatorsTile() throws Exception {
					test = extent.createTest("Participant deleting a facilitator's tile", "Participant deleting a facilitator's tile");
					test.log(Status.INFO, "Login as a participant");
					test.log(Status.INFO, "Navigate to Noodle page");
					test.log(Status.INFO, "Click on a tile");
					na.enterIntoSpecificTile(prop.getProperty("tileno_toDelete_FacilitatorsTile_fromParticipant_Account"),prop.getProperty("tilename_toDelete_FacilitatorsTile_fromParticipant_Account"));
					test.log(Status.INFO, "Click on a delete icon of the tile which was created by the facilitator and check it");
					Assert.assertTrue(na.deleteOthersTile(prop.getProperty("tileno_toDelete_FacilitatorsTile_fromParticipant_Account"),prop.getProperty("tilename_toDelete_FacilitatorsTile_fromParticipant_Account")));
					test.log(Status.INFO, "Participant is restricted to delete other's tile");
					
				}
	
		
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}

