package com.Testcases.noodle.backoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class CheckingOfPlusMinusIconOfReply extends Testbase{
	
	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);

	}

	
	@Test(priority = 1)
	public void verifyPlusAndMinusOfComment() throws Exception {
		test = extent.createTest("checking Plus and minus icon of comments", "checking Plus and minus icon of comments");
		na.enterIntoSpecificTile(prop.getProperty("tileno_to_check_plus_minus_of_comments"),prop.getProperty("tilename_to_check_plus_minus_of_comments"));
		test.log(Status.INFO, "Click on the minus icon and check it");
		test.log(Status.INFO, "Click on the plus icon and check the replies");		
		Assert.assertTrue(na.commentPlusMinusMenus());
		test.log(Status.INFO, "Plus icon shows the replies of particular comment and Minus icon hides the replies");
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
