package com.Testcases.noodle.activityinstruction;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class EditActivityInstruction extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		
		

	}

		
	@Test(priority = 1)
	public void editActivityInstruction() throws Exception {
		test = extent.createTest("Facilitator editing the activity instructions", "Facilitator editing the activity instructions");
		test.log(Status.INFO, "Login with a facilitator account");
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		test.log(Status.INFO, "Navigate to Noodle page");
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);
		test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
		test.log(Status.INFO, "click on the Noodle menu");
		Assert.assertTrue(na.checkViewNoodleSettingsPanel());		
		test.log(Status.INFO, "click on edit instruction button and edit the instruction");
		test.log(Status.INFO, "click on the instruction icon and check the instructions");
		Assert.assertTrue(na.editInstruction(prop.getProperty("instruction_to_edit_noodle_activity_instruction")));
		test.log(Status.INFO, "Facilitator edited Instruction successfully");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
}
