package com.Testcases.noodle.filevisibility;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class ParticipantHandlesFiles extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("user_email_for_noodle"), prop.getProperty("user_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodleBasedOnTopicInUserAccount(prop.getProperty("topic_to_handle_files_byparticipant")));		
		Thread.sleep(1000);

	}

		
	@Test(priority = 1)
	public void participantUploadAFile() throws Exception {
		test = extent.createTest("Participant uploading a file", "Participant uploading a file");
		test.log(Status.INFO, "Login as a participant");
		test.log(Status.INFO, "Enter into a noodle");
		test.log(Status.INFO, "Enter into a tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_to_addfile_from_participant"),prop.getProperty("tilename_to_addfile_from_participant"));
		test.log(Status.INFO, "Upload a file and check it");
		Assert.assertTrue(na.addFileForTile(prop.getProperty("filename_toadd_byparticipant")));
		test.log(Status.INFO, "Participant is able to upload a file successfully");
		
	}
	
	@Test(priority = 2)
	public void facilitatorAddingFileNameAndDescription() throws Exception {
		test = extent.createTest("Participant adding filename and uploader name", "Participant adding filename and uploader name");
		test.log(Status.INFO, "Login as a participant");
		test.log(Status.INFO, "Enter into a noodle");
		test.log(Status.INFO, "Enter into a tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_to_addfile_from_participant"),prop.getProperty("tilename_to_addfile_from_participant"));
		test.log(Status.INFO, "Upload a file and check it");
		Assert.assertTrue(na.addNamesForFile(prop.getProperty("filename_toadd_descripotion_byparticipant"),prop.getProperty("filedescription_toadd_byparticipant"),prop.getProperty("filename_toadd_byparticipant_forFile")));
		test.log(Status.INFO, "File name and description added successfully");
		
	}
	
	@Test(priority = 3)
		public void facilitatorDeletingAnOwnFile() throws Exception {
			test = extent.createTest("Participant deleting a file", "Participant deleting a file");
			test.log(Status.INFO, "Login as a participant");
			test.log(Status.INFO, "Enter into a noodle");
			test.log(Status.INFO, "Enter into a tile");
			na.enterIntoSpecificTile(prop.getProperty("tileno_to_addfile_from_participant"),prop.getProperty("tilename_to_addfile_from_participant"));
			test.log(Status.INFO, "Click on delete icon of his/her own file");
			Assert.assertTrue(na.deleteAFile(prop.getProperty("filename_todelete_byparticipant")));
			test.log(Status.INFO, "Participant deleted his/her own file successfully");
			
		}
	
	@Test(priority = 4)
	public void facilitatorDeletingFacilitatorsFile() throws Exception {
		test = extent.createTest("Participant deleting a facilitator's file", "Participant deleting a participant's file");
		test.log(Status.INFO, "Login as a participant");
		test.log(Status.INFO, "Enter into a noodle");
		test.log(Status.INFO, "Enter into a tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_to_addfile_from_participant"),prop.getProperty("tilename_to_addfile_from_participant"));
		test.log(Status.INFO, "Click on delete icon of his/her own file");
		Assert.assertFalse(na.deleteAFile(prop.getProperty("facilitators_filename_todelete_byparticipant")));
		test.log(Status.INFO, "Participant is restricted to delete other's file");
		
	}
		
			
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}

