package com.Testcases.noodle.backoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class ParticipantEditComments extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("user_email_for_noodle"), prop.getProperty("user_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);

	}

		
	@Test(priority = 1)
	public void participantEditOwnCommentForAtile() throws Exception {
		test = extent.createTest("Participant editing his/her own comment for a tile", "Participant editing his/her own comment for a tile");
		test.log(Status.INFO, "Login as a participant");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on any one tile");
		na.enterIntoSpecificTile(prop.getProperty("tile_no_to_editComment_ofOwnComment_byParticipant"),prop.getProperty("tile_name_to_editComment_ofOwnComment_byParticipant"));
		test.log(Status.INFO, "Edit comments and click on the tick mark");
		test.log(Status.INFO, "enter into the same tile and check the edited comments");
		Assert.assertTrue(na.editCommentForATile(prop.getProperty("tile_no_to_editComment_ofOwnComment_byParticipant"),prop.getProperty("tile_name_to_editComment_ofOwnComment_byParticipant"),prop.getProperty("tile_oldcomment_to_editComment_ofOwnComment_byParticipant"),prop.getProperty("tile_newcomment_to_editComment_ofOwnComment_byParticipant")));
		test.log(Status.INFO, "Comment which was posted by himself/herself edited successfully for a tile.");
		
	}
	
	@Test(priority = 2)
	public void participantEditAnotherParticipantsCommentForAtile() throws Exception {
		test = extent.createTest("Participant editing another participant's comment for a tile", "Participant adding comments for other's tile");
		test.log(Status.INFO, "Login as a participant");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on any one tile");
		na.enterIntoSpecificTile(prop.getProperty("tile_no_to_editComment_ofCoparticipantComment_byParticipant"),prop.getProperty("tile_name_to_editComment_ofCoparticipantComment_byParticipant"));
		test.log(Status.INFO, "Check the comment which was posted by a co-participant");
		Assert.assertTrue(na.editOthersCommentForATile(prop.getProperty("tile_oldcomment_to_editComment_ofCoparticipantComment_byParticipant")));
		test.log(Status.INFO, "Comments which was posted by a co-participant is not editable for other participant.");
		
		
	}
	
	@Test(priority = 3)
	public void participantEditFacilitatorsCommentForAtile() throws Exception {
		test = extent.createTest("Participant editing a facilitator's comment for a tile", "Participant editing a facilitator's comment for a tile");
		test.log(Status.INFO, "Login as a participant");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on any one tile");
		na.enterIntoSpecificTile(prop.getProperty("tile_no_to_editComment_ofFacilitatorComment_byParticipant"),prop.getProperty("tile_name_to_editComment_ofFacilitatorComment_byParticipant"));
		test.log(Status.INFO, "Check the comment which was posted by a facilitator");
		Assert.assertTrue(na.editOthersCommentForATile(prop.getProperty("tile_oldcomment_to_editComment_ofFacilitatorComment_byParticipant")));
		test.log(Status.INFO, "Comments which was posted by a facilitator is not editable for other participants.");
		
		
	}
		
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}

