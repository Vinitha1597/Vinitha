package com.Testcases.noodle.backoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class FacilitatorEditComments extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);

	}

		
	@Test(priority = 1)
	public void facilitatorEditOwnCommentForAtile() throws Exception {
		test = extent.createTest("Facilitator editing his/her own comment for a tile", "Facilitator editing his/her own comment for a tile");
		test.log(Status.INFO, "Login as a facilitator");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on any one tile");
		na.enterIntoSpecificTile(prop.getProperty("tile_no_to_editComment_ofOwnComment_byFacilitator"),prop.getProperty("tile_name_to_editComment_ofOwnComment_byFacilitator"));
		test.log(Status.INFO, "Edit comments and click on the tick mark");
		test.log(Status.INFO, "enter into the same tile and check the edited comments");
		Assert.assertTrue(na.editCommentForATile(prop.getProperty("tile_no_to_editComment_ofOwnComment_byFacilitator"),prop.getProperty("tile_name_to_editComment_ofOwnComment_byFacilitator"),prop.getProperty("tile_oldcomment_to_editComment_ofOwnComment_byFacilitator"),prop.getProperty("tile_newcomment_to_editComment_ofOwnComment_byFacilitator")));
		test.log(Status.INFO, "Comment which was posted by himself/herself edited successfully for a tile.");
		
	}
	
	@Test(priority = 2)
	public void facilitatorEditAParticipantsCommentForAtile() throws Exception {
		test = extent.createTest("Facilitator editing a participant's comment for a tile", "Facilitator editing a participant's comment for a tile");
		test.log(Status.INFO, "Login as a facilitator");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on any one tile");
		na.enterIntoSpecificTile(prop.getProperty("tile_no_to_editComment_ofAparticipantComment_byFacilitator"),prop.getProperty("tile_name_to_editComment_ofAparticipantComment_byFacilitator"));
		test.log(Status.INFO, "Edit comments and click on the tick mark");
		test.log(Status.INFO, "enter into the same tile and check the edited comments");
		Assert.assertTrue(na.editCommentForATile(prop.getProperty("tile_no_to_editComment_ofAparticipantComment_byFacilitator"),prop.getProperty("tile_name_to_editComment_ofAparticipantComment_byFacilitator"),prop.getProperty("tile_oldcomment_to_editComment_ofAparticipantComment_byFacilitator"),prop.getProperty("tile_newcomment_to_editComment_ofAparticipantComment_byFacilitator")));
		test.log(Status.INFO, "Comment which was posted by a participant edited by the facilitator successfully for a tile.");
		
		
	}
	
		
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}

