package com.Testcases.noodle.activityinstruction;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class AddTextFormattingInActivityInstruction extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);
		
		

	}

		
	@Test(priority = 1)
	public void addBulletsInActivityInstruction() throws Exception {
		test = extent.createTest("Facilitator adding bullets in the activity instructions", "Facilitator adding bullets in the activity instructions");
		test.log(Status.INFO, "Login with a facilitator account");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
		test.log(Status.INFO, "click on the Noodle menu");
		Assert.assertTrue(na.checkViewNoodleSettingsPanel());		
		test.log(Status.INFO, "click on edit instruction button and add bullets in the instruction");
		test.log(Status.INFO, "click on the instruction icon and check the instructions");
		Assert.assertTrue(na.addbulletsInInstruction(prop.getProperty("text_toadd_bullets_in_thenoodleactivity_instruction")));
		test.log(Status.INFO, "Facilitator added bullets in the Instructions successfully");
	}
	
	@Test(priority = 2)
	public void addBoldTextInActivityInstruction() throws Exception {
		test = extent.createTest("Facilitator bolds a text in the activity instructions", "Facilitator bolds a text in the activity instructions");
		test.log(Status.INFO, "Login with a facilitator account");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
		test.log(Status.INFO, "click on the Noodle menu");
		Assert.assertTrue(na.checkViewNoodleSettingsPanel());		
		test.log(Status.INFO, "click on edit instruction button and bold a text in the instruction");
		test.log(Status.INFO, "click on the instruction icon and check the instructions");
		Assert.assertTrue(na.boldTextInInstruction(prop.getProperty("text_toadd_boldtext_in_thenoodleactivity_instruction")));
		test.log(Status.INFO, "Facilitator bolded a text in the Instructions successfully");
	}
	
	@Test(priority = 3)
	public void addItalicTextInActivityInstruction() throws Exception {
		test = extent.createTest("Facilitator italics a text in the activity instructions", "Facilitator italics a text in the activity instructions");
		test.log(Status.INFO, "Login with a facilitator account");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
		test.log(Status.INFO, "click on the Noodle menu");
		Assert.assertTrue(na.checkViewNoodleSettingsPanel());		
		test.log(Status.INFO, "click on edit instruction button and add italic style for a text text in the instruction");
		test.log(Status.INFO, "click on the instruction icon and check the instructions");
		Assert.assertTrue(na.italicTextInInstruction(prop.getProperty("text_toadd_italictext_in_thenoodleactivity_instruction")));
		test.log(Status.INFO, "Facilitator added italic text in the Instructions successfully");
	}
	
	//@Test(priority = 4)
	public void addUnderlinedTextInActivityInstruction() throws Exception {
		test = extent.createTest("Facilitator underline a text in the activity instructions", "Facilitator underline a text in the activity instructions");
		test.log(Status.INFO, "Login with a facilitator account");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
		test.log(Status.INFO, "click on the Noodle menu");
		Assert.assertTrue(na.checkViewNoodleSettingsPanel());		
		test.log(Status.INFO, "click on edit instruction button and underline a text in the instruction");
		test.log(Status.INFO, "click on the instruction icon and check the instructions");
		Assert.assertTrue(na.underlineTextInInstruction(prop.getProperty("text_toadd_underlinedtext_in_thenoodleactivity_instruction")));
		test.log(Status.INFO, "Facilitator underlined a text in the Instructions successfully");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
}
