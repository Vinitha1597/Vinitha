package com.Testcases.noodle.backoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class FacilitatorAddsDescription extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);

	}

	@Test(priority = 1)
	public void participantAddingDescriptionForOwnTile() throws Exception {
		test = extent.createTest("Facilitator adding description for his/her own tile", "Facilitator adding description for his/her own tile");
		test.log(Status.INFO, "Login as a facilitator");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the tile which has created by the particular facilitator");
		na.enterIntoSpecificTile(prop.getProperty("tile_no_to_add_description_by_facilitator"),prop.getProperty("tile_name_to_add_description_by_facilitator"));
		test.log(Status.INFO, "Add description and click on the tick mark");
		Assert.assertTrue(na.addDescription(prop.getProperty("tile_no_to_add_description_by_facilitator"),prop.getProperty("tile_name_to_add_description_by_facilitator"),prop.getProperty("tile_description_to_add_description_by_facilitator")));
		test.log(Status.INFO, "Description added successfully for a tile.");
		
	}
	
	@Test(priority = 2)
	public void facilitatorEditingDescriptionForOwntile() throws Exception {
		test = extent.createTest("Facilitator edits description for his/her own tile", "Facilitator edits description for his/her own tile");
		test.log(Status.INFO, "Login as a facilitator");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the tile which has created by the particular facilitator");
		na.enterIntoSpecificTile(prop.getProperty("tile_no_to_edit_description_by_facilitator"),prop.getProperty("tile_name_to_edit_description_by_facilitator"));
		test.log(Status.INFO, "Edit description and click on the tick mark");
		Assert.assertTrue(na.editDescription(prop.getProperty("tile_no_to_edit_description_by_facilitator"),prop.getProperty("tile_name_to_edit_description_by_facilitator"),prop.getProperty("tile_description_to_edit_by_facilitator")));
		test.log(Status.INFO, "Description edited successfully for a tile.");
		
	}
	
	@Test(priority = 3)
	public void facilitatorAddingDescriptionForAParticipantsTile() throws Exception {
		test = extent.createTest("Facilitator adding description for a participant's tile", "Facilitator adding description for a participant's tile");
		test.log(Status.INFO, "Login as a Facilitator");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the tile which was created by the participant");
		na.enterIntoSpecificTile(prop.getProperty("tile_no_to_add_description_whichwascreated_by_a_participant"),prop.getProperty("tile_name_to_add_description_whichwascreated_by_a_participant"));
		test.log(Status.INFO, "Click on the plus mark and check the description text box");
		Assert.assertTrue(na.addDescription(prop.getProperty("tile_no_to_add_description_whichwascreated_by_a_participant"),prop.getProperty("tile_name_to_add_description_whichwascreated_by_a_participant"),prop.getProperty("tile_description_to_add_description_whichwascreated_by_a_participant")));
		test.log(Status.INFO, "Facilitator added description for a tile which was created by the participant");
		
	}
	
	@Test(priority = 4)
	public void facilitatorEditingDescriptionForAParticipantstile() throws Exception {
	test = extent.createTest("Facilitator edits description for a participant's tile", "Facilitator edits description for a participant's tile");
	test.log(Status.INFO, "Login as a facilitator");
	test.log(Status.INFO, "Navigate to Noodle page");
	test.log(Status.INFO, "Click on the tile which was created by the participant");
	na.enterIntoSpecificTile(prop.getProperty("tile_no_to_edit_description_whichwascreated_by_a_participant"),prop.getProperty("tile_name_to_edit_description_whichwascreated_by_a_participant"));
	test.log(Status.INFO, "Check the description text box");
	Assert.assertTrue(na.editDescription(prop.getProperty("tile_no_to_edit_description_whichwascreated_by_a_participant"),prop.getProperty("tile_name_to_edit_description_whichwascreated_by_a_participant"),prop.getProperty("tile_description_to_edit_description_whichwascreated_by_a_participant")));
	test.log(Status.INFO, "Facilitator edited description for a tile which was created by the participant");
		
	}
	
		
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}

