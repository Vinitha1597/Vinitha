package com.Testcases.noodle.activityinstruction;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class CheckAllCommentsVisibility extends Testbase {

	LoginPage login;
	NoodleActivity na;
	int commentcountinfacilitatorpagebeforereset;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		test = extent.createTest("Reset comment visibility as all", "Reset comment visibility as all");
		test.log(Status.INFO, "Login with a facilitator account");
		
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));
				
		test.log(Status.INFO, "Navigate to Noodle page");
		Assert.assertTrue(na.clickNoodleBasedOnTopic(prop.getProperty("topic_tocheck_tile_visibility")));		
		Thread.sleep(1000);
		test.log(Status.INFO, "Add comment for a tile");
		Assert.assertTrue(na.addCommentForTile(prop.getProperty("tileno_tocheck_comment_visibility_beforeandafter_reset"), prop.getProperty("comment_toadd_before_reset_commentvisibility")));
		test.log(Status.INFO, "Take a comment count before reset the comment visibility");
		commentcountinfacilitatorpagebeforereset = na.takeCommentCountOfATile(prop.getProperty("tileno_tocheck_comment_visibility_beforeandafter_reset"));
		test.log(Status.INFO, "Enter into noodle settings panel");
		Assert.assertTrue(na.checkViewNoodleSettingsPanel());
		test.log(Status.INFO, "Click on the All option of comment visibility");
		test.log(Status.INFO, "Take comment count now and check it with the previously taken count");
		Assert.assertEquals(commentcountinfacilitatorpagebeforereset,na.setcommentVisibilityAll(prop.getProperty("tileno_tocheck_comment_visibility_beforeandafter_reset")));
		test.log(Status.INFO, "Comment count is same before and after reset the comment visibility");
	}

		
	@Test(priority = 1)
	public void checkAllCommentVisibility() throws Exception {
		
		test.log(Status.INFO, "Login with a participant account");
		login.Login(prop.getProperty("user_email_for_noodle"), prop.getProperty("user_password_for_noodle"));
		test.log(Status.INFO, "Enter into the particular decision space and check the noodle icon of the topic");
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));
		test.log(Status.INFO, "Click on Noodle button undr the searched topic");
		Assert.assertTrue(na.clickNoodleBasedOnTopicInUserAccount(prop.getProperty("topic_tocheck_tile_visibility")));
		test.log(Status.INFO, "Take the comment count and check it into the facilitator's comment count");
		int commentcountinparticipantpage = na.takeCommentCountOfATile(prop.getProperty("tileno_tocheck_comment_visibility_beforeandafter_reset"));
		Assert.assertEquals(commentcountinparticipantpage,commentcountinfacilitatorpagebeforereset);
		test.log(Status.INFO, "Comment count of the tile in participant's page is lsame as the facilitator's page");
	}
	@AfterTest
	public void teardown() {
		driver.quit();
	}
}

