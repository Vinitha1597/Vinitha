package com.Testcases.noodle.textformatting;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class VerifyHyperLinkInTileTitle extends Testbase{
	
	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodleBasedOnTopic(prop.getProperty("topic_to_check_textformatting")));		
		Thread.sleep(1000);

	}
	@Test(priority = 1)
	public void verifyHyperlinkInTitle() throws Exception {
		test = extent.createTest("Adding hyperlinks in title of a tile", "adding hyperlinks in title of a tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_to_check_hyperlink_for_title"),prop.getProperty("tilename_to_check_hyperlink_for_title"));
		test.log(Status.INFO, "Enter into a tile and select a title");
		test.log(Status.INFO, "Click on hyperlink icon and check it");
		test.log(Status.INFO, "Click on the hyperlink and check it");
		test.log(Status.INFO, "Close the tile and check the tile's title");
		Assert.assertTrue(na.hyperlinkedTitle(prop.getProperty("tilename_to_check_hyperlink_for_title"),prop.getProperty("url_to_check_hyperlink_for_title")));
		test.log(Status.INFO, "User is able to make a hyperlink text in the title field");
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
