package com.Testcases.noodle.filevisibility;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class FacilitatorHandlesFile extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodleBasedOnTopic(prop.getProperty("topic_to_handle_files_byfacilitator")));		
		Thread.sleep(1000);

	}

		
	@Test(priority = 1)
	public void facilitatorUploadingAFile() throws Exception {
		test = extent.createTest("Facilitator uploading a file", "Facilitator uploading a file");
		test.log(Status.INFO, "Login as a facilitator");
		test.log(Status.INFO, "Enter into a noodle");
		test.log(Status.INFO, "Enter into a tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_to_addfile_from_facilitator"),prop.getProperty("tilename_to_addfile_from_facilitator"));
		test.log(Status.INFO, "Upload a file and check it");
		Assert.assertTrue(na.addFileForTile(prop.getProperty("filename_toadd_byfacilitator")));
		test.log(Status.INFO, "Facilitator is able to upload a file successfully");
		
	}
	
	@Test(priority = 2)
	public void facilitatorAddingFileNameAndDescription() throws Exception {
		test = extent.createTest("Facilitator adding filename and description name", "Facilitator adding filename and description name");
		test.log(Status.INFO, "Login as a facilitator");
		test.log(Status.INFO, "Enter into a noodle");
		test.log(Status.INFO, "Enter into a tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_to_addfile_from_facilitator"),prop.getProperty("tilename_to_addfile_from_facilitator"));
		test.log(Status.INFO, "Upload a file and check it");
		Assert.assertTrue(na.addNamesForFile(prop.getProperty("filename_toadd_descripotion_byfacilitator"),prop.getProperty("filedescription_toadd_byfacilitator"),prop.getProperty("filename_toadd_byfacilitator_forFile")));
		test.log(Status.INFO, "File name and description added successfully");
		
	}
	
	@Test(priority = 3)
		public void facilitatorDeletingAFile() throws Exception {
			test = extent.createTest("Facilitator deleting a file", "Facilitator deleting a file");
			test.log(Status.INFO, "Login as a facilitator");
			test.log(Status.INFO, "Enter into a noodle");
			test.log(Status.INFO, "Enter into a tile");
			na.enterIntoSpecificTile(prop.getProperty("tileno_to_addfile_from_facilitator"),prop.getProperty("tilename_to_addfile_from_facilitator"));
			test.log(Status.INFO, "Click on delete icon of a file");
			Assert.assertTrue(na.deleteAFile(prop.getProperty("filename_todelete_byfacilitator")));
			test.log(Status.INFO, "Facilitator deleted a file successfully");
			
		}
			
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
