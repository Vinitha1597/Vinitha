package com.Testcases.noodle.backoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class ParticipantEditingTileTitle extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("user_email_for_noodle"), prop.getProperty("user_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);

	}

		
	@Test(priority = 1)
	public void participantEditingTitleForOwntile() throws Exception {
		test = extent.createTest("Participant edits title for his/her own tile", "Participant edits title for his/her own tile");
		test.log(Status.INFO, "Login as a participant");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the tile which was created by the particular participant");
		na.enterIntoSpecificTile(prop.getProperty("tile_no_to_edit_title_whichwascreated_by_own"),prop.getProperty("tile_name_to_edit_title_whichwascreated_by_own"));
		test.log(Status.INFO, "Edit title and click on the tick mark");
		Assert.assertTrue(na.editTile(prop.getProperty("tile_no_to_edit_title_whichwascreated_by_own"),prop.getProperty("tile_newtitle_to_edit_title_whichwascreated_by_own")));
		test.log(Status.INFO, "Title edited successfully for a tile.");
		
	}
		
	@Test(priority = 2)
	public void participantEditingTitleForAnotherParticipantstile() throws Exception {
		test = extent.createTest("Participant edits title for another participant's tile", "Participant edits title for another participant's tile");
		test.log(Status.INFO, "Login as a participant");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the tile which has created by an another participant");
		na.enterIntoSpecificTile(prop.getProperty("tile_no_to_edit_title_whichwascreated_by_another_participant"),prop.getProperty("tile_name_to_edit_title_whichwascreated_by_another_participant"));
		test.log(Status.INFO, "Check the title text box");
		Assert.assertTrue(na.editTileOfOthersTile());
		test.log(Status.INFO, "Participant restricted to edit tile of the tile which was created by another participant.");
		
	}
		
	@Test(priority = 3)
		public void participantEditingTitleForAFacilitatorstile() throws Exception {
			test = extent.createTest("Participant edits title for a facilitator's tile", "Participant edits title for a facilitator's tile");
			test.log(Status.INFO, "Login as a participant");
			test.log(Status.INFO, "Navigate to Noodle page");
			test.log(Status.INFO, "Click on the tile which was created by a facilitator");
			na.enterIntoSpecificTile(prop.getProperty("tile_no_to_edit_title_whichwascreated_by_a_facilitator"),prop.getProperty("tile_name_to_edit_title_whichwascreated_by_a_facilitator"));
			test.log(Status.INFO, "Check the title text box");
			Assert.assertTrue(na.editTileOfOthersTile());
			test.log(Status.INFO, "Participant restricted to edit title of the tile which was created by a facilitator.");
			
		}
	
		
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
