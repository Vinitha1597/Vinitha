package com.Testcases.noodle.backoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class ParticipantEditsReplyForComment extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("user_email_for_noodle"), prop.getProperty("user_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);

	}

		
	@Test(priority = 1)
	public void participantEditAnOwnReply() throws Exception {
		test = extent.createTest("Participant editing his/her own reply", "Participant editing his/her own reply");
		test.log(Status.INFO, "Login as a participant");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on any one tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_toEdit_reply_forOwncomment_fromParticipant_Account"),prop.getProperty("tilename_toEdit_reply_forOwncomment_fromParticipant_Account"));
		test.log(Status.INFO, "Edit a reply which was posted by himself or herself and click on the tick mark");
		test.log(Status.INFO, "Enter into the same tile and check the reply");
		Assert.assertTrue(na.editReply(prop.getProperty("tileno_toEdit_reply_forOwncomment_fromParticipant_Account"),prop.getProperty("tilename_toEdit_reply_forOwncomment_fromParticipant_Account"),prop.getProperty("oldreply_toEdit_reply_forOwncomment_fromParticipant_Account"),prop.getProperty("newreply_toEdit_reply_forOwncomment_fromParticipant_Account")));
		test.log(Status.INFO, "Reply edited successfully for a comment.");
		
	}
	
	@Test(priority = 2)
	public void participantEditOthersReply() throws Exception {
		test = extent.createTest("Participant editing other's reply", "Participant editing other's reply");
		test.log(Status.INFO, "Login as a participant");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on any one tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_toEdit_reply_forOthersComment_fromParticipant_Account"),prop.getProperty("tilename_toEdit_reply_forOthersComment_fromParticipant_Account"));
		test.log(Status.INFO, "Try to edit a reply which was posted by an another participant or by a facilitator");
		Assert.assertTrue(na.editReplyOfOthers(prop.getProperty("oldreply_toEdit_reply_forOthersComment_fromParticipant_Account")));
		test.log(Status.INFO, "Reply which was posted by others is unable to edit from the participant's account");
		
		
	}
	
	
		
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
