package com.Testcases.noodle.backoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class FacilitatorAddReplyForAComment extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);

	}

		
	@Test(priority = 1)
	public void facilitatorAddReplyForAnOwnComment() throws Exception {
		test = extent.createTest("Facilitator adding reply for his/her own comment", "Facilitator adding reply for his/her own comment");
		test.log(Status.INFO, "Login as a facilitator");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on any one tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_toAdd_reply_forOwncomment_fromFacilitator_Account"),prop.getProperty("tilename_toAdd_reply_forOwncomment_fromFacilitator_Account"));
		test.log(Status.INFO, "Add reply for a comment which was posted by the particular facilitator and click on the tick mark");
		test.log(Status.INFO, "Enter into the same tile and check the reply");
		Assert.assertTrue(na.addReply(prop.getProperty("tileno_toAdd_reply_forOwncomment_fromFacilitator_Account"),prop.getProperty("tilename_toAdd_reply_forOwncomment_fromFacilitator_Account"),prop.getProperty("comment_toAdd_reply_forOwncomment_fromFacilitator_Account"),prop.getProperty("reply_toAdd_reply_forOwncomment_fromFacilitator_Account")));
		test.log(Status.INFO, "Reply added successfully for a comment.");
		
	}
	
	
			
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
