package com.Testcases.noodle.textformatting;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class CheckingOfHyperlinksInTile extends Testbase{
	
	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodleBasedOnTopic(prop.getProperty("topic_to_check_textformatting")));		
		Thread.sleep(1000);

	}

	
	@Test(priority = 1)
	public void verifyHyperlinkInDesc() throws Exception {
		test = extent.createTest("Adding hyperlinks in description", "adding hyperlinks in description");
		na.enterIntoSpecificTile(prop.getProperty("tileno_to_check_hyperlink_for_descriptiontext"),prop.getProperty("tilename_to_check_hyperlink_for_descriptiontext"));
		test.log(Status.INFO, "Enter into a tile and select a description");
		test.log(Status.INFO, "Click on hyperlink icon and check it");
		test.log(Status.INFO, "Click on the hyperlink and check it");
		Assert.assertTrue(na.hyperlinkedDescription(prop.getProperty("tileno_to_check_hyperlink_for_descriptiontext"),prop.getProperty("tilename_to_check_hyperlink_for_descriptiontext"),prop.getProperty("description_to_check_hyperlink_for_descriptionText"),prop.getProperty("url_to_check_hyperlink_for_descriptionText")));
		test.log(Status.INFO, "User is able to make a hyperlink text in the description field");
		
	}
	
	@Test(priority = 2)
	public void verifyHyperlinkInComment() throws Exception {
		test = extent.createTest("Adding hyperlinks in comment", "adding hyperlinks in comment");
		na.enterIntoSpecificTile(prop.getProperty("tileno_to_check_hyperlink_for_comment"),prop.getProperty("tilename_to_check_hyperlink_for_comment"));
		test.log(Status.INFO, "Enter into a tile and select a comment");
		test.log(Status.INFO, "Click on hyperlink icon and check it");
		test.log(Status.INFO, "Click on the hyperlink and check it");	
		Assert.assertTrue(na.hyperlinkedComment(prop.getProperty("tileno_to_check_hyperlink_for_comment"),prop.getProperty("tilename_to_check_hyperlink_for_comment"),prop.getProperty("comment_to_check_hyperlink_for_comment"),prop.getProperty("url_to_check_hyperlink_for_comment")));
		test.log(Status.INFO, "User is able to make a hyperlink text in the comment field");
		
	}
	
	@Test(priority = 3)
		public void verifyHyperlinkInReply() throws Exception {
		test = extent.createTest("Adding hyperlinks in reply", "adding hyperlinks in reply");
		na.enterIntoSpecificTile(prop.getProperty("tileno_to_check_hyperlink_for_reply"),prop.getProperty("tilename_to_check_hyperlink_for_reply"));
		test.log(Status.INFO, "Enter into a tile and select a reply");
		test.log(Status.INFO, "Click on hyperlink icon and check it");
		test.log(Status.INFO, "Click on the hyperlink and check it");	
		Assert.assertTrue(na.hyperlinkedReply(prop.getProperty("tileno_to_check_hyperlink_for_reply"),prop.getProperty("tilename_to_check_hyperlink_for_reply"),prop.getProperty("comment_to_check_hyperlink_for_reply"),prop.getProperty("reply_to_check_hyperlink_for_reply"),prop.getProperty("url_to_check_hyperlink_for_reply")));
		test.log(Status.INFO, "User is able to make a hyperlink text in the reply field");
			
		}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
