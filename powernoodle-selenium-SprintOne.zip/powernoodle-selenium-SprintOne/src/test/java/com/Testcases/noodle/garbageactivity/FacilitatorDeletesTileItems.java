package com.Testcases.noodle.garbageactivity;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class FacilitatorDeletesTileItems extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);

	}

		
	@Test(priority = 1)
	public void facilitatorDeleteAnOwnComment() throws Exception {
		test = extent.createTest("Facilitator deletes his/her own comment", "Facilitator deletes his/her own comment");
		test.log(Status.INFO, "Login as a facilitator");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on a tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_toDelete_Owncomment_fromFacilitator_Account"),prop.getProperty("tilename_toDelete_Owncomment_fromFacilitator_Account"));
		test.log(Status.INFO, "Click on a delete icon of the comment and check it");
		Assert.assertTrue(na.deleteComment(prop.getProperty("tileno_toDelete_Owncomment_fromFacilitator_Account"),prop.getProperty("tilename_toDelete_Owncomment_fromFacilitator_Account"),prop.getProperty("commentNo_toDelete_Owncomment_fromFacilitator_Account")));
		test.log(Status.INFO, "Facilitator deleted his/her own comment for a tile successfully");
		
	}
		
	@Test(priority = 2)
	public void facilitatorDeleteAParticipantsComment() throws Exception {
		test = extent.createTest("Facilitator deletes a participant's comment", "Facilitator deletes a participant's comment");
		test.log(Status.INFO, "Login as a facilitator");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on a tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_toDelete_Participantscomment_fromFacilitator_Account"),prop.getProperty("tilename_toDelete_Participantscomment_fromFacilitator_Account"));
		test.log(Status.INFO, "Click on a delete icon of the comment which was posted by any one participant and check it");
		Assert.assertTrue(na.deleteComment(prop.getProperty("tileno_toDelete_Participantscomment_fromFacilitator_Account"),prop.getProperty("tilename_toDelete_Participantscomment_fromFacilitator_Account"),prop.getProperty("commentNo_toDelete_Participantscomment_fromFacilitator_Account")));
		test.log(Status.INFO, "Facilitator deleted the participant's comment successfully");
		
	}
		
	@Test(priority = 3)
		public void facilitatorDeleteAnOwnReply() throws Exception {
		test = extent.createTest("Facilitator deletes his/her own reply", "Facilitator deletes his/her own reply");
		test.log(Status.INFO, "Login as a facilitator");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on a tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_toDelete_OwnReply_fromFacilitator_Account"),prop.getProperty("tilename_toDelete_OwnReply_fromFacilitator_Account"));
		test.log(Status.INFO, "Click on a delete icon of the reply and check it");
		Assert.assertTrue(na.deleteReply(prop.getProperty("replyNo_toDelete_OwnReply_fromFacilitator_Account")));
		test.log(Status.INFO, "Facilitator deleted his/her own reply for a comment successfully");
			
		}
		
		@Test(priority = 4)
		public void facilitatorDeleteAParticipantsReply() throws Exception {
			test = extent.createTest("Facilitator deletes a participant's reply", "Facilitator deletes a participant's reply");
			test.log(Status.INFO, "Login as a facilitator");
			test.log(Status.INFO, "Navigate to Noodle page");
			test.log(Status.INFO, "Click on a tile");
			na.enterIntoSpecificTile(prop.getProperty("tileno_toDelete_ParticipantsReply_fromFacilitator_Account"),prop.getProperty("tilename_toDelete_ParticipantsReply_fromFacilitator_Account"));
			test.log(Status.INFO, "Click on a delete icon of the reply and check it");
			Assert.assertTrue(na.deleteReply(prop.getProperty("replyNo_toDelete_ParticipantsReply_fromFacilitator_Account")));
			test.log(Status.INFO, "Facilitator deleted the participant's reply successfully");
				
			}
		@Test(priority = 5)
		public void facilitatorDeleteAnOwnTile() throws Exception {
			test = extent.createTest("Facilitator deletes his/her own tile", "Facilitator deletes his/her own tile");
			test.log(Status.INFO, "Login as a facilitator");
			test.log(Status.INFO, "Navigate to Noodle page");
			test.log(Status.INFO, "Click on a tile");
			na.enterIntoSpecificTile(prop.getProperty("tileno_toDelete_OwnTile_fromFacilitator_Account"),prop.getProperty("tilename_toDelete_OwnTile_fromFacilitator_Account"));
			test.log(Status.INFO, "Click on a delete icon of the tile and check it");
			Assert.assertTrue(na.deleteTile(prop.getProperty("tileno_toDelete_OwnTile_fromFacilitator_Account"),prop.getProperty("tilename_toDelete_OwnTile_fromFacilitator_Account")));
			test.log(Status.INFO, "facilitator deleted his/her own tile successfully");
					
		}
				
		@Test(priority = 6)
		public void facilitatorDeleteAParticipantsTile() throws Exception {
			test = extent.createTest("Facilitator deletes a participant's tile", "Facilitator deletes a participant's tile");
			test.log(Status.INFO, "Login as a facilitator");
			test.log(Status.INFO, "Navigate to Noodle page");
			test.log(Status.INFO, "Click on a tile");
			na.enterIntoSpecificTile(prop.getProperty("tileno_toDelete_ParticipantsTile_fromFacilitator_Account"),prop.getProperty("tilename_toDelete_ParticipantsTile_fromFacilitator_Account"));
			test.log(Status.INFO, "Click on a delete icon of the tile which was created by a participant and check it");
			Assert.assertTrue(na.deleteTile(prop.getProperty("tileno_toDelete_ParticipantsTile_fromFacilitator_Account"),prop.getProperty("tilename_toDelete_ParticipantsTile_fromFacilitator_Account")));
			test.log(Status.INFO, "Facilitator deleted the tile which was created by the participant successfully");
					
		}
	
		
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
