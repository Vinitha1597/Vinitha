package com.Testcases.noodle.frontoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class FacilitatorVerifiesDoneCount extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest

	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Participants count verification", "Verify participants count who done with decision making");
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);
		test.log(Status.INFO, "Login as Facilitator");
		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));
		test.log(Status.INFO, "Navigate to decision space page");
		Assert.assertTrue(na.clickNoodle());
		test.log(Status.INFO, "Navigate to Noodle page");
		Thread.sleep(1000);

	}


	@Test(priority = 1)
	public void verifyParticipantsDoneCount() throws Exception {
		test.log(Status.INFO, "Take the participants count of particular task from facilitator's account");
		Assert.assertTrue(na.verifyDoneCount(prop.getProperty("participant_done_count")));
		test.log(Status.INFO, "Participants done count verified successfully");
		
	}
	
	@Test(priority = 2)
	public void verifyParticipantsDoneCountBygoingForthandback()throws Exception{
		
		test.log(Status.INFO, "Check participant's done count before going to an another topic");
		test.log(Status.INFO, "Switch to another topic");
		test.log(Status.INFO, "Check participant's done count after coming from an another topic");
		Assert.assertTrue(na.verifyDoneCountBySwitchforthAndBack(prop.getProperty("participant_done_count"),prop.getProperty("topic_name_to_check_donecount")));
		test.log(Status.INFO, "Participants done count verified successfully by switching topics forth and back.");
	}
	
	@AfterTest

	public void teardown() {
		driver.quit();
	}

}

