package com.Testcases.noodle.backoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class FacilitatorEditsReplyOfAComment extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);

	}

		
	@Test(priority = 1)
	public void facilitatorEditAnOwnReply() throws Exception {
		test = extent.createTest("Facilitator editing his/her own reply", "Facilitator editing his/her own reply");
		test.log(Status.INFO, "Login as a facilitator");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on any one tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_toEdit_reply_forOwncomment_fromFacilitator_Account"),prop.getProperty("tilename_toEdit_reply_forOwncomment_fromFacilitator_Account"));
		test.log(Status.INFO, "Edit a reply which was posted by himself or herself and click on the tick mark");
		test.log(Status.INFO, "Enter into the same tile and check the reply");
		Assert.assertTrue(na.editReply(prop.getProperty("tileno_toEdit_reply_forOwncomment_fromFacilitator_Account"),prop.getProperty("tilename_toEdit_reply_forOwncomment_fromFacilitator_Account"),prop.getProperty("oldreply_toEdit_reply_forOwncomment_fromFacilitator_Account"),prop.getProperty("newreply_toEdit_reply_forOwncomment_fromFacilitator_Account")));
		test.log(Status.INFO, "Reply edited successfully for a comment.");
		
	}
	
	@Test(priority = 2)
	public void facilitatorEditOthersReply() throws Exception {
		test = extent.createTest("Facilitator editing other's reply", "Facilitator editing other's reply");
		test.log(Status.INFO, "Login as a facilitator");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on any one tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_toEdit_reply_forOthersComment_fromFacilitator_Account"),prop.getProperty("tilename_toEdit_reply_forOthersComment_fromFacilitator_Account"));
		test.log(Status.INFO, "Try to edit a reply which was posted by an another participant");
		Assert.assertTrue(na.editReply(prop.getProperty("tileno_toEdit_reply_forOthersComment_fromFacilitator_Account"),prop.getProperty("tilename_toEdit_reply_forOthersComment_fromFacilitator_Account"),prop.getProperty("oldreply_toEdit_reply_forOthersComment_fromFacilitator_Account"),prop.getProperty("newreply_toEdit_reply_forOtherscomment_fromFacilitator_Account")));
		test.log(Status.INFO, "Reply which was posted by others is edited successfully");
		
		
	}
	
	
		
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}

