package com.Testcases.noodle.activityinstruction;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class CheckAddTileVisibilityYes extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		
		
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		
		Assert.assertTrue(na.clickNoodleBasedOnTopic(prop.getProperty("topic_tocheck_tile_visibility")));		
		Thread.sleep(1000);
		

	}

	
	
	@Test(priority = 1)
	public void checkAddTileVisibilityYes() throws Exception {
		test = extent.createTest("Reset add tile visibility as yes", "Reset add tile visibility as yes");
		test.log(Status.INFO, "Login with a facilitator account");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Enter into noodle settings panel");
		Assert.assertTrue(na.checkViewNoodleSettingsPanel());
		test.log(Status.INFO, "Click on the yes button of add tile visibility to view the Add tile option from the noodle page");
		Assert.assertTrue(na.setaddtileVisibilityYes());
		
	}
	@AfterTest
	public void teardown() {
		driver.quit();
	}
}