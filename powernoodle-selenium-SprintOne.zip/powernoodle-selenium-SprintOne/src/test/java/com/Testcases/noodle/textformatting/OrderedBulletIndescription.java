package com.Testcases.noodle.textformatting;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class OrderedBulletIndescription extends Testbase{
	
	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);

	}

	
	@Test(priority = 1)
	public void verifyBulletsForDesc() throws Exception {
		test = extent.createTest("checking bullets for description", "checking bullets for description");
		na.enterIntoSpecificTile(prop.getProperty("tileno_to_check_numberbullets_for_descriptiontext"),prop.getProperty("tilename_to_check_numberbullets_for_descriptiontext"));
		test.log(Status.INFO, "Enter into a tile and select a description");
		test.log(Status.INFO, "Click on Dot icon and check it");
		test.log(Status.INFO, "Click on Number bullet (1.) icon and check it");
		Assert.assertTrue(na.orderedBulletInDesc(prop.getProperty("description_to_check_numberbullets_for_descriptionText")));
		test.log(Status.INFO, "User is able to make bullets in the description field.");
		
	}
	
	
	
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
}