package com.Testcases.noodle.garbageactivity;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class DeleteCommentWhichHasReply extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);

	}

		
	@Test(priority = 1)
	public void facilitatorDeleteACommentWhichHasReply() throws Exception {
		test = extent.createTest("Facilitator deletes a comment which has replies", "Facilitator deletes a comment which has replies");
		test.log(Status.INFO, "Login as a facilitator");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on a tile");
		na.enterIntoSpecificTile(prop.getProperty("tileno_toDelete_commentWhichHasReply_fromFacilitator_Account"),prop.getProperty("tilename_toDelete_commentWhichHasReply_fromFacilitator_Account"));
		test.log(Status.INFO, "Click on a delete icon of the comment and check it");
		Assert.assertTrue(na.deleteCommentWhichHasReply(prop.getProperty("commentNo_toDelete_commentWhichHasReply_fromFacilitator_Account"),(prop.getProperty("replyNo_toDelete_commentWhichHasReply_fromFacilitator_Account"))));
		test.log(Status.INFO, "Comment text deleted without the comment bar and replies which are there under the comment remains as it is.");
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
		
}
