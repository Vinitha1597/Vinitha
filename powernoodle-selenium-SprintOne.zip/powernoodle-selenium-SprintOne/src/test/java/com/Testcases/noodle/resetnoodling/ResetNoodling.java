package com.Testcases.noodle.resetnoodling;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class ResetNoodling extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@Test
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		test = extent.createTest("Checking of reset noodling actions", "Checking of reset noodling actions");
		test.log(Status.INFO, "Login with a facilitator account");
		
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		test.log(Status.INFO, "Navigate to decision space");
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		test.log(Status.INFO, "Navigate to Noodle page");
		Assert.assertTrue(na.clickNoodleBasedOnTopic(prop.getProperty("topic_name_to_resetnoodling")));		
		Thread.sleep(1000);
		test.log(Status.INFO, "Enter into noodle settings panel");
		Assert.assertTrue(na.checkViewNoodleSettingsPanel());
		test.log(Status.INFO, "Check cross mark and confirm buttons in the Are you sure alert window");
		test.log(Status.INFO, "Check the tiles after reset noodling");
		Assert.assertTrue(na.resetNoodling());
		test.log(Status.INFO, "Clicking on reset noodling deletes all the ideas for the particular topic");
		
	}
	@AfterTest
	public void teardown() {
		driver.quit();
	}
}

