package com.Testcases.noodle.instructionpanel;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class UserCheckingInstructionPanel extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest

	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		
		login = new LoginPage();
		login.Login(prop.getProperty("user_email_for_noodle"), prop.getProperty("user_password_for_noodle"));
		Thread.sleep(3000);
		

	}


	@Test(priority = 1)
	public void goto_Noodle() throws Exception {
		test = extent.createTest("Participant Navigate to Noodle", "Participant views noodle page");
		na = new NoodleActivity();
		test.log(Status.INFO, "Login as User");
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));
		test.log(Status.INFO, "Navigate to decision space page");
		Assert.assertTrue(na.clickNoodleBasedOnTopicInUserAccount(prop.getProperty("topic_to_check_instructionPanel")));
		test.log(Status.INFO, "Navigate to Noodle page");
		Thread.sleep(1000);
		
	}
	
	@Test(priority = 2)
	public void checkInstructionIcon() throws Exception {
		test = extent.createTest("Participant Checking instruction menu's functionality", "Participant Checking Instruction menu's functionality");
		na = new NoodleActivity();
		Assert.assertTrue(na.checkInsIcon());
		test.log(Status.INFO, "Checking the instruction icon");
	}
	
	@Test(priority = 3)
	public void checkInstruction() throws Exception {
		test = extent.createTest("Participant Checking the instructions", "Participant Checking the instructions");
		na = new NoodleActivity();
		Assert.assertTrue(na.checkInstructions());
		test.log(Status.INFO, "Checking the instructions content");
	}
	
	@Test(priority = 4)
	public void checkInstructionLink() throws Exception {
		test = extent.createTest("Participant Checking hyperlinks on the instructions", "Participant Checking hyperlinks on the instructions");
		na = new NoodleActivity();
		Assert.assertTrue(na.checkHyperLink());
		test.log(Status.INFO, "Checking the hyperlinks of instructions");
	}
	


	@AfterTest

	public void teardown() {
		driver.quit();
	}
}





