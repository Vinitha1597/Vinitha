package com.Testcases.noodle.settingspanel;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class HideAndCheckNoodleActivity extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		test = extent.createTest("Participant views hidden noodle settings panel", "Participant views hidden noodle settings panel");
		test.log(Status.INFO, "Login with a facilitator account");
		
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		test.log(Status.INFO, "Navigate to Noodle page");
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);
		test.log(Status.INFO, "Enter into noodle settings panel");
		Assert.assertTrue(na.checkViewNoodleSettingsPanel());
		test.log(Status.INFO, "Click on the hide noodle activity button to hide the noodle activity from the participant");
		Assert.assertTrue(na.hideNoodleActivity());

	}

		
	@Test(priority = 1)
	public void viewHiddenNoodleSettingsPanel() throws Exception {
		
		test.log(Status.INFO, "Login with a participant account");
		login.Login(prop.getProperty("user_email_for_noodle"), prop.getProperty("user_password_for_noodle"));
		test.log(Status.INFO, "Enter into the particular decision space and check the noodle icon of the topic");
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));
		test.log(Status.INFO, "Check Noodle activity icon under particular topic");
		Assert.assertFalse(na.checkNoodleIconUnderTopic(prop.getProperty("topic_name_to_check_after_hideorShowNoodle")));
		test.log(Status.INFO, "Noodle activity icon is not there under particular topic");
	}
	@AfterTest
	public void teardown() {
		driver.quit();
	}
}
