package com.Testcases.noodle.textformatting;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class CheckingOfItalicText extends Testbase{
	
	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);

	}

	
	@Test(priority = 1)
	public void verifyItalictextForDesc() throws Exception {
		test = extent.createTest("checking italic style of description", "checking italic style of description");
		na.enterIntoSpecificTile(prop.getProperty("tileno_to_check_italiced_for_descriptiontext"),prop.getProperty("tilename_to_check_italiced_for_descriptiontext"));
		test.log(Status.INFO, "Enter into a tile and select a description");
		test.log(Status.INFO, "Click on Italic icon and check it");		
		Assert.assertTrue(na.italicDescription(prop.getProperty("description_to_check_italiced_for_descriptionText")));
		test.log(Status.INFO, "User is able to make a description style as italic");
		
	}
	
	@Test(priority = 2)
	public void verifyItalictextForComments() throws Exception {
		test = extent.createTest("checking italic text of comment", "checking italic text of comment");
		na.enterIntoSpecificTile(prop.getProperty("tileno_to_check_italiced_for_commenttext"),prop.getProperty("tilename_to_check_italiced_for_commenttext"));
		test.log(Status.INFO, "Enter into a tile and select a comment");
		test.log(Status.INFO, "Click on Italic icon and check it");		
		Assert.assertTrue(na.italicComment(prop.getProperty("comment_to_check_italiced_for_commentText")));
		test.log(Status.INFO, "User is able to make a comment style as italic");
		
	}
	
	@Test(priority = 3)
		public void verifyItalictextForReply() throws Exception {
			test = extent.createTest("checking italic text of reply", "checking italic text of reply");
			na.enterIntoSpecificTile(prop.getProperty("tileno_to_check_italicstyle_for_replytext"),prop.getProperty("tilename_to_check_italicstyle_for_replytext"));
			test.log(Status.INFO, "Enter into a tile and select the reply");
			test.log(Status.INFO, "Click on Italic icon and check it");		
			Assert.assertTrue(na.italicReply(prop.getProperty("tileno_to_check_italicstyle_for_replytext"),prop.getProperty("tilename_to_check_italicstyle_for_replytext"),prop.getProperty("comment_to_add_italicstylereply_under_this"),prop.getProperty("reply_to_check_italicstyle_of_replytext")));
			test.log(Status.INFO, "User is able to make a reply style as italic");
			
		}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
