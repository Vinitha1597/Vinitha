package com.Testcases.noodle.viewpanel;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class ShuffledFilter extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);
		

	}

		
	@Test(priority = 1)
			public void viewTilesInShuffledOrder() throws Exception {
				test = extent.createTest("View idea in shuffled order", "View idea in shuffled order");
				test.log(Status.INFO, "Login with a valid account");
				test.log(Status.INFO, "Navigate to Noodle page");
				test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
				na.clickOnviewPanelToggle();
				test.log(Status.INFO, "click on the list view icon and check the tile's description");
				 
				Assert.assertTrue(na.tileshuffledOrder());
				test.log(Status.INFO, "User is able to see the tiles in a shuffled order");
			}
		
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
}
