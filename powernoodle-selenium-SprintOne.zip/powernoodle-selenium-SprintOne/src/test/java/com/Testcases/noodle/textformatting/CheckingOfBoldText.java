package com.Testcases.noodle.textformatting;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class CheckingOfBoldText extends Testbase{
	
	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);

	}

	
	@Test(priority = 1)
	public void verifyBoldtextForDesc() throws Exception {
		test = extent.createTest("checking bold text of description", "checking bold text of description");
		na.enterIntoSpecificTile(prop.getProperty("tileno_to_check_bold_for_descriptiontext"),prop.getProperty("tilename_to_check_bold_for_descriptiontext"));
		test.log(Status.INFO, "Enter into a tile");
		test.log(Status.INFO, "Click on Bold icon and check it");		
		Assert.assertTrue(na.boldsDescription(prop.getProperty("description_to_check_bold_for_descriptionText")));
		test.log(Status.INFO, "User is able to make a description style as bold");
		
	}
	
	@Test(priority = 2)
	public void verifyBoldtextForComments() throws Exception {
		test = extent.createTest("checking bold text of comment", "checking bold text of comment");
		na.enterIntoSpecificTile(prop.getProperty("tileno_to_check_bold_for_descriptiontext"),prop.getProperty("tilename_to_check_bold_for_descriptiontext"));
		test.log(Status.INFO, "Enter into a tile");
		test.log(Status.INFO, "Click on Bold icon and check it");		
		Assert.assertTrue(na.boldsComment(prop.getProperty("comment_to_check_bold_of_commentText")));
		test.log(Status.INFO, "User is able to make a comment style as bold");
		
	}
	
	@Test(priority = 3)
		public void verifyBoldtextForReply() throws Exception {
			test = extent.createTest("checking bold text of reply", "checking bold text of reply");
			na.enterIntoSpecificTile(prop.getProperty("tileno_to_check_bold_for_descriptiontext"),prop.getProperty("tilename_to_check_bold_for_descriptiontext"));
			test.log(Status.INFO, "Enter into a tile");
			test.log(Status.INFO, "Click on Bold icon and check it");		
			Assert.assertTrue(na.boldsReply(prop.getProperty("tileno_to_check_bold_for_replytext"),prop.getProperty("tilename_to_check_bold_for_replytext"),prop.getProperty("comment_to_add_boldreply_under_this"),prop.getProperty("reply_to_check_bold_of_replytext")));
			test.log(Status.INFO, "User is able to make a reply style as bold");
			
		}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}

