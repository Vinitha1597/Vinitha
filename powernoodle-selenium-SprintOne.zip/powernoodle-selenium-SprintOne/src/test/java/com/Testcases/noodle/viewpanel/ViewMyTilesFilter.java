package com.Testcases.noodle.viewpanel;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class ViewMyTilesFilter extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);
		

	}

		
	@Test(priority = 1)		
		public void viewMyTilesListAlone() throws Exception {
			test = extent.createTest("View own tiles alone", "View own tiles alone");
			test.log(Status.INFO, "Login with a valid account");
			test.log(Status.INFO, "Navigate to Noodle page");
			test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
			na.clickOnviewPanelToggle();
			
			test.log(Status.INFO, "Check the total number of tiles displaying at present");
			test.log(Status.INFO, "Click on the mytile icon and check the total number of tiles displaying currently");
			test.log(Status.INFO, "Compare the number of tiles present before and now");
			test.log(Status.INFO, "Search the tile which is created by own and the tile which is created by others ");
			Assert.assertTrue(na.testMyTiles(prop.getProperty("tileno_ofTile_createdby_himself"), prop.getProperty("tileno_ofTile_createdby_others")));
			
			test.log(Status.INFO, "The tile's count after clicking on the my tile icon is lesser than the tile's count before clicking on the my tile icon");
			test.log(Status.INFO, "The tile which was created by himself/herself is there. And the tile which was created by others is not there.");
		}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
}
