package com.Testcases.noodle.frontoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class IAMDoneByUser extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest

	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Participant done with making decisions", "Participant done with making decisions");
		login = new LoginPage();
		login.Login(prop.getProperty("user_email_for_noodle"), prop.getProperty("user_password_for_noodle"));
		Thread.sleep(3000);
		test.log(Status.INFO, "Login as a participant");
		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));
		test.log(Status.INFO, "Navigate to decision space page");
		Assert.assertTrue(na.clickNoodle());
		test.log(Status.INFO, "Navigate to Noodle page");
		Thread.sleep(1000);

	}


	@Test(priority = 1)
	public void clickIamDone() throws Exception {
		test.log(Status.INFO, "Click on I'm done checkbox");
		Assert.assertTrue(na.putIamDone());
		test.log(Status.INFO, "User clicked on i'm done checkbox with a few decisions");
		
	}
	
	
	
	@AfterTest

	public void teardown() {
		driver.quit();
	}

}