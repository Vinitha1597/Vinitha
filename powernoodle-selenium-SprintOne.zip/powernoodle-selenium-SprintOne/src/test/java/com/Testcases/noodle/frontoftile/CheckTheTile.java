package com.Testcases.noodle.frontoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class CheckTheTile extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest

	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		//test = extent.createTest("Tile's front checking", "Checking of tile's front side actions");
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);
		
		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));
		
		Assert.assertTrue(na.clickNoodle());
		
		Thread.sleep(1000);

	}

	@Test(priority = 1)
	public void verifyTileNameAndNumber() throws Exception {
		test = extent.createTest("checking Name and Number of the tiles", "checking Name and Number of the tiles");
		test.log(Status.INFO, "Login as Facilitator");
		test.log(Status.INFO, "Navigate to decision space page");
		test.log(Status.INFO, "Navigate to Noodle page");
		
		test.log(Status.INFO, "Check all the tile's name and number");
		
		Assert.assertTrue(na.checkTileNameAndNumber());
		test.log(Status.INFO, "Name and Number of all the tiles are displaying correctly");
		
	}
	
	@Test(priority = 2)
	public void verifyPlusAndMinusOfDesc() throws Exception {
		test = extent.createTest("checking Plus and minus icon of tile description", "checking Plus and minus icon of tile description");
		test.log(Status.INFO, "Navigate to Noodle page");
		
		test.log(Status.INFO, "Click on the plus icon and check the description");
		test.log(Status.INFO, "Click on the minus icon and check");
		Assert.assertTrue(na.descPlusMinusMenus());
		test.log(Status.INFO, "Plus icon expands the description and Minus icon shrinks the description");
		
	}

	@Test(priority = 3)
	public void navigateToCommentsByClickingAnywhereOnTile() throws Exception {
		
		test = extent.createTest("Enter into comments by clicking on a tile anywhere", "Enter into comments by clicking on a tile anywhere");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Check the tile after clicking on the text area of a tile");
		test.log(Status.INFO, "Check the tile after clicking on the comment area of a tile");
		Assert.assertTrue(na.enterIntoCommentsByClickingTileAnywhere());
		test.log(Status.INFO, "Clicking anywhere on a tile redirects the user into the comments frame");
		
	}
	
	
	
	@AfterTest

	public void teardown() {
		driver.quit();
	}

}
