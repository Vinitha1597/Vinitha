package com.Testcases.noodle.backoftile;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class FacilitatorAddsCommentForTile extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);

	}

		
	@Test(priority = 1)
	public void facilitatorAddCommentForOwntile() throws Exception {
		test = extent.createTest("Facilitator adding comments for his/her own tile", "Facilitator adding comments for his/her own tile");
		test.log(Status.INFO, "Login as a facilitator");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the tile which was created by the particular facilitator");
		na.enterIntoSpecificTile(prop.getProperty("tile_no_to_addComment_ofFacilitatorTile_byFacilitator"),prop.getProperty("tile_name_to_addComment_ofFacilitatorTile_byFacilitator"));
		test.log(Status.INFO, "Add comments and click on the tick mark");
		test.log(Status.INFO, "enter into the same tile and check the comments");
		Assert.assertTrue(na.addCommentForTile(prop.getProperty("tile_no_to_addComment_ofFacilitatorTile_byFacilitator"),prop.getProperty("tile_comment_to_addComment_ofFacilitatorTile_byFacilitator")));
		test.log(Status.INFO, "Comments added successfully for a tile.");
		
	}
	
	@Test(priority = 2)
	public void facilitatorAddCommentForOtherstile() throws Exception {
		test = extent.createTest("Facilitator adding comments for other's tile", "Facilitator adding comments for other's tile");
		test.log(Status.INFO, "Login as a facilitator");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the tile which was created by other user");
		na.enterIntoSpecificTile(prop.getProperty("tile_no_to_addComment_ofOthersTile_byFacilitator"),prop.getProperty("tile_name_to_addComment_ofOthersTile_byFacilitator"));
		test.log(Status.INFO, "Add comments and click on the tick mark");
		test.log(Status.INFO, "enter into the same tile and check the comments");
		Assert.assertTrue(na.addCommentForTile(prop.getProperty("tile_no_to_addComment_ofOthersTile_byFacilitator"),prop.getProperty("tile_comment_to_addComment_ofOthersTile_byFacilitator")));
		test.log(Status.INFO, "Comments added successfully for a tile.");
		
		
	}
		
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}

