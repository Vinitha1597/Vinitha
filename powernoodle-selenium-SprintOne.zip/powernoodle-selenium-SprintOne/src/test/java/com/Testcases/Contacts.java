package com.Testcases;

import org.testng.annotations.Test;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.Contactspage;
import com.pageobjects.LoginPage;

public class Contacts extends Testbase {
	LoginPage login;
	Contactspage cn;

	@BeforeTest

	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Add Contacts", "Add Contact");
		Assert.assertTrue(true);

	}

	@Test(priority = 1)
	public void user_login() throws InterruptedException {
		login = new LoginPage();
		login.Login(prop.getProperty("adminusername"), prop.getProperty("adminpassword"));
		Thread.sleep(3000);
		test.log(Status.INFO, "Login as User");
	}

	@Test(priority = 2)
	public void Goto_Settings_contact() throws InterruptedException {
		cn = new Contactspage();
		cn.Menu();
		Thread.sleep(500);
		test.log(Status.INFO, "Navigate to Contacts Page");
	}

	@Test(priority = 3)
	public void add_contact_details() throws InterruptedException {
		cn = new Contactspage();
		test.log(Status.INFO, "Add Details to add the contact");
		Assert.assertTrue(cn.add_details(prop.getProperty("fname"),prop.getProperty("lname"),prop.getProperty("contactemail"),prop.getProperty("contactcompany")));
		Thread.sleep(1000);
		test.log(Status.INFO, "Contact added successfully");
	}

	@AfterTest

	public void teardown() {
		driver.quit();
	}
}
