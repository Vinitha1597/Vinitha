package com.Testcases.tagactivity.instructionpanel;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.NoodleActivity;
import com.pageobjects.TagActivityPage;

public class UserChecksDefaultHyperlinksOfInstructionPanel extends Testbase {
	LoginPage login;
	NoodleActivity noodle;
	NextActionPage nac;
	TagActivityPage tac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("User checks the default hyperlinks of instruction panel", "User checks the default hyperlinks of instruction panel");
		login = new LoginPage();
		nac = new NextActionPage();
		tac = new TagActivityPage();
		noodle = new NoodleActivity();
		test.log(Status.INFO, "Login to the application");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		
	}

	@Test(priority = 1)
	public void userChecksDefaultHyperlinks() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_tagging_instruction_panel")),prop.getProperty("expected_domainspace_to_check_tagging_instruction_panel"));
		test.log(Status.INFO, "Enter into a tag activity");
		Assert.assertTrue(tac.facilitatorClicksTagActivity(prop.getProperty("topic_to_check_tagging_instructionpanel")));
		test.log(Status.INFO, "Click on the instruction panel menu");		
		test.log(Status.INFO, "Click on each and every hyperlinks and check");		
		Assert.assertTrue(tac.checkHyperLinkInInstructions());		
		test.log(Status.PASS, "Hyperlinks navigated the user to the respective links in a new tab");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
