package com.Testcases.tagactivity.opentagging;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.NoodleActivity;
import com.pageobjects.TagActivityPage;

public class ParticipantAddsTiles extends Testbase {
	LoginPage login;
	NoodleActivity noodle;
	NextActionPage nac;
	TagActivityPage tac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Participant adds a few tiles in a topic", "Participant adds a few tiles in a topic");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("participant_email_for_tagaction"), prop.getProperty("participant_password_for_tagaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
		tac = new TagActivityPage();
		noodle = new NoodleActivity();
	}

	@Test(priority = 1)
	public void participantAddsTiles() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_add_tiles_byparticipant_in_tag")),prop.getProperty("expected_domainspace_to_add_tiles_byparticipant_in_tag"));
		test.log(Status.INFO, "Enter into the noodle page of the topic");
		Assert.assertTrue(noodle.clickNoodleBasedOnTopicInUserAccount(prop.getProperty("topicname_to_add_tiles_for_tagging_by_participant")));
		test.log(Status.PASS, "Participant is able to see the noodle activity page");
		test.log(Status.INFO, "Add a few ideas");
		Assert.assertTrue(noodle.addNewTile(prop.getProperty("tilename_for_firstidea_to_add_in_tagmodule_byparticipant")));
		Assert.assertTrue(noodle.addNewTile(prop.getProperty("tilename_for_secondidea_to_add_in_tagmodule_byparticipant")));
		test.log(Status.PASS, "Participant added the ideas for a topic successfully");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
