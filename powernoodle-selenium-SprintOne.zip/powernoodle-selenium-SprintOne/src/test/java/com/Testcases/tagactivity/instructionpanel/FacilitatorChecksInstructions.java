package com.Testcases.tagactivity.instructionpanel;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.NoodleActivity;
import com.pageobjects.TagActivityPage;

public class FacilitatorChecksInstructions extends Testbase {
	LoginPage login;
	NoodleActivity noodle;
	NextActionPage nac;
	TagActivityPage tac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks the instruction panel's instructions", "Facilitator checks the instruction panel's instructions");
		login = new LoginPage();
		nac = new NextActionPage();
		tac = new TagActivityPage();
		noodle = new NoodleActivity();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		
	}

	@Test(priority = 1)
	public void facilitatorChecksInstructions() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_tagging_instruction_panel")),prop.getProperty("expected_domainspace_to_check_tagging_instruction_panel"));
		test.log(Status.INFO, "Enter into a tag activity");
		Assert.assertTrue(tac.facilitatorClicksTagActivity(prop.getProperty("topic_to_check_tagging_instructionpanel")));
		test.log(Status.INFO, "Click on the instruction panel menu and check the instructions");
		Assert.assertTrue(tac.checkInstructionsOfFacilitator());
		test.log(Status.INFO, "Facilitator is able to see the instructions for both participant and facilitator");
		test.log(Status.INFO, "Click on the instruction panel menu again and check the page");
		Assert.assertTrue(tac.closeInstructionPanel());
		test.log(Status.INFO, "Instruction panel disappeared from the page immediately");
		test.log(Status.PASS, "Instruction panel menu shows and hides the instructions to the facilitator correctly");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
