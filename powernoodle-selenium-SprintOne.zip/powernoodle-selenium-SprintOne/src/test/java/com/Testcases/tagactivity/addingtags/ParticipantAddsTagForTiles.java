package com.Testcases.tagactivity.addingtags;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.TagActivityPage;

public class ParticipantAddsTagForTiles extends Testbase {
	LoginPage login;	
	NextActionPage nac;
	TagActivityPage tac;
	DashboardPage dashboard;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Participant adds tags for the tiles", "Participant adds tags for the tiles");
		login = new LoginPage();
		nac = new NextActionPage();
		tac = new TagActivityPage();
		dashboard = new DashboardPage();
		test.log(Status.INFO, "Login with a facilitator account");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		
	}

	@Test(priority = 1)
	public void participantAddsTagForTiles() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_addingtags")),prop.getProperty("expected_domainspace_to_check_addingtags"));
		test.log(Status.INFO, "Enter into a tag activity");
		Assert.assertTrue(tac.facilitatorClicksTagActivity(prop.getProperty("topic_to_check_addingtags_for_tiles")));	
		test.log(Status.INFO, "Make sure that the owner tagging ability is selected by default");
		tac.goToTagSettingsPanel();
		tac.setOwnerTaggingAbilitySettings();
		test.log(Status.INFO, "Logout from this session");
		dashboard.logoutMenu();
		test.log(Status.INFO, "Log in with a participant account");
		login.Login(prop.getProperty("participant_email_for_tagaction"), prop.getProperty("participant_password_for_tagaction"));
		Thread.sleep(3000);
		test.log(Status.INFO, "Go to the same decision space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_addingtags")),prop.getProperty("expected_domainspace_to_check_addingtags"));
		test.log(Status.INFO, "Enter into the tag activity");
		Assert.assertTrue(tac.participantClicksTagActivity(prop.getProperty("topic_to_check_taggingability_tag_settingspanel")));
		test.log(Status.INFO, "Enter into a tile which was created by himself/herself and try to add tags");		
		Assert.assertTrue(tac.AddTagForATile(prop.getProperty("own_tileno_toadd_tags_byparticipant"),prop.getProperty("groupname_toadd_tags_fortiles"),prop.getProperty("tagname_toadd_tags_fortiles")));
		test.log(Status.PASS, "Participant added the tag for his/her own tile");
		test.log(Status.INFO, "Enter into a tile which was created by the facilitator and try to add tags");		
		Assert.assertFalse(tac.AddTagForATile(prop.getProperty("facilitators_tileno_toadd_tags_byparticipant"),prop.getProperty("groupname_toadd_tags_fortiles"),prop.getProperty("tagname_toadd_tags_fortiles")));
		test.log(Status.PASS, "Participant is restricted to add tag for the facilitator's tile");
				
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
