package com.Testcases.tagactivity.instructionpanel;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.NoodleActivity;
import com.pageobjects.TagActivityPage;

public class CheckIAMDoneCount extends Testbase {
	LoginPage login;
	NoodleActivity noodle;
	NextActionPage nac;
	TagActivityPage tac;
	DashboardPage dashboard; 

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks the total participant's done count", "Facilitator checks the total participant's done count");
		login = new LoginPage();
		nac = new NextActionPage();
		tac = new TagActivityPage();
		noodle = new NoodleActivity();
		dashboard = new DashboardPage();
		test.log(Status.INFO, "Login with a facilitator account");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		
	}

	@Test(priority = 1)
	public void facilitatorChecksIamDoneCount() throws Exception {
		
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_tagging_instruction_panel")),prop.getProperty("expected_domainspace_to_check_tagging_instruction_panel"));
		test.log(Status.INFO, "Enter into a tag activity");
		Assert.assertTrue(tac.facilitatorClicksTagActivity(prop.getProperty("topic_to_check_tagging_instructionpanel")));
		test.log(Status.INFO, "Check the value of total participant's done count");	
		int donecountBeforeChanges = tac.takeTotalDoneCount();
		test.log(Status.INFO, "Total participant's done count before change is: "+ donecountBeforeChanges);
		test.log(Status.INFO, "Logout from the facilitator account");
		Assert.assertTrue(dashboard.logoutMenu());
		
		test.log(Status.INFO, "Log in with a participant account to whom the particular topic is enaled");
		login.Login(prop.getProperty("participant_email_for_tagaction"), prop.getProperty("participant_password_for_tagaction"));
		Thread.sleep(3000);
		test.log(Status.INFO, "Enter into the same domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_tagging_instruction_panel")),prop.getProperty("expected_domainspace_to_check_tagging_instruction_panel"));
		test.log(Status.INFO, "Enter into the same tag activity");
		Assert.assertTrue(tac.participantClicksTagActivity(prop.getProperty("topic_to_check_tagging_instructionpanel")));
		test.log(Status.INFO, "Click on the I'm done checkbox");
		tac.clickIamDoneCheckbox();
		test.log(Status.INFO, "Logout from this participant account");
		Assert.assertTrue(dashboard.logoutMenu());
		
		test.log(Status.INFO, "Login again with the same facilitator account and check the total participant's done count and compare it with a previous value");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
			
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_tagging_instruction_panel")),prop.getProperty("expected_domainspace_to_check_tagging_instruction_panel"));
		Assert.assertTrue(tac.facilitatorClicksTagActivity(prop.getProperty("topic_to_check_tagging_instructionpanel")));
		int donecountAfterChanges = tac.takeTotalDoneCount();
		test.log(Status.INFO, "Total participant's done count after change is: "+ donecountAfterChanges);
		if(donecountBeforeChanges==donecountAfterChanges) {
			test.log(Status.FAIL, "Total participant's done count is not getting updated properly");
		}
		else if(donecountBeforeChanges==donecountAfterChanges+1 || donecountBeforeChanges == donecountAfterChanges-1){
			test.log(Status.PASS, "Total participant's done count is getting updated properly");
		}
		
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
