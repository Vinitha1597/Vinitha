package com.Testcases.tagactivity.opentagging;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.NoodleActivity;
import com.pageobjects.TagActivityPage;

public class OpenTaggingForATopic extends Testbase {
	LoginPage login;
	NoodleActivity noodle;
	NextActionPage nac;
	TagActivityPage tac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator opens tagging for a topic", "Facilitator opens tagging for a topic");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
		tac = new TagActivityPage();
		noodle = new NoodleActivity();
	}

	@Test(priority = 1)
	public void facilitatorOpensTaggingForATopic() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_opentagging")),prop.getProperty("expected_domainspace_to_opentagging"));
		test.log(Status.INFO, "Click on the tag settings icon of a topic if the tag button is not clickable");
		test.log(Status.INFO, "Click on the open tagging button");
		test.log(Status.INFO, "Check whether the tag button is now clickable or not");
		test.log(Status.INFO, "Click on the tag button to see the tag activity");
		Assert.assertTrue(tac.openTagActivityForATopic(prop.getProperty("topic_to_open_tagging")));
		test.log(Status.PASS, "Facilitator opened the tag activity for the topic successfully");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
