package com.Testcases.tagactivity.instructionpanel;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.NoodleActivity;
import com.pageobjects.TagActivityPage;

public class FacilitatorAddsItalicTextInTagInstructions extends Testbase {
	LoginPage login;
	NoodleActivity noodle;
	NextActionPage nac;
	TagActivityPage tac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator adding a italic text in the tag instruction panel", "Facilitator adding a italic text in the tag instruction panel");
		login = new LoginPage();
		nac = new NextActionPage();
		tac = new TagActivityPage();
		noodle = new NoodleActivity();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		
	}

	@Test(priority = 1)
	public void facilitatorAddsItalictextInTagInstruction() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_tagging_instruction_panel")),prop.getProperty("expected_domainspace_to_check_tagging_instruction_panel"));
		test.log(Status.INFO, "Enter into a tag activity");
		Assert.assertTrue(tac.facilitatorClicksTagActivity(prop.getProperty("topic_to_check_tagging_instructionpanel")));
		test.log(Status.INFO, "Click on Activity settings menu");
		test.log(Status.INFO, "Click on tag settings menu");
		test.log(Status.INFO, "Click on the Edit activity instructions button");
		tac.goToEditTagInstruction();
		test.log(Status.INFO, "Add a text and make it as italic");
		tac.addItalicTextInTagInstruction(prop.getProperty("text_to_add_italic_in_tag_instruction"));
		test.log(Status.INFO, "Check the instruction panel");
		Assert.assertTrue(tac.checkItalicizedTextInTagInstructions(prop.getProperty("text_to_add_italic_in_tag_instruction")));
		test.log(Status.PASS, "Italicized text is there in the instruction panel");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}