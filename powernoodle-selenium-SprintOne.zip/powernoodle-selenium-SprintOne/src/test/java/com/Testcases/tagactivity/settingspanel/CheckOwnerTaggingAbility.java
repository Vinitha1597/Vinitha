package com.Testcases.tagactivity.settingspanel;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.NoodleActivity;
import com.pageobjects.TagActivityPage;

public class CheckOwnerTaggingAbility extends Testbase {
	LoginPage login;
	NoodleActivity noodle;
	NextActionPage nac;
	TagActivityPage tac;
	DashboardPage dashboard;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks OWNER option of tagging ability label", "Facilitator checks OWNER option of tagging ability label");
		login = new LoginPage();
		nac = new NextActionPage();
		tac = new TagActivityPage();
		noodle = new NoodleActivity();
		dashboard = new DashboardPage();
		test.log(Status.INFO, "Login with a facilitator account");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		
	}

	@Test(priority = 1)
	public void facilitatorChecksOwnerTaggingAbilitySettings() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_tagging_settings_panel")),prop.getProperty("expected_domainspace_to_check_tagging_settings_panel"));
		test.log(Status.INFO, "Enter into a tag activity");
		Assert.assertTrue(tac.facilitatorClicksTagActivity(prop.getProperty("topic_to_check_taggingability_tag_settingspanel")));	
		test.log(Status.INFO, "Go to tag settings panel");
		tac.goToTagSettingsPanel();
		test.log(Status.INFO, "Click on Owner option of the tagging ability label");
		tac.setOwnerTaggingAbilitySettings();
		test.log(Status.INFO, "Logout from this session");
		dashboard.logoutMenu();
		test.log(Status.INFO, "Log in with a participant account");
		login.Login(prop.getProperty("participant_email_for_tagaction"), prop.getProperty("participant_password_for_tagaction"));
		Thread.sleep(3000);
		test.log(Status.INFO, "Go to the same decision space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_tagging_settings_panel")),prop.getProperty("expected_domainspace_to_check_tagging_settings_panel"));
		test.log(Status.INFO, "Enter into the tag activity");
		Assert.assertTrue(tac.participantClicksTagActivity(prop.getProperty("topic_to_check_taggingability_tag_settingspanel")));
		test.log(Status.INFO, "Enter into a tile which was created by himself/herself and check the tagging ability");
		Assert.assertTrue(tac.checkTaggingAbilityOfATile(prop.getProperty("own_tileno_to_check_taggingability_tag_settingspanel")));
		test.log(Status.INFO, "Participant is able to add tags for his/her own tile");
		test.log(Status.INFO, "Enter into a tile which was created by the facilitator or by an another participant and check the tagging ability");
		Assert.assertFalse(tac.checkTaggingAbilityOfATile(prop.getProperty("others_tileno_to_check_taggingability_tag_settingspanel")));
		test.log(Status.INFO, "Participant is restricted to add tags for the tiles which was created by others");
		test.log(Status.PASS, "Participant is able to manage tags only for his/her own tiles successfully");		
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
