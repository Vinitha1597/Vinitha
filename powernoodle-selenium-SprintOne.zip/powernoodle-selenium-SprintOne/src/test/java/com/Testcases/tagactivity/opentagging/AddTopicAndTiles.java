package com.Testcases.tagactivity.opentagging;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.NoodleActivity;
import com.pageobjects.TagActivityPage;

public class AddTopicAndTiles extends Testbase {
	LoginPage login;
	NoodleActivity noodle;
	NextActionPage nac;
	TagActivityPage tac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator adds a new topic and a few tiles in it", "Facilitator adds a new topic and a few tiles in it");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
		tac = new TagActivityPage();
		noodle = new NoodleActivity();
	}

	@Test(priority = 1)
	public void facilitatorAddsTopicAndTiles() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_addtopic")),prop.getProperty("expected_domainspace_to_addtopic"));
		test.log(Status.INFO, "Add a new topic and check");
		Assert.assertTrue(tac.addNewTopic(prop.getProperty("topicname_to_add_for_tagging")));
		test.log(Status.PASS, "Facilitator added the topic successfully");
		test.log(Status.INFO, "Enter into the noodle page of the newly added topic");
		Assert.assertTrue(noodle.clickNoodleBasedOnTopic(prop.getProperty("topicname_to_add_for_tagging")));
		test.log(Status.PASS, "Facilitator is able to see the noodle activity page");
		test.log(Status.INFO, "Add a few ideas");
		Assert.assertTrue(noodle.addNewTile(prop.getProperty("tilename_for_firstidea_to_add_in_tagmodule_byfacilitator")));
		Assert.assertTrue(noodle.addNewTile(prop.getProperty("tilename_for_secondidea_to_add_in_tagmodule_byfacilitator")));
		test.log(Status.PASS, "Facilitator added the ideas successfully");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
