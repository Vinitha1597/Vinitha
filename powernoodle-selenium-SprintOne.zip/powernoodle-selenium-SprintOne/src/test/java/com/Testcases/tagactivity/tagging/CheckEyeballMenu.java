package com.Testcases.tagactivity.tagging;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.TagActivityPage;

public class CheckEyeballMenu extends Testbase {
	LoginPage login;
	NextActionPage nac;
	TagActivityPage tac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks eyball toggle of a tag group", "Facilitator checks eyball toggle of a tag group");
		login = new LoginPage();		
		tac = new TagActivityPage();
		nac = new NextActionPage();
		test.log(Status.INFO, "Login with a facilitator account");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		
	}

	@Test(priority = 1)
	public void facilitatorChecksEyeToggleOfTagGroup() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_taggingmenus")),prop.getProperty("expected_domainspace_to_check_taggingmenus"));
		test.log(Status.INFO, "Enter into a tag activity");
		Assert.assertTrue(tac.facilitatorClicksTagActivity(prop.getProperty("topic_to_check_eyeball_toggle_of_taggroup")));	
		test.log(Status.INFO, "Click on an idea and check the tag group is present or not");
		int groupcountBeforeChanges = tac.checkTagGroupInTheTile(prop.getProperty("groupname_to_check_eyeball_toggle_of_taggroup"));
		test.log(Status.INFO, "Number of group with this searched name before changes: "+groupcountBeforeChanges);
		
		test.log(Status.INFO, "Go to tag settings panel and click on the eyeball toggle");		
		tac.goToTagSettingsPanel();
		Assert.assertTrue(tac.clickEyetoggleOfTagGroup(prop.getProperty("groupname_to_check_eyeball_toggle_of_taggroup")));
		
		test.log(Status.INFO, "Click on a tile and check the same tag group");
		int groupcountAfterChanges = tac.checkTagGroupInTheTile(prop.getProperty("groupname_to_check_eyeball_toggle_of_taggroup"));
		test.log(Status.INFO, "Number of group with this searched name after changes: "+groupcountAfterChanges);
		
		if(groupcountBeforeChanges+1==groupcountAfterChanges) {
			test.log(Status.PASS, "Eyeball toggle shows the tag group in the tiles successfully");
		}
		else if(groupcountBeforeChanges-1 == groupcountAfterChanges) {
			test.log(Status.PASS, "Eyeball toggle hides the tag group in the tiles successfully");
		}
		else {
			test.log(Status.FAIL, "Eyeball toggle doesn't work properly");
		}
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}

