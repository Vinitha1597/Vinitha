package com.Testcases.tagactivity.settingspanel;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.NoodleActivity;
import com.pageobjects.TagActivityPage;

public class CheckHideFileVisibility extends Testbase {
	LoginPage login;
	NoodleActivity noodle;
	NextActionPage nac;
	TagActivityPage tac;
	DashboardPage dashboard;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks Hide option of file visibility label", "Facilitator checks Hide option of file visibility label");
		login = new LoginPage();
		nac = new NextActionPage();
		tac = new TagActivityPage();
		noodle = new NoodleActivity();
		dashboard = new DashboardPage();
		test.log(Status.INFO, "Login with a facilitator account");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		
	}

	@Test(priority = 1)
	public void facilitatorChecksHideFileVisibilitySettings() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_tagging_settings_panel")),prop.getProperty("expected_domainspace_to_check_tagging_settings_panel"));
		test.log(Status.INFO, "Enter into a tag activity");
		Assert.assertTrue(tac.facilitatorClicksTagActivity(prop.getProperty("topic_to_check_filevisibility_tag_settingspanel")));	
		test.log(Status.INFO, "Go to tag settings panel");
		tac.goToTagSettingsPanel();
		test.log(Status.INFO, "Click on Hide option of the file visibility label");
		tac.setHideFilesInSettings();
		test.log(Status.INFO, "Enter into an idea");
		tac.clickOnATile();
		test.log(Status.INFO, "Check that the Add file button is there or not");
		Assert.assertFalse(tac.isAddFilePresent());
		test.log(Status.INFO, "Add file button is hidden");
		test.log(Status.INFO, "Logout from this session");
		dashboard.logoutMenu();
		test.log(Status.INFO, "Log in with a participant account");
		login.Login(prop.getProperty("participant_email_for_tagaction"), prop.getProperty("participant_password_for_tagaction"));
		Thread.sleep(3000);
		test.log(Status.INFO, "Go to the same decision space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_tagging_settings_panel")),prop.getProperty("expected_domainspace_to_check_tagging_settings_panel"));
		test.log(Status.INFO, "Enter into the tag activity");
		Assert.assertTrue(tac.participantClicksTagActivity(prop.getProperty("topic_to_check_filevisibility_tag_settingspanel")));
		test.log(Status.INFO, "Enter into an idea");
		tac.clickOnATile();
		test.log(Status.INFO, "Check that the Add file button is there or not");
		Assert.assertFalse(tac.isAddFilePresent());
		test.log(Status.INFO, "Participant is unable to see the Add file button");
		test.log(Status.PASS, "Files are hidden for the particular topic");
		
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}



