package com.Testcases.tagactivity.addingtags;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.TagActivityPage;

public class AddNewTagGroups extends Testbase {
	LoginPage login;
	NextActionPage nac;
	TagActivityPage tac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator adds new tag groups", "Facilitator adds new tag groups");
		login = new LoginPage();		
		tac = new TagActivityPage();
		nac = new NextActionPage();
		test.log(Status.INFO, "Login with a facilitator account");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		
	}

	@Test(priority = 1)
	public void facilitatorAddsNewTagGroups() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_addingtags")),prop.getProperty("expected_domainspace_to_check_addingtags"));
		test.log(Status.INFO, "Enter into a tag activity");
		Assert.assertTrue(tac.facilitatorClicksTagActivity(prop.getProperty("topic_to_add_taggroup")));	
		test.log(Status.INFO, "Go to tag settings panel");
		tac.goToTagSettingsPanel();
		test.log(Status.INFO, "Click on Add tag group button and fill the group name field with a group name as you want");
		test.log(Status.INFO, "Check that the newly added group is there or not");
		Assert.assertTrue(tac.createNewTagGroup(prop.getProperty("groupname_to_add_taggroup")));
		test.log(Status.PASS, "Facilitator added the tag group successfully");
		test.log(Status.INFO, "Add one more group and check");
		Assert.assertTrue(tac.createNewTagGroup(prop.getProperty("onemore_groupname_to_add_taggroup")));
		test.log(Status.PASS, "Facilitator added one more tag group successfully");
		tac.saveSettingsChanges();
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
