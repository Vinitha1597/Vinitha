package com.Testcases.tagactivity.addingtags;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.TagActivityPage;

public class CheckPickManyTagSettings extends Testbase {
	LoginPage login;	
	NextActionPage nac;
	TagActivityPage tac;
	DashboardPage dashboard;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Checking of Pick many tag label", "Checking of Pick many tag label");
		login = new LoginPage();
		nac = new NextActionPage();
		tac = new TagActivityPage();
		dashboard = new DashboardPage();
		test.log(Status.INFO, "Login with a facilitator account");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		
	}

	@Test(priority = 1)
	public void CheckPickManyTagLabel() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_addingtags")),prop.getProperty("expected_domainspace_to_check_addingtags"));
		test.log(Status.INFO, "Enter into a tag activity");
		Assert.assertTrue(tac.facilitatorClicksTagActivity(prop.getProperty("topic_to_check_pickoneandmany_tags")));	
		test.log(Status.INFO, "Go to tag settings panel");
		tac.goToTagSettingsPanel();
		test.log(Status.INFO, "Set pick many option for a tag group");
		tac.setPickManyTagSettings(prop.getProperty("groupname_to_check_pickoneandmany_tags"));		
		test.log(Status.INFO, "Click on a tile from the facilitator's session");
		tac.clickOnATile();
		test.log(Status.INFO, "Try to select more than one tags from the group and check");
		Assert.assertTrue(tac.checkPickManyType(prop.getProperty("groupname_to_check_pickoneandmany_tags")));	
		test.log(Status.PASS, "Facilitator is able to select more than one tag from this group successfully");
		test.log(Status.INFO, "Logout from this session");
		dashboard.logoutMenu();
		test.log(Status.INFO, "Log in with a participant account");
		login.Login(prop.getProperty("participant_email_for_tagaction"), prop.getProperty("participant_password_for_tagaction"));
		Thread.sleep(3000);
		test.log(Status.INFO, "Go to the same decision space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_addingtags")),prop.getProperty("expected_domainspace_to_check_addingtags"));
		test.log(Status.INFO, "Enter into the tag activity");
		Assert.assertTrue(tac.participantClicksTagActivity(prop.getProperty("topic_to_check_pickoneandmany_tags")));
		test.log(Status.INFO, "Click on a tile from the participant's session");
		tac.clickOnATile();
		test.log(Status.INFO, "Try to select more than one tags from the group and check");
		Assert.assertTrue(tac.checkPickManyType(prop.getProperty("groupname_to_check_pickoneandmany_tags")));	
		test.log(Status.PASS, "Participant is able to select more than one tag from this group successfully");
				
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}

