package com.Testcases.tagactivity.opentagging;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.NoodleActivity;
import com.pageobjects.TagActivityPage;

public class ParticipantViewsTagActivity extends Testbase {
	LoginPage login;
	NoodleActivity noodle;
	NextActionPage nac;
	TagActivityPage tac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Participant views tag activity", "Participant views tag activity");
		login = new LoginPage();
		test.log(Status.INFO, "Login as Participant");
		login.Login(prop.getProperty("participant_email_for_tagaction"), prop.getProperty("participant_password_for_tagaction"));
		Thread.sleep(3000);
		nac = new NextActionPage();
		tac = new TagActivityPage();
		noodle = new NoodleActivity();
	}

	@Test(priority = 1)
	public void participantViewTagActivity() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_viewtagging")),prop.getProperty("expected_domainspace_to_viewtagging"));
		test.log(Status.INFO, "Click on the tag button and check the page");		
		Assert.assertTrue(tac.participantClicksTagActivity(prop.getProperty("topic_to_view_tag_by_participant")));
		test.log(Status.PASS, "Participant is able to click the Tag button and enter into the Tag actiity");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
