package com.Testcases.tagactivity.instructionpanel;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.NoodleActivity;
import com.pageobjects.TagActivityPage;

public class FacilitatorVerifiesDoneCountBygoingForthandback extends Testbase {
	LoginPage login;
	NoodleActivity noodle;
	NextActionPage nac;
	TagActivityPage tac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks the total participant's done count by going forth and back", "Facilitator checks the total participant's done count by going forth and back");
		login = new LoginPage();
		nac = new NextActionPage();
		tac = new TagActivityPage();
		noodle = new NoodleActivity();
		test.log(Status.INFO, "Login as Facilitator");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		
	}

	@Test(priority = 1)
	public void facilitatorChecksParticipantDoneCountByGoingForthAndBack() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_tagging_instruction_panel")),prop.getProperty("expected_domainspace_to_check_tagging_instruction_panel"));
		test.log(Status.INFO, "Enter into a tag activity");
		Assert.assertTrue(tac.facilitatorClicksTagActivity(prop.getProperty("topic_to_check_tagging_instructionpanel")));
		test.log(Status.INFO, "Check the total participant's done count");
		int beforeSwitching = tac.takeTotalDoneCount();
		test.log(Status.INFO, "Total participant's done count before switching to someother topic is: "+beforeSwitching);
		test.log(Status.INFO, "Switch to some other topic");
		test.log(Status.INFO, "Switch back to the same topic");
		tac.switchForthAndBack(prop.getProperty("topic_to_check_tagging_instructionpanel"));
		test.log(Status.INFO, "Check the done count");
		int afterSwitching = tac.takeTotalDoneCount();
		test.log(Status.INFO, "Total done count after swiching forth and back is: "+ afterSwitching);
		test.log(Status.INFO, "Compare the current value with the previous value");
		
		if(beforeSwitching==afterSwitching) {
			test.log(Status.PASS, "The total participant's done count of a topic persisted after switching forth to another topic and back to the same");
		}
		else {
			test.log(Status.FAIL, "The total participant's done count of a topic doesn't persist after switching forth to another topic and back to the same");
		}
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}