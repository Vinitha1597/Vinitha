package com.Testcases.tagactivity.settingspanel;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.NoodleActivity;
import com.pageobjects.TagActivityPage;

public class CheckHideTagSettings extends Testbase {
	LoginPage login;
	NoodleActivity noodle;
	NextActionPage nac;
	TagActivityPage tac;
	DashboardPage dashboard;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks the hide tag settings option", "Facilitator checks the hide tag settings option");
		login = new LoginPage();
		nac = new NextActionPage();
		tac = new TagActivityPage();
		noodle = new NoodleActivity();
		dashboard = new DashboardPage();
		test.log(Status.INFO, "Login with a facilitator account");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		
	}

	@Test(priority = 1)
	public void facilitatorChecksHideTagSettings() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_tagging_settings_panel")),prop.getProperty("expected_domainspace_to_check_tagging_settings_panel"));
		test.log(Status.INFO, "Enter into a tag activity");
		Assert.assertTrue(tac.facilitatorClicksTagActivity(prop.getProperty("topic_to_check_showorhide_tag_settingspanel")));
		test.log(Status.INFO, "Go to tag settings panel");
		tac.goToTagSettingsPanel();
		test.log(Status.INFO, "Click on Hide tag settings button");
		tac.enableHideTagButton();
		test.log(Status.INFO, "Logout from this session");
		dashboard.logoutMenu();
		test.log(Status.INFO, "Log in with a participant account");
		login.Login(prop.getProperty("participant_email_for_tagaction"), prop.getProperty("participant_password_for_tagaction"));
		Thread.sleep(3000);
		test.log(Status.INFO, "Go to the same decision space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_tagging_settings_panel")),prop.getProperty("expected_domainspace_to_check_tagging_settings_panel"));
		test.log(Status.INFO, "Check that the Tag activity is there under the particular topic or not");
		Assert.assertFalse(tac.isTagThere(prop.getProperty("topic_to_check_showorhide_tag_settingspanel")));
		test.log(Status.PASS, "Tag activity is not there under the topic. Facilitator set hide tag settings successfully.");
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
