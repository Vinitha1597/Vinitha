package com.Testcases.tagactivity.tagging;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.TagActivityPage;

public class CheckTagGroupOrder extends Testbase {
	LoginPage login;
	NextActionPage nac;
	TagActivityPage tac;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks order of tag group", "Facilitator checks order of tag group");
		login = new LoginPage();		
		tac = new TagActivityPage();
		nac = new NextActionPage();
		test.log(Status.INFO, "Login with a facilitator account");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		
	}

	@Test(priority = 1)
	public void facilitatorChecksTagGroupOrder() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_taggingmenus")),prop.getProperty("expected_domainspace_to_check_taggingmenus"));
		test.log(Status.INFO, "Enter into a tag activity");
		Assert.assertTrue(tac.facilitatorClicksTagActivity(prop.getProperty("topic_to_check_orderof_taggroup")));			
		test.log(Status.INFO, "Go to tag settings panel");		
		tac.goToTagSettingsPanel();		
		test.log(Status.INFO, "Check the group name's order");
		test.log(Status.INFO, "Click on a tile and compare the group names with the order which was there in the settings panel");
		Assert.assertTrue(tac.checkTagGroupOrder());
		test.log(Status.PASS, "Order of the tag groups is same as the settings panel's group order");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}


