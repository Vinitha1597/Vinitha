package com.Testcases.tagactivity.settingspanel;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.DashboardPage;
import com.pageobjects.LoginPage;
import com.pageobjects.NextActionPage;
import com.pageobjects.NoodleActivity;
import com.pageobjects.TagActivityPage;

public class CheckOwnerCommentVisibility extends Testbase {
	LoginPage login;
	NoodleActivity noodle;
	NextActionPage nac;
	TagActivityPage tac;
	DashboardPage dashboard;

	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Facilitator checks Owner option of comment visibility label", "Facilitator checks Owner option of comment visibility label");
		login = new LoginPage();
		nac = new NextActionPage();
		tac = new TagActivityPage();
		noodle = new NoodleActivity();
		dashboard = new DashboardPage();
		test.log(Status.INFO, "Login with a facilitator account");
		login.Login(prop.getProperty("facilitator_email_for_tagaction"), prop.getProperty("facilitator_password_for_tagaction"));
		Thread.sleep(3000);
		
	}

	@Test(priority = 1)
	public void facilitatorChecksOwnerCommentVisibilitySettings() throws Exception {
		test.log(Status.INFO, "Enter into a domain space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_tagging_settings_panel")),prop.getProperty("expected_domainspace_to_check_tagging_settings_panel"));
		test.log(Status.INFO, "Enter into a tag activity");
		Assert.assertTrue(tac.facilitatorClicksTagActivity(prop.getProperty("topic_to_check_commentvisibility_tag_settingspanel")));
		test.log(Status.INFO, "Add comment for a tile");
		Assert.assertTrue(tac.postAComment(prop.getProperty("tileno_to_check_comment_visibility_tag_settings"),prop.getProperty("comment_to_check_comment_visibility_tag_settings")));		
		test.log(Status.INFO, "Go to tag settings panel");
		tac.goToTagSettingsPanel();
		test.log(Status.INFO, "Click on Owner option of the comment visibility label");
		tac.setOwnerCommentVisibilitySettings();
		test.log(Status.INFO, "Take the comment count of the tile to which you have added a comment now from the facilitator's session");
		int commentcountFromFacilitatorSession = tac.takeCommentCount(prop.getProperty("tileno_to_check_comment_visibility_tag_settings"));
		test.log(Status.INFO, "Comment count of the tile in faciltator's session: "+commentcountFromFacilitatorSession);
		test.log(Status.INFO, "Logout from this session");
		dashboard.logoutMenu();
		test.log(Status.INFO, "Log in with a participant account");
		login.Login(prop.getProperty("participant_email_for_tagaction"), prop.getProperty("participant_password_for_tagaction"));
		Thread.sleep(3000);
		test.log(Status.INFO, "Go to the same decision space");
		Assert.assertEquals(nac.clickSpace(prop.getProperty("domainspace_to_check_tagging_settings_panel")),prop.getProperty("expected_domainspace_to_check_tagging_settings_panel"));
		test.log(Status.INFO, "Enter into the tag activity");
		Assert.assertTrue(tac.participantClicksTagActivity(prop.getProperty("topic_to_check_commentvisibility_tag_settingspanel")));
		test.log(Status.INFO, "Take the comment count of the same tile from the participant's session");
		int commentcountFromParticipantSession = tac.takeCommentCount(prop.getProperty("tileno_to_check_comment_visibility_tag_settings"));
		test.log(Status.INFO, "Comment count of the tile in participant's session: "+commentcountFromParticipantSession);
		test.log(Status.INFO, "Compare these two values");
		
		if(commentcountFromFacilitatorSession-1>=commentcountFromParticipantSession) {
			test.log(Status.PASS, "Participant is able to see only his/her own comments of the tiles");
		}
		
		else {
			test.log(Status.FAIL, "Participant is able to see all comments of the tiles. Other's comment is not hidden correctly");
		}
		
		
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}


