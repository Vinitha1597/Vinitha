package com.Testcases;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.Accountcreation;

public class AccountCreation extends Testbase {

	Accountcreation ac;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		// test = extent.createTest("SignUp", "Account Creation");
		ac = new Accountcreation();
		ac.Sign_up();
	}

	@Test(priority = 1)
	public void add_user_with_empty_fields() throws Exception {

		test = extent.createTest("SignUp with empty fields", "Account Creation with empty fields");
		test.log(Status.INFO, "Left all fields as empty");
		Assert.assertEquals(ac.signupWithEmptyFields(), "Please fill out all fields");
		test.log(Status.INFO, "Error message displayed correctly");
		driver.navigate().refresh();

	}

	@Test(priority = 2)
	public void add_user_with_empty_firstname() throws Exception {
		Thread.sleep(1000);
		test = extent.createTest("SignUp with empty first name", "Creating an account with an empty first name field");
		test.log(Status.INFO, "Add Details of User except first name");
		Assert.assertEquals(ac.signupWithEmptyFirstName(prop.getProperty("lastname"), prop.getProperty("email"),
				prop.getProperty("password")), "Please fill out all fields");
		test.log(Status.INFO, "Error message displayed correctly");
		driver.navigate().refresh();
	}

	@Test(priority = 3)
	public void add_user_with_empty_lasttname() throws Exception {
		Thread.sleep(1000);
		test = extent.createTest("SignUp with empty last name", "Creating an account with an empty last name field");
		test.log(Status.INFO, "Add Details of User except last name");
		Assert.assertEquals(ac.signupWithEmptyLastName(prop.getProperty("firstname"), prop.getProperty("email"),
				prop.getProperty("password")), "Please fill out all fields");
		test.log(Status.INFO, "Error message displayed correctly");
		driver.navigate().refresh();
	}

	@Test(priority = 4)
	public void add_user_with_empty_email() throws Exception {
		Thread.sleep(1000);
		test = extent.createTest("SignUp with empty email field", "Creating an account with an empty email field");
		test.log(Status.INFO, "Add Details of User except email field");
		Assert.assertEquals(ac.signupWithEmptyEmail(prop.getProperty("firstname"), prop.getProperty("lastname"),
				prop.getProperty("password")), "Please fill out all fields Email address is invalid");
		test.log(Status.INFO, "Error message displayed correctly");
		driver.navigate().refresh();
	}
	
	@Test(priority = 5)
	public void add_user_with_invalid_email() throws Exception {
		Thread.sleep(1000);
		test = extent.createTest("SignUp with invalid email field", "Creating an account with an invalid email field");
		test.log(Status.INFO, "Add Details of User with invalid email id");
		Assert.assertEquals(ac.signupWithInvalidEmail(prop.getProperty("firstname"), prop.getProperty("lastname"),prop.getProperty("invalidemail"),
				prop.getProperty("password")), "Email address is invalid");
		test.log(Status.INFO, "Error message displayed correctly");
		driver.navigate().refresh();
	}

	@Test(priority = 6)
	public void add_user_with_empty_pswd() throws Exception {
		Thread.sleep(1000);
		test = extent.createTest("SignUp with empty password field", "Creating an account with an empty password field");
		test.log(Status.INFO, "Add Details of User except password field");
		Assert.assertEquals(ac.signupWithEmptyPswd(prop.getProperty("firstname"), prop.getProperty("lastname"),prop.getProperty("email")), " Please enter a password Your password must be at least 8 characters long, and include uppercase letters, lowercase letters, and numbers.");
		test.log(Status.INFO, "Error message displayed correctly");
		driver.navigate().refresh();
	}
	
	@Test(priority = 7)
	public void add_user_with_invalid_pswd() throws Exception {
		Thread.sleep(1000);
		test = extent.createTest("SignUp with invalid password field", "Creating an account with an invalid password field");
		test.log(Status.INFO, "Add Details of User with invalid password field");
		Assert.assertTrue(ac.signupWithInvalidPswd(prop.getProperty("firstname"), prop.getProperty("lastname"),prop.getProperty("email"),"xas"));
		test.log(Status.INFO, "Error message displayed correctly");
		driver.navigate().refresh();
	}
	
	@Test(priority = 8)
		public void add_user_with_unchecked_conditions() throws Exception {
			Thread.sleep(1000);
			test = extent.createTest("SignUp with unaccepted checkboxes", "Creating an account with unaccepted checkboxes");
			test.log(Status.INFO, "Add Details of User except checking the check boxes");
			Assert.assertEquals(ac.signupWithUnClickedCheckBox(prop.getProperty("firstname"), prop.getProperty("lastname"),prop.getProperty("email"),prop.getProperty("password")), "Please read and accept the Terms and Conditions");
			test.log(Status.INFO, "Error message displayed correctly");
			driver.navigate().refresh();
		}

	@Test(priority = 9)
	public void add_user_details() throws Exception {
		Thread.sleep(1000);
		test = extent.createTest("SignUp", "Account Creation");
		test.log(Status.INFO, "Add Details of User to create an account");
		ac.add_details(prop.getProperty("firstname"), prop.getProperty("lastname"), prop.getProperty("email"),
				prop.getProperty("password"));
		// Assert.assertEquals(ac.checkSignUpCompleteMsg(), "Complete Signup");
		test.log(Status.INFO, "User account created successfully");

	}
	

	@AfterTest
	public void teardown() {
		driver.quit();
	}
}
