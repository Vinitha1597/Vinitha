package com.Testcases.noodle;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.LoginPage;
import com.pageobjects.NoodleActivity;

public class CheckingOfViewPanelFilters extends Testbase {

	LoginPage login;
	NoodleActivity na;

	@BeforeTest
	public void setup() throws Exception{
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		login = new LoginPage();
		login.Login(prop.getProperty("admin_email_for_noodle"), prop.getProperty("admin_password_for_noodle"));
		Thread.sleep(3000);		
		na = new NoodleActivity();
		Assert.assertEquals(na.clickSpace(prop.getProperty("title_name_to_view_noodle")), prop.getProperty("expected_space_header"));		
		Assert.assertTrue(na.clickNoodle());		
		Thread.sleep(1000);
		

	}

		
	//@Test(priority = 1)
	public void testListView() throws Exception {
		test = extent.createTest("Checking of list view menu", "Checking of list view menu");
		test.log(Status.INFO, "Login with a valid account");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
		na.clickOnviewPanelToggle();
		test.log(Status.INFO, "click on the list view icon and check the tiles");
		Assert.assertTrue(na.testListViewOfTiles());
		test.log(Status.INFO, "Clicking on the list view icon shows the ideas in a list");
	}
	//@Test(priority = 2)
	public void testTileView() throws Exception {
		test = extent.createTest("Checking of tile view menu", "Checking of tile view menu");
		test.log(Status.INFO, "Login with a valid account");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
		na.clickOnviewPanelToggle();
		test.log(Status.INFO, "click on the tile view icon and check the tiles");
		//Assert.assertTrue(na.testListViewOfTiles());
		Assert.assertTrue(na.testTileViewOfTiles());
		test.log(Status.INFO, "Clicking on the tile view icon shows the ideas in a tile");
	}
	
	//@Test(priority = 3)
	public void testShowDescriptionWithCheckedCheckbox() throws Exception {
		test = extent.createTest("View idea description", "View idea description");
		test.log(Status.INFO, "Login with a valid account");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
		na.clickOnviewPanelToggle();
		test.log(Status.INFO, "click on the list view icon and check the tile's description");
		Assert.assertTrue(na.testListViewOfTiles());
		Assert.assertTrue(na.testTiledescriptionWhilehavingCheckedShowdescription());
		test.log(Status.INFO, "User is able to see the description of all ideas in the list view");
	}
	
	@Test(priority = 4)
	public void testShowDescriptionWithUnCheckedCheckbox() throws Exception {
		test = extent.createTest("View idea description", "View idea description");
		test.log(Status.INFO, "Login with a valid account");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
		na.clickOnviewPanelToggle();
		test.log(Status.INFO, "click on the list view icon and check the tile's description");
		Assert.assertTrue(na.testListViewOfTiles());
		test.log(Status.INFO, "Uncheck the show description checkbox and check the ideas");
		Assert.assertTrue(na.testTiledescriptionWhilehavingUnCheckedShowdescription());
		test.log(Status.INFO, "Descriptions are disappearing from the ideas");
	}
	//@Test(priority = 5)		
	public void viewMyTilesListAlone() throws Exception {
		test = extent.createTest("View own tiles alone", "View own tiles alone");
		test.log(Status.INFO, "Login with a valid account");
		test.log(Status.INFO, "Navigate to Noodle page");
		test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
		na.clickOnviewPanelToggle();
		
		test.log(Status.INFO, "Check the total number of tiles displaying at present");
		test.log(Status.INFO, "Click on the mytile icon and check the total number of tiles displaying currently");
		test.log(Status.INFO, "Compare the number of tiles present before and now");
		test.log(Status.INFO, "Search the tile which is created by own and the tile which is created by others ");
		Assert.assertTrue(na.testMyTiles(prop.getProperty("tileno_ofTile_createdby_himself"), prop.getProperty("tileno_ofTile_createdby_others")));
		
		test.log(Status.INFO, "The tile's count after clicking on the my tile icon is lesser than the tile's count before clicking on the my tile icon");
		test.log(Status.INFO, "The tile which was created by himself/herself is there. And the tile which was created by others is not there.");
	}
	
	//@Test(priority = 6)		
		public void viewAllTilesList() throws Exception {
			test = extent.createTest("View all tiles alone", "View all tiles");
			test.log(Status.INFO, "Login with a valid account");
			test.log(Status.INFO, "Navigate to Noodle page");
			test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
			na.clickOnviewPanelToggle();
			
			test.log(Status.INFO, "Check the total number of tiles displaying at present");
			test.log(Status.INFO, "Click on the mytile icon and check the total number of tiles displaying currently");
			
			
			test.log(Status.INFO, "Click on the alltile icon and check the total number of tiles displaying currently");
			test.log(Status.INFO, "Compare the number of tiles present before and now");
			test.log(Status.INFO, "The tile's count after clicking on the my tile icon is lesser than the tile's count before clicking on the my tile icon");
			test.log(Status.INFO, "Search the tile which is created by own and the tile which is created by others ");
			Assert.assertTrue(na.testAllTiles(prop.getProperty("tileno_ofTile_createdby_himself"), prop.getProperty("tileno_ofTile_createdby_others")));
			test.log(Status.INFO, "The tile's count after clicking on the all tile icon is equal to the tile's count before clicking on the my tile icon");
			test.log(Status.INFO, "The tile which was created by himself/herself is there. And the tile which was created by others is also there.");
		}
		
		//@Test(priority = 7)
		public void sortByAlphaAscending() throws Exception {
			test = extent.createTest("sort by alpha ascending", "sort by alpha ascending");
			test.log(Status.INFO, "Login with a valid account");
			test.log(Status.INFO, "Navigate to Noodle page");
			test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
			na.clickOnviewPanelToggle();
			test.log(Status.INFO, "click on the list view icon and check the tile's description");
			 
			Assert.assertTrue(na.alphabeticalAscendingTiles());
			test.log(Status.INFO, "User is able to see the description of all ideas in the list view");
		}
		
		//@Test(priority = 8)
		public void sortByAlphaDescending() throws Exception {
			test = extent.createTest("sort by alpha descending", "sort by alpha descending");
			test.log(Status.INFO, "Login with a valid account");
			test.log(Status.INFO, "Navigate to Noodle page");
			test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
			na.clickOnviewPanelToggle();
			test.log(Status.INFO, "click on the list view icon and check the tile's description");
			 
			Assert.assertTrue(na.alphabeticalDescendingTiles());
			test.log(Status.INFO, "User is able to see the description of all ideas in the list view");
		}
		
		//@Test(priority = 9)
		public void sortByNumberAscending() throws Exception {
			test = extent.createTest("sort by numeric ascending", "sort by numeric ascending");
			test.log(Status.INFO, "Login with a valid account");
			test.log(Status.INFO, "Navigate to Noodle page");
			test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
			na.clickOnviewPanelToggle();
			test.log(Status.INFO, "click on the list view icon and check the tile's description");
			 
			Assert.assertTrue(na.tilenoAscendingOrder());
			test.log(Status.INFO, "User is able to see the description of all ideas in the list view");
		}
		
		//@Test(priority = 10)
		public void sortByNumberDescending() throws Exception {
			test = extent.createTest("sort by numeric descending", "sort by numeric descending");
			test.log(Status.INFO, "Login with a valid account");
			test.log(Status.INFO, "Navigate to Noodle page");
			test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
			na.clickOnviewPanelToggle();
			test.log(Status.INFO, "click on the list view icon and check the tile's description");
			 
			Assert.assertTrue(na.tilenoDescendingOrder());
			test.log(Status.INFO, "User is able to see the description of all ideas in the list view");
		}
		
		//@Test(priority = 11)
		public void viewTilesInShuffledOrder() throws Exception {
			test = extent.createTest("View idea in shuffled order", "View idea in shuffled order");
			test.log(Status.INFO, "Login with a valid account");
			test.log(Status.INFO, "Navigate to Noodle page");
			test.log(Status.INFO, "Click on the display view panel menu which is there on top of the page and check");
			na.clickOnviewPanelToggle();
			test.log(Status.INFO, "click on the list view icon and check the tile's description");
			 
			Assert.assertTrue(na.tileshuffledOrder());
			test.log(Status.INFO, "User is able to see the description of all ideas in the list view");
		}
	
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
}