package com.Base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import au.com.bytecode.opencsv.CSVReader;

public class DataReader extends Testbase {
	
	public static XSSFSheet ExceLWSheet;
	private static XSSFWorkbook ExcelWBook;
	private static XSSFCell cell;
	private String FilePath=null;
	private String sheetName=null;
	
	public static CSVReader csvReader;
	
	
	
	public DataReader(String FilePath) {
		this.FilePath=FilePath;
		
	}
	 
	public static Object[][] getTableArray(String FilePath,String sheetName) throws FileNotFoundException{
		String[][] tabArray=null;
		try {
			System.out.println("Coming here");
			System.out.println(FilePath);
			System.out.println(sheetName);
			FileInputStream ExcelFile=new FileInputStream(FilePath);
			ExcelWBook	=new XSSFWorkbook(ExcelFile);
			ExceLWSheet=ExcelWBook.getSheet(sheetName);
			int startRow=1;
			int startCol=1;
			int ci,cj;
			int totalRows=ExceLWSheet.getFirstRowNum();
			System.out.println("totalrows"+totalRows);
			int totalCols=ExceLWSheet.getRow(0).getLastCellNum()-1;
			tabArray=new String[totalRows][totalCols];
			ci=0;
			for(int i=startRow;i<=totalRows;i++,ci++) {
				cj=0;
				for(int j= startCol;j<=totalCols;j++,cj++) {
					tabArray[ci][cj]=getcellData(i,j);
					System.out.println(tabArray[ci][cj]);
					
				}
				
			}
		
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return (tabArray);
			
	}
		
	private static String getcellData(int row,int col) {
		
		String CellData=null;
		try {
			
			cell=ExceLWSheet.getRow(row).getCell(col);
			int dataType=cell.getCellType();
			if(dataType==3)
				return "";
			else if(dataType==0) {
				
				CellData=cell.getRawValue();
				return CellData;
				
			}
			
			else {
				
				CellData=cell.getStringCellValue();
				return CellData;
			}
			
		
		}catch(Exception e) {
			return CellData="";
		}

	}
	


}
