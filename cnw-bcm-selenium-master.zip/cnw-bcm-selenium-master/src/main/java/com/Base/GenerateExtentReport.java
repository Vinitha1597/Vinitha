package com.Base;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class GenerateExtentReport  {

	
	ExtentHtmlReporter htmlReporter;
	protected static ExtentReports extent;
	protected ExtentTest test;
	WebDriver driver;
	public static String currentDate;
	
	
	

	@BeforeSuite
	@Parameters("reportname")

	public void startReport(String reportname) {
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd HH_mm_ss");
		Date date = new Date();
		System.out.println(dateFormat.format(date));
		currentDate = dateFormat.format(date);

		String fileName = reportname+"_"+currentDate+".html";

		String rn = reportname+"_Report_At_"+currentDate;

		htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "/ExtentReport/"+fileName);

		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		htmlReporter.setAppendExisting(true);

		extent.setSystemInfo("OS", "Linux");
		extent.setSystemInfo("Host", "Prema");
		extent.setSystemInfo("Environment", "QA");

		htmlReporter.config().setChartVisibilityOnOpen(true);
		htmlReporter.config().setDocumentTitle("PN Report");
		htmlReporter.config().setReportName(rn);
		htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlReporter.config().setTheme(Theme.DARK);

	}

	@BeforeMethod
	public static ExtentReports getInstance() {
		// TODO Auto-generated method stub
		return extent;
	}

	@AfterMethod
	public void getResult(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			test.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + "Testcase failed due to some issues:",
					ExtentColor.RED));
			test.fail(result.getThrowable());
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			test.log(Status.PASS, MarkupHelper.createLabel(result.getName() + "Testcase Passed", ExtentColor.GREEN));
		} else {
			test.log(Status.SKIP, MarkupHelper.createLabel(result.getName() + "Testcase Skipped", ExtentColor.ORANGE));
			test.skip(result.getThrowable());
		}
	}

	@AfterSuite
	public void endreport() {
		extent.flush();
		driver.quit();
	}
}
