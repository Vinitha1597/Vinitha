package com.pageobjects;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Base.Testbase;

public class loginpage extends Testbase{
	
	@FindBy(xpath = "//input[@id='username']")
	WebElement username;
	
	@FindBy(xpath = "//input[@id='password']")
	WebElement password;

	@FindBy(xpath = "//button[text()='Sign in']")
	WebElement signin;
	
	@FindBy(xpath = "//button[text()='Login']")
	WebElement clicklogin;
	
	@FindBy(xpath = "//button[text()='Forgot Password?']")
	WebElement clkpasswordlink;
	
	@FindBy(xpath = "//input[@id='username']")
	WebElement emailidtextbox;
	
	@FindBy(xpath = "//button[text()='Confirm']")
	WebElement resentlink;
	
	@FindBy(xpath = "//input[@name='newPassword']")
	WebElement setnewpassword;
	
	@FindBy(xpath = "//input[@name='confirmPassword']")
	WebElement setconfirmpassword;
	
	@FindBy(xpath = "//i[@class='password-icon hide']")
	WebElement clkeye;
	
	
	public loginpage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}
	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	
	public void Login(String un,String pswd) {
		username.sendKeys(un);
		password.sendKeys(pswd);
		signin.click();

	}
	
	public boolean securitydashboard() throws Exception{
		 Thread.sleep(3000);
		 if(driver.findElements(By.xpath("//h5[text()='Entry Health Check']")).size()>0){
			 System.out.println("Successfully Security group dashboard page open");
				return true;
			}
			else {
				System.out.println("Not open Security group dashboard");
				return false;
			}
	}
	
	public boolean overalldashboard() throws Exception{
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Hello')]")));
		 if(driver.findElements(By.xpath("//*[@id='root']/div/div/div[2]/div/div[1]/div[1]/i")).size()>0){
			 System.out.println("Successfully employee dashboard page open");
				return true;
			}
			else {
				System.out.println("Not open employee dashboard");
				return false;
			}
	}
	
	public boolean forgotpass() throws Exception{
		 Thread.sleep(3000);
		 clkpasswordlink.click();
		 Thread.sleep(2000);
		 emailidtextbox.sendKeys("prema.d@cloudnowtech.com");
		 Thread.sleep(5000);
		 resentlink.click();
		 if(driver.findElements(By.xpath("//div[@class='check-mail']/h5")).size()>0){
			 System.out.println("Successfully mail send the user");
				return true;
			}
			else {
				System.out.println("Not mail send to the user");
				return false;
			}
	}
	
	 public String accessurl() throws Exception {
			WebElement url = driver.findElement(By.xpath("//span[@id='space-url-value']"));
			System.out.println(url.getText());
			return url.getText();

	}
	 
	 public void openNewTab(String newUrl) throws Exception

		{
			((JavascriptExecutor) driver).executeScript("window.open('" + newUrl + "','_blank');");
			Thread.sleep(3000);

		}
	 
	 public void openNew(String newUrl) throws Exception

		{
			((JavascriptExecutor) driver).executeScript("window.open('" + newUrl + "','_blank');");
			Thread.sleep(3000);

		}
	 
	 public void SwitchToTheSecondTab() throws Exception{
			Thread.sleep(3000);
			ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());			
			Thread.sleep(1000);		
			driver.switchTo().window(tabs.get(1));
		}
	 
	 public void loginWithGmailAccount(String newpassword, String confirmpassword) throws Exception{
			Thread.sleep(1000);
			js.executeScript("arguments[0].click();", setnewpassword);
			Thread.sleep(500);
			setnewpassword.sendKeys(newpassword);
			Thread.sleep(500);
			js.executeScript("arguments[0].click();", setconfirmpassword);
			Thread.sleep(500);
			setconfirmpassword.sendKeys(confirmpassword);
			Thread.sleep(500);
			js.executeScript("arguments[0].click();", resentlink);
			Thread.sleep(500);
			
			
	}
	 
	 public void setpassword() throws Exception{
		 	Thread.sleep(1000);
		 	emailidtextbox.sendKeys("prema.d@cloudnowtech.com");
			Thread.sleep(1000);
			password.sendKeys("Bcm@12349");
			Thread.sleep(500);
			clkeye.click();
			Thread.sleep(500);
			signin.click();
			Thread.sleep(1000);
			
		 
	 }
	 
 
	 
	
	
	
	
}

