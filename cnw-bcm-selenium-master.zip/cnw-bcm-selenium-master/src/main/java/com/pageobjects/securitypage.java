package com.pageobjects;

import java.awt.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Base.Testbase;

public class securitypage extends Testbase {
	
	@FindBy(xpath = "//img[@src='/static/media/guard.c624cb18.svg']")
	WebElement securitypagelink;
	
	@FindBy(xpath = "//*[@id='messageForm']/div[1]/div[1]/div[1]/div/div/input[1]")
	WebElement empid;
	
	@FindBy(xpath = "//*[@id='temp']")
	WebElement tempinput;
	
	@FindBy(xpath = "//input[@name='OximeterReading']")
	WebElement oximetervalueinput;
	
	
	//@FindBy(xpath = "//div[@id='gtest']/label/div/following::div[text()='Fever']")
	//WebElement clkfever;
	
	//@FindBy(xpath = "//div[@id='gtest']/label/div/following::div[text()='Dry Cough']")
	//WebElement clkdry;
	
	//@FindBy(xpath = "//div[@id='gtest']/label/div/following::div[text()='Aches & Pain']")
	//WebElement clkpain;
	
	//@FindBy(xpath = "//div[@id='gtest']/label/div/following::div[text()='Short of Breath']")
	//WebElement clkbreath;
	
	@FindBy(xpath = "//div[@class='check-text'][text()='Fever']")
	WebElement clkfever;
	
	@FindBy(xpath = "//div[@class='check-img']//img")
	WebElement wfeverIcon;
	
	
	@FindBy(xpath = "//img[@src='/static/media/dry-cough.5f7dd7e6.png']")
	WebElement clkdry;
	
	@FindBy(xpath = "//img[@src='/static/media/sneezing.98a8625f.png']")
	WebElement clkpain;
	
	@FindBy(xpath = "//img[@src='/static/media/short-breath.80341a0a.png']")
	WebElement clkbreath;
	
	@FindBy(xpath = "//*[@id='messageForm']/div[4]/div[5]/div[1]/img")
	WebElement clksmell;
	
	@FindBy(xpath = "//label[@id='yesid']")
	WebElement clkyes;
	
	@FindBy(xpath = "//label[@id='noid']")
	WebElement clkno;
	
	@FindBy(xpath = "//label[@id='familytestyesid']")
	WebElement clkcovidyes;
	
	@FindBy(xpath = "//label[@id='familytestnoid']")
	WebElement clkcovidno;
	
	@FindBy(xpath = "//button[text()='Verify']")
	WebElement clkverify;
	
	@FindBy(xpath = "//button[text()='Edit']")
	WebElement clkedit;
	
	@FindBy(xpath = "//button[text()='Submit']")
	WebElement clksubmit;
	
	@FindBy(xpath = "//img[@src='/static/media/logo-white.72ff73f3.svg']")
	WebElement clkicon;
	
	@FindBy(xpath = "//button[@id='user-profile']")
	WebElement logout;
	
	@FindBy(xpath = "//a[text()='Logout']")
	WebElement clklogout;
	
	@FindBy(xpath = "//input[@class='rbt-input-main form-control rbt-input']")
	WebElement empInput;
	
	@FindBy(xpath = "//ul[@id= 'async-example']//li//a")
	List empids;
	
	@FindBy(xpath = "//input[@id='name']")
	WebElement empname;
	
	@FindBy(xpath = "//input[@id='department']")
	WebElement empdesg;
	
	@FindBy(xpath = "//div[@style='']//div//div[contains(text(),'Has PPE')]")
	WebElement ppe;
	
	@FindBy(xpath = "//div[@class='notes error']/p[contains(text(),\"The employee\")]")
	WebElement sympmsg;
	
	@FindBy(xpath = "//button[text()='Edit']")
	WebElement editbtn;
	
	@FindBy(xpath = "//div[@class='entry-health-check card']//span")
	WebElement datemonth;
	
	@FindBy(xpath = "//p[@class='degreeCelsius red']")
	WebElement surveytemp;
	
	
	
	
	public securitypage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}
	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	Actions actions = new Actions(driver);
	
	/*public void surveymenu(String emp, String temp, String oxy,String fever) throws Exception
	{
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		Thread.sleep(2000);		
		empInput.sendKeys(emp);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//ul[@id= 'async-example']//li//a//span[text() = '" +emp.trim()+ "']"));
		tempinput.sendKeys(temp);
		Thread.sleep(2000);
		oximetervalueinput.sendKeys(oxy);
		Thread.sleep(2000);
		if(!empname.getAttribute("value").equals("") && !empdesg.getAttribute("value").equals(""))
		{


		if(fever.equalsIgnoreCase("YES") && !wfeverIcon.getAttribute("class").equals("check-img"))
			clkfever.click();
	//	if(clkdry.equalsIgnoreCase("YES"))
		//	clkdry.click();

	}


	} */
	
	/*public void onsitesemps(String EmpId,String Temp,String Oximeter) throws Exception{
		
		Thread.sleep(2000);
		empid.sendKeys(EmpId);
		driver.findElement(By.xpath("//ul[@id= 'async-example']//li//a//span[text() = '" +EmpId.trim()+ "']"));
		tempinput.sendKeys(Temp);
		Thread.sleep(2000);
		oximetervalueinput.sendKeys(Oximeter);
		Thread.sleep(2000);
		clkyes.click();
		Thread.sleep(2000);
		clkcovidno.click();
		Thread.sleep(2000);
		clkverify.click();
		Thread.sleep(2000);
		clksubmit.click();
		Thread.sleep(2000);
	}*/

	public void onsiteemp() throws Exception{
		
		Thread.sleep(2000);
		empid.sendKeys("600");
		driver.findElement(By.xpath("//span[text()='600536']")).click();
		Thread.sleep(6000);
		tempinput.sendKeys("98");
		Thread.sleep(2000);
		oximetervalueinput.sendKeys("110");
		Thread.sleep(2000);
		clkyes.click();
		Thread.sleep(2000);
		clkcovidno.click();
		Thread.sleep(2000);
		clkverify.click();
		Thread.sleep(2000);
		clksubmit.click();
		Thread.sleep(2000);
		
		
	}
	
	public void suspectedemp() throws Exception{
		
		Thread.sleep(2000);
		empid.sendKeys("600");
		driver.findElement(By.xpath("//span[text()='600408']")).click();
		Thread.sleep(6000);
		tempinput.sendKeys("100");
		Thread.sleep(2000);
		oximetervalueinput.sendKeys("118");
		Thread.sleep(2000);
		clkdry.click();
		Thread.sleep(1000);
		clkpain.click();
		Thread.sleep(1000);
		clkbreath.click();
		Thread.sleep(1000);	
		clksmell.click();
		Thread.sleep(1000);
		clkcovidno.click();
		Thread.sleep(2000);
		clkverify.click();
		Thread.sleep(2000);
		clksubmit.click();
		Thread.sleep(2000);
		
		
	}
	
	
	
	public void stayathomeempsymone() throws Exception{
		Thread.sleep(2000);
		empid.sendKeys("603");
		driver.findElement(By.xpath("//span[text()='603991']")).click();
		Thread.sleep(6000);
		tempinput.sendKeys("100");
		Thread.sleep(2000);
		oximetervalueinput.sendKeys("120");
		Thread.sleep(2000);
		clkcovidno.click();
		Thread.sleep(2000);
		clkverify.click();
		Thread.sleep(2000);
		clksubmit.click();
		
		
	}
	
	public void stayathomeempsymtwo() throws Exception{
		Thread.sleep(2000);
		empid.sendKeys("603");
		driver.findElement(By.xpath("//span[text()='603786']")).click();
		Thread.sleep(6000);
		tempinput.sendKeys("100");
		Thread.sleep(2000);
		oximetervalueinput.sendKeys("120");
		Thread.sleep(2000);
		clkdry.click();
		Thread.sleep(1000);
		clkcovidno.click();
		Thread.sleep(2000);
		clkverify.click();
		Thread.sleep(2000);
		clksubmit.click();
		
		
	}
	
	public void stayathomeempsymthree() throws Exception{
		Thread.sleep(2000);
		empid.sendKeys("603");
		driver.findElement(By.xpath("//span[text()='600850']")).click();
		Thread.sleep(6000);
		tempinput.sendKeys("100");
		Thread.sleep(2000);
		oximetervalueinput.sendKeys("120");
		Thread.sleep(2000);
		clkdry.click();
		Thread.sleep(1000);
		clkpain.click();
		Thread.sleep(1000);
		clkcovidno.click();
		Thread.sleep(2000);
		clkverify.click();
		Thread.sleep(2000);
		clksubmit.click();
		
		
	}
	
	
	public void stayathomeempsymfour() throws Exception{
		Thread.sleep(2000);
		empid.sendKeys("602");
		driver.findElement(By.xpath("//span[text()='602982']")).click();
		Thread.sleep(6000);
		tempinput.sendKeys("100");
		Thread.sleep(2000);
		oximetervalueinput.sendKeys("120");
		Thread.sleep(2000);
		clkdry.click();
		Thread.sleep(1000);
		clkpain.click();
		Thread.sleep(1000);
		clkbreath.click();
		Thread.sleep(1000);	
		clkcovidno.click();
		Thread.sleep(2000);
		clkverify.click();
		Thread.sleep(2000);
		clksubmit.click();
		
		
	}
	
	
	public void stayathomeemp() throws Exception{
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		Thread.sleep(2000);
		empid.sendKeys("603");
		driver.findElement(By.xpath("//span[text()='603999']")).click();
		Thread.sleep(6000);
		tempinput.sendKeys("100");
		Thread.sleep(2000);
		oximetervalueinput.sendKeys("120");
		Thread.sleep(2000);
		clkdry.click();
		Thread.sleep(1000);
		clkpain.click();
		Thread.sleep(1000);
		clksmell.click();
		Thread.sleep(1000);
		clkcovidno.click();
		Thread.sleep(2000);
		clkverify.click();
		Thread.sleep(2000);
		clksubmit.click();
		
	}
	
	public void Tempfahrenheittocelsius() throws Exception{
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		Thread.sleep(2000);
		empid.sendKeys("601");
		driver.findElement(By.xpath("//span[text()='601971']")).click();
		Thread.sleep(6000);
		tempinput.sendKeys("98");
		Thread.sleep(2000);
		Select cels=new Select(driver.findElement(By.xpath("//select[@id='temp']")));
		cels.selectByIndex(1);
		Thread.sleep(2000);
		oximetervalueinput.sendKeys("120");
		Thread.sleep(2000);
		clkyes.click();
		Thread.sleep(2000);
		clkcovidno.click();
		Thread.sleep(2000);
		clkverify.click();
		Thread.sleep(2000);
		clksubmit.click();
		
		
	}
	
	public void celsiustotempfahrenheit() throws Exception{
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		Thread.sleep(2000);
		empid.sendKeys("601");
		driver.findElement(By.xpath("//span[text()='601968']")).click();
		Thread.sleep(6000);
		Select cels=new Select(driver.findElement(By.xpath("//select[@id='temp']")));
		cels.selectByIndex(1);
		Thread.sleep(2000);
		tempinput.sendKeys("36.8");
		Thread.sleep(2000);
		oximetervalueinput.sendKeys("110");
		Thread.sleep(2000);
		clkyes.click();
		Thread.sleep(2000);
		clkcovidno.click();
		Thread.sleep(2000);
		clkverify.click();
		Thread.sleep(2000);
		clksubmit.click();
		
		
	}
	
	public void empidnameanddep() throws Exception{
		
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		Thread.sleep(2000);
		empid.sendKeys("600");
		driver.findElement(By.xpath("//span[text()='600820']")).click();
		tempinput.sendKeys("98");
		Thread.sleep(2000);
		oximetervalueinput.sendKeys("110");
		Thread.sleep(2000);
		clkyes.click();
		Thread.sleep(2000);
		clkcovidno.click();
		Thread.sleep(2000);
		if(!empname.getAttribute("value").equals("") && !empdesg.getAttribute("value").equals(""))
		{
  
			boolean verifybtn=clkverify.isEnabled();
			System.out.println(verifybtn);
			System.out.println("Verify button is Enabled");
		}
			
		else {
				System.out.println("Verify button is not enabled");
		
		
		}
	}
	
	public boolean ppeqp() throws Exception{
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		Thread.sleep(2000);
		empid.sendKeys("600");
		driver.findElement(By.xpath("//span[text()='600625']")).click();
		tempinput.sendKeys("99");
		Thread.sleep(2000);
		oximetervalueinput.sendKeys("110");
		Thread.sleep(2000);
		if(ppe.isEnabled()) {
			System.out.println("PPE question is enabled and gives to the employee");
			return true;
			
		}
		else {
			System.out.println("PPE question is not enabled and not given to the employee");
			return false;
		}
		
	}
	
	public boolean sympmessage() throws Exception{
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		Thread.sleep(2000);
		empid.sendKeys("600");
		driver.findElement(By.xpath("//span[text()='600625']")).click();
		tempinput.sendKeys("100");
		Thread.sleep(2000);
		oximetervalueinput.sendKeys("110");
		Thread.sleep(2000);
		if(sympmsg.isDisplayed())
		{
			System.out.println("The employee is symptomatic, Kindly send him or her to home the message is shown");
			return true;
			
		}
		else {
			System.out.println("The employee is symptomatic, Kindly send him or her to home the message is not shown");
			return false;
		}
			
		}
	
	public void editbutton() throws Exception{
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		Thread.sleep(2000);
		empid.sendKeys("601");
		driver.findElement(By.xpath("//span[text()='601878']")).click();
		tempinput.sendKeys("98");
		Thread.sleep(2000);
		oximetervalueinput.sendKeys("110");
		Thread.sleep(2000);
		clkyes.click();
		Thread.sleep(2000);
		clkcovidno.click();
		Thread.sleep(2000);
		clkverify.click();
		Thread.sleep(2000);
		editbtn.click();
		Thread.sleep(2000);
		tempinput.clear();
		Thread.sleep(2000);
		tempinput.sendKeys("99");
		Thread.sleep(2000);
		clkverify.click();
		Thread.sleep(2000);
		clksubmit.click();		
		
	}
		
	public String datemonth() throws Exception{
		Thread.sleep(2000);
		securitypagelink.click();
		System.out.println(datemonth.getText());
		return datemonth.getText();
		
		
	}
	
	public boolean scannedemployee(String aScanEmp) throws Exception{
		
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		Thread.sleep(2000);
		empid.sendKeys(aScanEmp);
		//driver.findElement(By.xpath("//span[text()='600884']")).click();
		if(driver.findElements(By.xpath("//a[text()='User not available']")).size()>0) {
			return true;
		}
		else {
			System.out.println("User in the list.");
			return false;
		}
	}
	
	public void suspectedintemp() throws Exception{
		
		Thread.sleep(2000);
		empid.sendKeys("603");
		driver.findElement(By.xpath("//span[text()='603991']")).click();
		Thread.sleep(6000);
		tempinput.sendKeys("100");
		Thread.sleep(2000);
		oximetervalueinput.sendKeys("118");
		Thread.sleep(2000);
		clkdry.click();
		Thread.sleep(1000);
		clkpain.click();
		Thread.sleep(1000);
		clkbreath.click();
		Thread.sleep(1000);	
		clksmell.click();
		Thread.sleep(1000);
		clkcovidno.click();
		Thread.sleep(2000);
		clkverify.click();
		Thread.sleep(2000);
		clksubmit.click();
		Thread.sleep(2000);
		
		
	}

	public String temp() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='entry-health-check card']")));
		System.out.println(tempinput.getText());
		return tempinput.getText();
	}
	
	public String surveytemp() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Case History']")));
		System.out.println(surveytemp.getText());
		return surveytemp.getText();
	}	
	
	public boolean comparetempera() throws Exception{
		
		
		
		int stemp=driver.findElements(By.xpath("//*[@id='temp']")).size();
		int surveytempera=driver.findElements(By.xpath("//*[@id='15 Thu']/div/div[1]/div/p[2]/text()[1]")).size();
		
		if(stemp == surveytempera) {
			
			return true;
		}
		else {
			
			return false;
			
		}
	}
	
	public boolean Temperaturerange(String tempRange) throws Exception{
		
		
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		empid.sendKeys("60");
		driver.findElement(By.xpath("//span[text()='606060']")).click();
		tempinput.sendKeys(tempRange);
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//small[text()='Normal body temperature lies between 97.7-99.5']")).size()>0) {
            System.out.println("Message shown is Normal body temperature lies between 97.7-99.5");
            return true;
        }
		else {
			System.out.println("Message is not shown");
			return false;
        }

	
	}
	
	
	public boolean washhandsmsg(String tempRange) throws Exception{
		
		
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		empid.sendKeys("60");
		driver.findElement(By.xpath("//span[text()='606060']")).click();
		tempinput.sendKeys(tempRange);
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//p[contains(text(),'Please remind')]")).size()>0) {
            System.out.println("Message shown is Please remind the employee to wash their hands before entering the premises");
            return true;
        }
		else {
			System.out.println("Message is not shown");
			return false;
        }
		
	
	}
	
	public boolean oximeterrange(String tempRange,String oxiRange) throws Exception{
		
		
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		empid.sendKeys("60");
		driver.findElement(By.xpath("//span[text()='606060']")).click();
		tempinput.sendKeys(tempRange);
		Thread.sleep(2000);
		oximetervalueinput.sendKeys(oxiRange);
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//small[contains(text(),'Normal human ')]")).size()>0) {
            System.out.println("Message shown is Normal human body oxygen level lies between 90 mm Hg to 120 mm Hg");
            return true;
        }
		else {
			System.out.println("Message is not shown");
			return false;
        }
		
	
	}
	
	public boolean fevericon(String tempRange) throws Exception{
		
		
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		empid.sendKeys("60");
		driver.findElement(By.xpath("//span[text()='606060']")).click();
		tempinput.sendKeys(tempRange);
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//div[@class='survey-icon-container']//div[@class='survey-icons active']")).size()>0) {
            System.out.println("Fever Icon button is Enabled");
            return true;
        }
		else {
			System.out.println("Fever Icon button not Enabled");
			return false;
        }
		
	
	}
	
	public boolean chksymintemp(String tempRange) throws Exception{
		
		
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		empid.sendKeys("60");
		driver.findElement(By.xpath("//span[text()='606060']")).click();
		tempinput.sendKeys(tempRange);
		Thread.sleep(2000);
		clkfever.click();
		Thread.sleep(1000);
		clkbreath.click();
		Thread.sleep(1000);
		if(driver.findElements(By.xpath("//div[@class='survey-icon-container']//div[@class='survey-icons active']")).size()>0) {
            return true;
        }
		else {
			return false;	        
        }
	
	
	}
	
	
	public boolean msgintemp() throws Exception{
		
		
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		empid.sendKeys("60");
		driver.findElement(By.xpath("//span[text()='606060']")).click();
		clkfever.click();
		Thread.sleep(1000);
		clkbreath.click();
		Thread.sleep(1000);
		if(driver.findElements(By.xpath("//div[@class='survey-icon-container']//div[@class='survey-icons active']")).size()>0) {
            return true;
        }
		else {
			return false;	        
        }
	
	
	}
	
  public boolean chkoximeterrange(String tempRange,String oxiRange) throws Exception{
		
		
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Chennai");
		empid.sendKeys("60");
		driver.findElement(By.xpath("//span[text()='606060']")).click();
		tempinput.sendKeys(tempRange);
		Thread.sleep(2000);
		oximetervalueinput.sendKeys(oxiRange);
		Thread.sleep(2000);
		clkdry.click();
		Thread.sleep(1000);
		clkpain.click();
		Thread.sleep(1000);
		clkbreath.click();
		Thread.sleep(1000);	
		clksmell.click();
		Thread.sleep(1000);
		clkcovidno.click();
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//button[text()='Verify']")).size()>0) {
           return true;
        }
		else {
			return false;
        }
	}
  
  public boolean chkbranch() throws Exception{
		
		
		Thread.sleep(2000);
		securitypagelink.click();
		Thread.sleep(1000);
		Select branch=new Select(driver.findElement(By.xpath("//select[@id='exampleForm.ControlSelect1']")));
		branch.selectByVisibleText("Mumbai");
		empid.sendKeys("606060");
		//driver.findElement(By.xpath("//span[text()='606060']")).click();
		if(driver.findElements(By.xpath("//a[text()='User not available']")).size()>0) {
	           return true;
	        }
			else {
				return false;
	        }
  }
  
  
  
}
	
	
	


	
	
	
	
	

