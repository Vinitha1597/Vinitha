package com.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Base.Testbase;

public class Empsurveystatus extends Testbase{
	
	@FindBy(xpath = "//a[@href='#/home/onsitesurvey']/span/img")
	WebElement clkonsitesurvey;
	
	@FindBy(xpath = "//*[@id='messageForm']/div[1]/div[1]/div[1]/div/div/input[1]")
	WebElement empcode;
	
	@FindBy(xpath = "//*[@id='temp']")
	WebElement emptemp;
	
	@FindBy(xpath = "//*[@id='messageForm']/div[3]/div/label[1]/div[1]/img")
	WebElement empsym;	

	@FindBy(xpath = "//*[@id='messageForm']/div[4]/div/label[1]")
	WebElement empppe;
	
	@FindBy(xpath = "//button[text()='Submit']")
	WebElement empsubmit;
	
	@FindBy(xpath = "//*[@id='messageForm']/div[6]/button[2]")
	WebElement clkverify;
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/div[2]/div[1]/div/div[2]/div/div[2]/span[2]")
	WebElement countofscan;
	
	@FindBy(xpath = "//div[@class='yet-to-scan']//span[@class='count-value']")
	WebElement yettoscan;
	
	@FindBy(xpath = "//div[@class='PieChart']/span/h5")
	WebElement totalcount;
	
	@FindBy(xpath = "//span[text()='WFO']//parent::div//*[local-name()='svg']//*[local-name()='text']")
	WebElement onsitecount;
	
	@FindBy(xpath = "//span[text()='Quarantine']//parent::div//*[local-name()='svg']//*[local-name()='text']")
	WebElement quarantinecount;
	
	@FindBy(xpath = "//span[text()='Suspected']//parent::div//*[local-name()='svg']//*[local-name()='text']")
	WebElement suspectedcount;
	
	
	
		
	public Empsurveystatus() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}
	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	
	public boolean surveystatuslink() throws Exception{
		Thread.sleep(2000);
		clkonsitesurvey.click();
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//div[@class='welcome-text']/div/h2[text()='Survey Status']")).size()>0){
			System.out.println("Successfully open the employee survey status page");	
			return true;
		}
			else {
				System.out.println("Does not open the employee survey status page");	
			return false;
			}
		
		}
	
	
	public boolean surveystatusforemp() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Entry Health Check']")));

		empcode.sendKeys("1018");

		empcode.sendKeys("1133");

		Thread.sleep(3000);
		empcode.sendKeys(Keys.ARROW_DOWN);
		Thread.sleep(3000);
		empcode.sendKeys(Keys.RETURN);		
		Thread.sleep(6000);
		emptemp.sendKeys("140");
		Thread.sleep(4000);
		empsym.click();
		Thread.sleep(4000);
		empppe.click();
		Thread.sleep(2000);
		empsubmit.click();
		Thread.sleep(4000);
		clkverify.click();
		Thread.sleep(7000);
		if(driver.findElements(By.xpath("//button[text()='Submit']")).size()>0){
			return true;
		}
			else {
				
			return false;
			}
	}
		 
	
	
	public String scancount() throws Exception{
	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='yet-to-scan']//span[@class='count-value']")));

		Thread.sleep(3000);


		System.out.println(countofscan.getText());
		return countofscan.getText();
	}
	
	public void clksurvey() throws Exception{
		
		Thread.sleep(2000);
		clkonsitesurvey.click();
		Thread.sleep(2000);
		
	}
	
	
	public String yettoscan() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='yet-to-scan']//span[@class='count-value']")));

		Thread.sleep(3000);


		System.out.println(yettoscan.getText());
		return yettoscan.getText();
	}
	
	
	
	public String totalcountdash() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Employee Health']")));

		Thread.sleep(3000);


		System.out.println(totalcount.getText());
		return totalcount.getText();
	}
	
	public String onsitecountdash() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Employee Health']")));

		Thread.sleep(3000);


		System.out.println(onsitecount.getText());
		return onsitecount.getText();
	}
	
	public String quarantinecountdash() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Employee Health']")));

		Thread.sleep(3000);


		System.out.println(quarantinecount.getText());
		return quarantinecount.getText();
	}
	
	
	public String suspectedcountdash() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Employee Health']")));

		Thread.sleep(3000);


		System.out.println(suspectedcount.getText());
		return suspectedcount.getText();
	}
	
	
	
	
}


