package com.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Base.Testbase;

public class Newsandupdate extends Testbase {
	
	@FindBy(xpath = "//a[@href='#/home/newsandupdates']/span/img")
	WebElement clknewsandupdate;
	
	@FindBy(xpath = "//div[@class='news-option']")
	WebElement clknewoption;
	
	@FindBy(xpath = "//div[@class=' react-multi-email  empty']/input[@type='text']")
	WebElement toaddress;
	
	@FindBy(xpath = "//input[@id='formGridPassword']")
	WebElement addsubject;
	
	@FindBy(xpath = "//input[@name='titleName']")
	WebElement addtitle;
	
	@FindBy(xpath = "//div[@class='ql-editor ql-blank']")
	WebElement editcontent;
	
	@FindBy(xpath = "//*[@id='addNews']/div/div[2]/div/form/div[4]/div[2]/button")
	WebElement clkpublish;
	
	@FindBy(xpath = "//button[@class='close']")
	WebElement clkclose;
	
	@FindBy(xpath = "//form[@class='tab-search']/input")
	WebElement clksearch;
	
	@FindBy(xpath = "//p[text()='test']")
	WebElement clktest;
	
	@FindBy(xpath = "//div[@class='forward-btn']/button")
	WebElement clkforward;
	
	@FindBy(xpath = "//button[text()='Send']")
	WebElement clksend;
	
	@FindBy(xpath = "//div[@class='ql-editor']")
	WebElement editexitcontent;
	
	@FindBy(xpath = "//img[contains(@src,'/static/media/delete')]")
	WebElement deletecontent;
	
	
	public Newsandupdate() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}
	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	
	public boolean newsandupdatelink() throws Exception{
		Thread.sleep(2000);
		clknewsandupdate.click();
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//div[@class='welcome-text']/div/h2[text()='News & Updates']")).size()>0){
			System.out.println("Successfully open the news and update page");	
			return true;
		}
			else {
				System.out.println("Does not open the news and update page");	
			return false;
			}
		
		}
	
	public boolean updatenews() throws Exception{
		Thread.sleep(2000);
		clknewsandupdate.click();
		Thread.sleep(2000);
		clknewoption.click();
		Thread.sleep(2000);
		//toaddress.sendKeys("prema.d@cloudnowtech.com");
		//Thread.sleep(2000);
		//addsubject.click();
		//Thread.sleep(1000);
		//addsubject.sendKeys("hello");
		//Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='bcmUserGroupId_input']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//ul[@class='optionContainer']/li[2]")).click();
		Thread.sleep(4000);
		addtitle.sendKeys("Test");
		Thread.sleep(2000);
		editcontent.click();
		Thread.sleep(1000);
		editcontent.sendKeys("hello");
		Thread.sleep(2000);
		clkpublish.click();
		Thread.sleep(1000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div/h2[text()='News & Updates']")));
		js.executeScript("window.scrollBy(0,1000)");
		if(driver.findElements(By.xpath("//p[text()='hello']")).size()>0){
		 System.out.println("Successfully updated the Company News");	
		 return true;
		}
			else {
		 System.out.println("Does not updated the Company News");	
		 return false;
			}
		
	}
		
		
	public boolean cancelnewsupdates() throws Exception{
		Thread.sleep(2000);
		clknewsandupdate.click();
		Thread.sleep(2000);
		clknewoption.click();
		Thread.sleep(2000);
		clkclose.click();
		if(driver.findElements(By.xpath("//div[@class='welcome-text']/div/h2[text()='News & Updates']")).size()>0){
		 System.out.println("Successfully cancel the Company News");	
		   return true;
			}
				else {
			 System.out.println("Not cancel the Company News");	
			 return false;
				}
		
	}
	
	public void updateexitnews() throws Exception{
		Thread.sleep(2000);
		clknewsandupdate.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div/h2[text()='News & Updates']")));
		clksearch.click();
		Thread.sleep(1000);
		clksearch.sendKeys("test");
		Thread.sleep(1000);
		clktest.click();
		Thread.sleep(1000);
		clkforward.click();
		toaddress.sendKeys("prema.d@cloudnowtech.com");
		Thread.sleep(2000);
		editexitcontent.click();
		Thread.sleep(1000);
		editexitcontent.clear();
		Thread.sleep(1000);
		editexitcontent.sendKeys("hello");
		Thread.sleep(2000);
		clksend.click();
		Thread.sleep(1000);
			
	}
	
	public boolean confirmupdatenews() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div/h2[text()='News & Updates']")));
		clksearch.click();
		Thread.sleep(1000);
		clksearch.clear();
		Thread.sleep(1000);
		clksearch.sendKeys("test");
		Thread.sleep(1000);
		if(driver.findElements(By.xpath("//p[text()='hello ']")).size()>0){
			System.out.println("Successfully Updated the Company News");
		   return true;
			}
		else {
			System.out.println("Not Updated the Company News");
		   return false;
		}
		
		
	}
	
	public boolean deletecontent() throws Exception{
		Thread.sleep(2000);
		clknewsandupdate.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div/h2[text()='News & Updates']")));
		clksearch.click();
		Thread.sleep(1000);
		clksearch.sendKeys("test");
		Thread.sleep(1000);
		clktest.click();
		Thread.sleep(1000);
		deletecontent.click();
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//p[text()='hello']")).size()>0){
		   return true;
			}
		else {
		   return false;
		}
		
		
	}
	

}
