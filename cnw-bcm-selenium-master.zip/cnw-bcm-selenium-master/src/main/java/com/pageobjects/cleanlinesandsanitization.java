package com.pageobjects;

//import java.awt.Desktop.Action;
//import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
//import org.openqa.selenium.Keys;
//import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Base.Testbase;


public class cleanlinesandsanitization extends Testbase {
	
	@FindBy(xpath = "//a[@href='#/home/cleansanitization']/span/img")
	WebElement clkcleanandsanti;
	
	@FindBy(xpath = "//span[@class='addBtn']//i[@class='addIcon']")
	WebElement clkaddplant;
	
	@FindBy(xpath = "//*[@id='addPlant']/div/div[2]/form/div/div[1]/div/div[2]/div/input")
	WebElement plantname;
	
	@FindBy(xpath = "//*[@id='addPlant']/div/div[2]/form/div/div[1]/div/div[4]/div/input")
	WebElement address;
	
	@FindBy(xpath = "//*[@id='addPlant']/div/div[2]/form/div/div[1]/div/div[6]/div/div/div/input[1]")
	WebElement empsearch;
	
	@FindBy(xpath = "//*[@id='addPlant']/div/div[2]/form/div/div[3]/div/div[2]/div[2]/input")
	WebElement areas;
	
	@FindBy(xpath = "//*[@id='addPlant']/div/div[2]/form/div/div[3]/div/div[2]/div[1]/i[1]")
	WebElement addareas;
	
	@FindBy(xpath = "//button[text()='Verify']")
	WebElement clkverify;

	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/div[2]/div[1]/div/ul/li[17]/div/a/div/div[1]/div/h2")
	WebElement clkplantedit;
	
	@FindBy(xpath = "//div[@class='cardItem']/h2[text()='College']")
	WebElement clkcard;
	
	@FindBy(xpath = "//button[text()='Assign Task']")
	WebElement clkassigntask;
	
	@FindBy(xpath = "//*[@id='assignTask']/div/div[2]/div/div[1]/div/div[8]/div/div/div/input[1]")
	WebElement assignee;
	
	@FindBy(xpath = "//a[@class='dropdown-item' and text()='Sridhar Tumma']")
	WebElement sendassignee;
	
	@FindBy(xpath = "//*[@id='assignTask']/div/div[2]/div/div[1]/div/div[10]/div/div[2]/div[2]/div/div/div[2]/div[2]/div[5]/div[6]")
	WebElement datefix;
	
	@FindBy(xpath = "//*[@id='assignTask']/div/div[2]/div/div[1]/div/div[12]/div/div[1]/div/div/div/div/input[2]")
	WebElement dateHH;
	
	@FindBy(xpath = "//*[@id='assignTask']/div/div[2]/div/div[1]/div/div[12]/div/div[1]/div/div/div/div/input[3]")
	WebElement dateMM;
	
	@FindBy(xpath = "//*[@id='assignTask']/div/div[2]/div/div[1]/div/div[12]/div/div[2]/div/div/div/div/input[2]")
	WebElement dateHHH;
	
	@FindBy(xpath = "//*[@id='assignTask']/div/div[2]/div/div[1]/div/div[12]/div/div[2]/div/div/div/div/input[3]")
	WebElement dateMMM;
	
	@FindBy(xpath = "//button[text()='Save']")
	WebElement clksave;
	
	@FindBy(xpath = "//div[text()='Plant Information']/following-sibling::span/i")
	WebElement clkdeleteplant;
	
	@FindBy(xpath = "//label[@class='search-label']/input")
	WebElement searchbtn;
	
	@FindBy(xpath = "//div[@class='statusTableContainer']/div/table/tbody/tr/td[7]/div/i[@class='icon-edit']")
	WebElement editbtn;
	
	@FindBy(xpath = "//div[@class='statusTableContainer']/div/table/tbody/tr[3]/td[7]/div/i[@class='icon-delete']")
	WebElement deleteassignbtn;
	
	@FindBy(xpath = "//button[text()='Confirm']")
	WebElement deleteconfirmassignbtn;
	
	@FindBy(xpath = "//*[@id='assignTask']/div/div[2]/div/div[1]/div/div[12]/div/div[1]/div/input")
	WebElement clkpicker;
	
	@FindBy(xpath = "//*[@id='assignTask']/div/div[2]/div/div[2]/div/div[1]/div[1]/div[1]/span")
	WebElement clkpickerhh;
	
	@FindBy(xpath = "//*[@id='assignTask']/div/div[2]/div/div[2]/div/div[1]/div[1]/div[1]/div/ul/li[5]")
	WebElement setpickerhh;
	
	@FindBy(xpath = "//*[@id='assignTask']/div/div[2]/div/div[2]/div/div[1]/div[1]/div[2]/span")
	WebElement clkpickermm;
	
	@FindBy(xpath = "//*[@id='assignTask']/div/div[2]/div/div[2]/div/div[1]/div[1]/div[2]/div/ul/li[1]")
	WebElement setpickermm;
	
	@FindBy(xpath = "//*[@id='assignTask']/div/div[2]/div/div[1]/div/div[12]/div/div[2]/div/input")
	WebElement clkTopicker;
	
	@FindBy(xpath = "//*[@id='assignTask']/div/div[2]/div/div[2]/div/div[1]/div[1]/div[1]/span")
	WebElement setTopickerhh;
	
	@FindBy(xpath = "//*[@id='assignTask']/div/div[2]/div/div[2]/div/div[1]/div[1]/div[1]/div/ul/li[6]")
	WebElement clkTopickerhh;
	
	
		
	
	
	public cleanlinesandsanitization() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}
	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	Actions actions = new Actions(driver);
	
	public boolean cleanandsnati() throws Exception{
		
		Thread.sleep(2000);
		clkcleanandsanti.click();
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//div[@class='pageTitle']/h2")).size()>0){
			System.out.println("Successfully open the Cleanliness & Sanitization page");	
			return true;
		}
			else {
				System.out.println("Does not open the Cleanliness & Sanitization page");	
			return false;
			}
		
		}
	
	public boolean checkaddplant() throws Exception{
		
		Thread.sleep(3000);
		WebElement element = driver.findElement(By.xpath("//span[@class='addBtn']//i[@class='addIcon']"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//div[text()='Add Branch']")).size()>0){
			System.out.println("Successfully open the Add plant");	
			return true;
		}
			else {
				System.out.println("Does not Add plant");	
			return false;
			}
				
	}
	
	public boolean addplantdetails() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Add Branch']")));
		plantname.sendKeys("CMC");
		Thread.sleep(2000);
		address.sendKeys("frontoffice");
		Thread.sleep(2000);
		empsearch.sendKeys("CNT10026");
		driver.findElement(By.xpath("//mark[text()='CNT10026']")).click();
		Thread.sleep(6000);
		areas.sendKeys("Reception");
		Thread.sleep(2000);
		addareas.click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='addPlant']/div/div[2]/form/div/div[3]/div[2]/div[2]/div[2]/input")).sendKeys("Cabin");
		Thread.sleep(3000);
		clkverify.click();
		Thread.sleep(4000);
		if(driver.findElements(By.xpath("//div[@class='cardItem']/h2[text()='CMC']")).size()>0){
			System.out.println("Successfully Add Branch");	
			return true;
		}
			else {
			System.out.println("Does not Add Branch");	
			return false;
			}
	}
	
	public void addplantedit() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='pageTitle']/h2")));
		Thread.sleep(4000);
		WebElement webElement = driver.findElement(By.xpath("//div[@class='nav-item']/a/div/div/div/h2[text()='CMC']/following-sibling::div/i"));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", webElement);
		//actions.moveToElement(driver.findElement(By.xpath("//div[@class='nav-item']/a/div/div/div/h2[text()='CMC']/following-sibling::div/i"))).click().build().perform();
		Thread.sleep(5000);
		address.clear();
		Thread.sleep(2000);
		address.sendKeys("chennai");
		Thread.sleep(2000);
		clkverify.click();
		Thread.sleep(4000);
	
	}
	
	public void assigntask() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='pageTitle']/h2")));
		actions.moveToElement(driver.findElement(By.xpath("//div[@class='nav-item']/a/div/div/div/h2[text()='CMC']/following::div/div/div/h4[text()='Total Tasks']"))).click().build().perform();
		Thread.sleep(5000);
		clkassigntask.click();
		Thread.sleep(2000);
		Select drplist=new Select(driver.findElement(By.xpath("//select[@name='clientPlanAreaDetailId']")));
		drplist.selectByVisibleText("Reception");
		Thread.sleep(2000);
		Select drptask=new Select(driver.findElement(By.xpath("//select[@name='taskMasterId']")));
		drptask.selectByVisibleText("Cleaning");
		Thread.sleep(2000);
		
		assignee.click();
		Thread.sleep(1000);
		assignee.sendKeys("vini");
		Thread.sleep(3000);
		assignee.sendKeys(Keys.ARROW_DOWN);
		Thread.sleep(3000);
		assignee.sendKeys(Keys.RETURN);		
		Thread.sleep(6000);
		
		driver.findElement(By.xpath("//input[@placeholder='Select Date']")).click();
		Thread.sleep(2000);
		datefix.click();
		Thread.sleep(4000);
		clkpicker.click();
		Thread.sleep(1000);
		clkpickerhh.click();
		Thread.sleep(1000);
		setpickerhh.click();
		Thread.sleep(2000);
		clkpickermm.click();
		Thread.sleep(1000);	
		clkpickermm.click();
		Thread.sleep(1000);	
		setpickermm.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='PM']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[text()='Done']")).click();
		Thread.sleep(1000);
		clkTopicker.click();
		Thread.sleep(1000);
		setTopickerhh.click();
		Thread.sleep(1000);
		clkTopickerhh.click();
		Thread.sleep(1000);
		clkpickermm.click();
		Thread.sleep(1000);
		clkpickermm.click();
		Thread.sleep(1000);
		setpickermm.click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[text()='PM']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[text()='Done']")).click();
		Thread.sleep(1000);
		
		
		/*dateHH.sendKeys("05");
		Thread.sleep(2000);
		dateMM.sendKeys("00");
		Thread.sleep(2000);
		Select hours=new Select(driver.findElement(By.xpath("//select[@aria-label='PM']")));
		hours.selectByVisibleText("PM");
		Thread.sleep(3000);
		dateHHH.sendKeys("06");
		Thread.sleep(2000);
		dateMMM.sendKeys("30");
		Thread.sleep(2000);
		Select mini=new Select(driver.findElement(By.xpath("//select[@aria-label='PM']")));
		mini.selectByVisibleText("AM");
		Thread.sleep(3000);*/
		clksave.click();
		Thread.sleep(3000);
		
	}
	
	public boolean deleteplant() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='pageTitle']/h2")));
		WebElement webElement = driver.findElement(By.xpath("//div[@class='nav-item']/a/div/div/div/h2[text()='CMC']/following-sibling::div/i"));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", webElement);
		Thread.sleep(3000);
		clkdeleteplant.click();
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//div[@class='pageTitle']/h2")).size()>0){
		  return true;
		}
		else {
		  return false;
			}
		
	}
	
	public void dropdownlist() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='pageTitle']/h2")));
		actions.moveToElement(driver.findElement(By.xpath("//div[@class='nav-item']/a/div/div/div/h2[text()='CMC']/following::div/div/div/h4[text()='Total Tasks']"))).click().build().perform();
		Thread.sleep(5000);
		Select drplist=new Select(driver.findElement(By.xpath("//select[@id='exampleFormControlSelect1']")));
		drplist.selectByVisibleText("Cabin");
		Thread.sleep(5000);
			
	}
	
	
	
	public boolean searchbtn() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='pageTitle']/h2")));
		actions.moveToElement(driver.findElement(By.xpath("//div[@class='nav-item']/a/div/div/div/h2[text()='CMC']/following::div/div/div/h4[text()='Total Tasks']"))).click().build().perform();
		Thread.sleep(5000);
		searchbtn.sendKeys("Disinfection");
		Thread.sleep(5000);
		if(driver.findElements(By.xpath("//div[@class='statusTableContainer']/div/table/tbody/tr/td[2]/div[text()='Disinfection']")).size()>0){
			return true;
			}
			else {
			return false;
		}
			
	}
	
	public void editassigntaskbtn() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='pageTitle']/h2")));
		actions.moveToElement(driver.findElement(By.xpath("//div[@class='nav-item']/a/div/div/div/h2[text()='CMC']/following::div/div/div/h4[text()='Total Tasks']"))).click().build().perform();
		Thread.sleep(5000);
		editbtn.click();
		Thread.sleep(5000);
		Select drptask=new Select(driver.findElement(By.xpath("//select[@name='taskMasterId']")));
		drptask.selectByVisibleText("Dispose Waste");
		Thread.sleep(5000);
	}
	
	public void deleteassigntaskbtn() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='pageTitle']/h2")));
		actions.moveToElement(driver.findElement(By.xpath("//div[@class='nav-item']/a/div/div/div/h2[text()='CMC']/following::div/div/div/h4[text()='Total Tasks']"))).click().build().perform();
		Thread.sleep(5000);
		deleteassignbtn.click();
		Thread.sleep(5000);
		deleteconfirmassignbtn.click();
		Thread.sleep(3000);
		
	}
	
	
	
}
	
