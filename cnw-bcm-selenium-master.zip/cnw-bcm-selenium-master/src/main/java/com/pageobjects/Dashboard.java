package com.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Base.Testbase;

public class Dashboard extends Testbase {
	
	@FindBy(xpath = "//a[@href='#/home/dashboard']/span/img")
	WebElement clkdashboard;
	
	@FindBy(xpath = "//div[@class='PieChart']/span/h5")
	WebElement clkpiechart;
	
	@FindBy(xpath = "//div[@class='progress-circle']/div/span[text()='COVID Confirmed']")
	WebElement clkcovid;
	
	//@FindBy(xpath = "//div[@class='progress-circle']/div/span[text()='Quarantine']")
	//WebElement clkstayathome;
	
	//@FindBy(xpath = "//div[@class='progress-circle']/div/span[text()='On Site']")
	//WebElement clkonsite;
	
	//@FindBy(xpath = "//div[@class='progress-circle']/div/span[text()='Suspected']")
	//WebElement clksuspected;
	
	@FindBy(xpath = "//span[text()='Quarantine']")
	WebElement clkstayathome;
		
	@FindBy(xpath = "//span[text()='WFO']")
	WebElement clkonsite;
	
	@FindBy(xpath = "//span[text()='Suspected']")
	WebElement clksuspected;
	
	@FindBy(xpath = "//div[@class='progress-circle']/div/span[text()='Recovered']")
	WebElement clkrecover;
	
	@FindBy(xpath = "//span[text()='WFH']")
	WebElement clkwfh;
	
	@FindBy(xpath = "//div[text()='Cleanliness & Sanitization']")
	WebElement clksanti;
	
	@FindBy(xpath = "//div[@class='plant-circle']")
	WebElement clkplantcir;
	
	@FindBy(xpath = "//button[@class='react-multiple-carousel__arrow react-multiple-carousel__arrow--left']")
	WebElement clkleftarr;
	
	@FindBy(xpath = "//button[@class='react-multiple-carousel__arrow react-multiple-carousel__arrow--right']")
	WebElement clkrightarr;
	
	@FindBy(xpath = "//div[text()='News & Update']")
	WebElement clknews;
	
	@FindBy(xpath = "//h6[@class='news-title']")
	WebElement clknewstitle;
	
	@FindBy(xpath = "//div[text()='Training & Awareness']")
	WebElement clkTraining;
	
	@FindBy(xpath = "//h6[@class='progress-name']")
	WebElement clkcourse;
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/div[3]/div/div/div[2]/div[2]/table/tbody/tr[1]/td[1]")
	WebElement clkcasehistory;
	
	@FindBy(xpath = "//table[@class='caseDetailsTable table table-striped']/tbody/tr[1]/td[4]/span/img[@src='/static/media/survey.89acf7fd.svg']")
	WebElement iWFHsurvey;
	
	@FindBy(xpath = "//a[text()='Quarantine']")
	WebElement surveyquarantine;
	
	@FindBy(xpath = "//a[text()='Work From Home']")
	WebElement surveyWFH;
	
	@FindBy(xpath = "//div[@id='survey-tab-tabpane-workFromHome']/div/div[2]/div/div[2]")
	WebElement surveytaken;
	
	@FindBy(xpath = "//div[@id='survey-tab-tabpane-workFromHome']/div/div[2]/div[2]/div[2]")
	WebElement surveynottaken;
	
	@FindBy(xpath = "//div[@id='survey-tab-tabpane-workFromHome']/div/div[2]/div[3]/div[2]")
	WebElement totalemp;
	
	
	@FindBy(xpath = "//*[@id='survey-tab-tabpane-onsiteWork']/div/div[2]/div[1]/div[2]")
	WebElement Qsurveytaken;
	
	@FindBy(xpath = "//*[@id='survey-tab-tabpane-onsiteWork']/div/div[2]/div[2]/div[2]")
	WebElement Qsurveynottaken;
	
	@FindBy(xpath = "//*[@id='survey-tab-tabpane-onsiteWork']/div/div[2]/div[3]/div[2]")
	WebElement Qtotalemp;
	
	@FindBy(xpath = "//button[@class='react-multiple-carousel__arrow react-multiple-carousel__arrow--right']")
	WebElement rightarrow;
	
	@FindBy(xpath = "//button[@class='react-multiple-carousel__arrow react-multiple-carousel__arrow--left']")
	WebElement leftarrow;
	
	@FindBy(xpath = "//input[@placeholder='Search']")
	WebElement searchbtn;
	
	@FindBy(xpath = "//span[@class='td-employee-name']")
	WebElement nameclk;
	
	@FindBy(xpath = "//table[@class='caseDetailsTable table table-striped']/tbody/tr[1]/td[4]/span/img[@src='/static/media/survey.89acf7fd.svg']")
	WebElement isurvey;
	
	
	public Dashboard() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}
	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	Actions actions = new Actions(driver);
	
	public boolean dashboardpage() throws Exception{
		
		Thread.sleep(2000);
		clkdashboard.click();
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//div[@class='welcome-text']/div")).size()>0){
		System.out.println("Successfully open the dashboard page");	
			return true;
		}
			else {
				System.out.println("Does not open the dashboard page");	
			return false;
			}
		
		}
	
	public boolean piechartdashboardpage() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkpiechart.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h5[text()='Employee Directory  - ']")).size()>0){
		System.out.println("Successfully open the employee directory page");	
			return true;
		}
			else {
				System.out.println("Does not open the employee directory page");	
			return false;
			}
		
		}
	
	public boolean coviddashboardpage() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkcovid.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h5[text()='COVID Confirmed  - ']")).size()>0){
		System.out.println("Successfully open the covid confirmed page");	
			return true;
		}
			else {
				System.out.println("Does not open the covid confirmed page");	
			return false;
			}
		
		}
	
	public boolean staydashboardpage() throws Exception{
		Thread.sleep(2000);
		clkdashboard.click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkstayathome.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h5[text()='Quarantine  - ']")).size()>0){
		System.out.println("Successfully open the stay at home page");	
			return true;
		}
			else {
				System.out.println("Does not open the stay at home page");	
			return false;
			}
		
		}
	
	public boolean onsitedashboardpage() throws Exception{
		Thread.sleep(2000);
		clkdashboard.click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkonsite.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h5[text()='On Site  - ']")).size()>0){
		System.out.println("Successfully open the Onsite page and employee entered under onsite");	
			return true;
		}
			else {
				System.out.println("Does not open the Onsite page and employee not entered under onsite");	
			return false;
			}
		
		}
	
	public boolean suspectdashboardpage() throws Exception{
		Thread.sleep(2000);
		clkdashboard.click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clksuspected.click();	
		Thread.sleep(3000);
		searchbtn.click();
		Thread.sleep(1000);
		searchbtn.sendKeys("Arunsundar");
		Thread.sleep(1000);
		nameclk.click();
		Thread.sleep(1000);
		isurvey.click();
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//div[@class='tableData row align-items-center']")).size()>0){
		System.out.println("Successfully open the Suspected page and employee entered under suspected");	
			return true;
		}
			else {
				System.out.println("Does not open the Suspected page and employee not entered under suspected");	
			return false;
			}
		
		}
	
	public boolean ferentocel() throws Exception{
		Thread.sleep(2000);
		clkdashboard.click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkonsite.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h5[text()='On Site  - ']")).size()>0){
			System.out.println("Successfully open the Onsite page and employee entered under onsite");	
				return true;
			}
				else {
					System.out.println("Does not open the Suspected page and employee not entered under onsite");	
				return false;
				}
			
		}
	
	public boolean celtofren() throws Exception{
		Thread.sleep(2000);
		clkdashboard.click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkonsite.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h5[text()='On Site  - ']")).size()>0){
			System.out.println("Successfully open the Onsite page and employee entered under onsite");	
				return true;
			}
				else {
					System.out.println("Does not open the Suspected page and employee not entered under onsite");	
				return false;
				}
			
		}
	
	public boolean recoverdashboardpage() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkrecover.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h5[text()='Recovered  - ']")).size()>0){
		System.out.println("Successfully open the Recovered page");	
			return true;
		}
			else {
				System.out.println("Does not open the Recovered page");	
			return false;
			}
		
		}
	
	public boolean cleanandsantidashboardpage() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clksanti.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//div[@class='welcome-text']/div/h2")).size()>0){
		System.out.println("Successfully open the cleanliness&santization page");	
			return true;
		}
			else {
				System.out.println("Does not open the cleanliness&santization page");	
			return false;
			}
		
		}
	
	public boolean circlecleandashboardpage() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkplantcir.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h4[text()='Status']")).size()>0){
		System.out.println("Successfully open the cleanliness&santization plant details page");	
			return true;
		}
			else {
				System.out.println("Does not open the cleanliness&santization plant page");	
			return false;
			}
		
		}
	
	public void arrowscleandashboardpage() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkrightarr.click();	
		Thread.sleep(5000);
		clkleftarr.click();
		Thread.sleep(5000);
		
	}
	
	public boolean newsdashboardpage() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clknews.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//a[text()='Company']")).size()>0){
		System.out.println("Successfully open the Newsandupdate page");	
			return true;
		}
			else {
				System.out.println("Does not open the Newsandupdate page");	
			return false;
			}
		
		}

	public boolean newsreaddashboardpage() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clknewstitle.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//div[text()='Total nagative casses on Jun 18']")).size()>0){
		System.out.println("Successfully open the Newsandupdate title page");	
			return true;
		}
			else {
				System.out.println("Does not open the Newsandupdate title page");	
			return false;
			}
		
		}
	
	public void scrolldashboardpage() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(5000);
		
	}
	
	public boolean trainingdashboardpage() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkTraining.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h3[text()='Total Courses ']")).size()>0){
		System.out.println("Successfully open the Training and awareness page");	
			return true;
		}
			else {
				System.out.println("Does not open the Training and awareness page");	
			return false;
			}
		
		}

	public boolean coursedashboardpage() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkcourse.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h2[text()='Courses Details']")).size()>0){
		System.out.println("Successfully open the Training and awareness course page");	
			return true;
		}
			else {
				System.out.println("Does not open the Training and awareness course page");	
			return false;
			}
		
		}
	
	public boolean wfhdashboardpage() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkwfh.click();	
		Thread.sleep(3000);
		clkcasehistory.click();
		Thread.sleep(3000);
		iWFHsurvey.click();
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//div[text()='Case History']")).size()>0){
		System.out.println("Successfully open the work from home Case history page");	
			return true;
		}
			else {
				System.out.println("Does not open the case history work from home page");	
			return false;
			}
		
		}
	
	
	public void scrolltraindashboardpage() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(5000);
		
	}
	
	public void surveytabs() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Survey']")));
		surveyquarantine.click();
		Thread.sleep(2000);
		surveyWFH.click();
		Thread.sleep(2000);
			
		
	}
	
	public void surveytabsWFH() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Survey']")));
		surveyquarantine.click();
		Thread.sleep(2000);
		surveyWFH.click();
		Thread.sleep(2000);
			
		
	}
	
	public String wfhsurveydetails() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Survey']")));
		System.out.println(surveytaken.getText());
		return surveytaken.getText();
	}
	
	public String wfhnottakendetails() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Survey']")));
		System.out.println(surveynottaken.getText());
		return surveynottaken.getText();
	}
	
	public String wfhtotalemptakendetails() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Survey']")));
		System.out.println(totalemp.getText());
		return totalemp.getText();
	}
	
	public String qsurveydetails() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Survey']")));
		System.out.println(Qsurveytaken.getText());
		return Qsurveytaken.getText();
	}
	
	public String qnottakendetails() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Survey']")));
		System.out.println(Qsurveynottaken.getText());
		return Qsurveynottaken.getText();
	}
	
	public String qtotalemptakendetails() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Survey']")));
		System.out.println(Qtotalemp.getText());
		return Qtotalemp.getText();
	}
	
	public void empdirarrows() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		rightarrow.click();
		Thread.sleep(2000);
		leftarrow.click();
		Thread.sleep(6000);
			
	}
	
	
}