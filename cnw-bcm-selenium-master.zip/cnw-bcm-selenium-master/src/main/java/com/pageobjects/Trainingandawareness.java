package com.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Base.Testbase;

public class Trainingandawareness extends Testbase {
	
	@FindBy(xpath = "//a[@href='#/home/traningawareness']/span/img")
	WebElement clktrainaware;
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/div[1]/div/div")
	WebElement clkassigncourse;
	
	@FindBy(xpath = "//div[@class='courseDetails']//div[text()='IAP']")
	WebElement coursename;
	
	@FindBy(xpath = "//button[@class='rdl-move rdl-move-right']")
	WebElement arrow;
	
	@FindBy(xpath = "//button[text()='Assign']")
	WebElement clkassign;
	
	@FindBy(xpath = "//button[@class='close']/span")
	WebElement cancelassign;
	
	@FindBy(xpath = "//h4[@class='resutl error']")
	WebElement clkyettostart;
	
	@FindBy(xpath = "//h4[@class='resutl warning border-0']")
	WebElement clkinprogress;
	
	@FindBy(xpath = "//h4[@class='resutl success']")
	WebElement clkcompleted;
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/div[1]/div/h2/span/img")
	WebElement clkreturnarrow;
	
	
	
	
	
	public Trainingandawareness() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}
	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	
	public boolean trainaware() throws Exception{
		
		Thread.sleep(2000);
		clktrainaware.click();
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//h2[text()='Training & Awareness']")).size()>0){
			System.out.println("Successfully open the Training & Awareness page");	
			return true;
		}
			else {
				System.out.println("Does not open the Training & Awareness page");	
			return false;
			}
		
		}
	
	public boolean assigncourse() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Training & Awareness']")));
		clkassigncourse.click();
		Thread.sleep(2000);
		Select drplist=new Select(driver.findElement(By.xpath("//select[@name='categoryId']")));
		drplist.selectByVisibleText("Procedure of Wearing Mask");
		Thread.sleep(2000);
		Select drpnamelist=new Select(driver.findElement(By.xpath("//select[@name='departmentName']")));
		drpnamelist.selectByVisibleText("Software Developer");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//option[text()='Yeswanth']")).click();
		Thread.sleep(2000);
		arrow.click();
		Thread.sleep(2000);
		clkassign.click();
		Thread.sleep(2000);		
		//driver.findElement(By.xpath("//div[text()='Quiz Course ']")).click();
		//Thread.sleep(2000);
		//clkyettostart.click();
		//Thread.sleep(2000);
		if(driver.findElements(By.xpath("//h2[text()='Training & Awareness']")).size()>0){
			System.out.println("Successfully assign the course to the employee");	
			return true;
		}
			else {
				System.out.println("Does not assign the course to the employee");	
			return false;
			}
		
		
	}
	
	public boolean cancelassign() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Training & Awareness']")));
		clkassigncourse.click();
		Thread.sleep(2000);
		cancelassign.click();
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//h2[text()='Training & Awareness']")).size()>0){
			System.out.println("Successfully cancel the assign the course");	
			return true;
		}
			else {
				System.out.println("Does not cancel the assign the course");	
			return false;
			}
			
	}
	
	public boolean yettostartcourse() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Training & Awareness']")));
		driver.findElement(By.xpath("//div[text()='Child Development - 2']")).click();
		Thread.sleep(2000);	
		clkyettostart.click();
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//div[@class='ProgressConatiner']/div/div[@aria-valuenow='0']")).size()>0){
			return true;
		}
			else {
				
			return false;
			}
	}
	
	public boolean inprogresscourse() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Training & Awareness']")));
		driver.findElement(By.xpath("//div[text()='Child Development - 2']")).click();
		Thread.sleep(2000);	
		clkinprogress.click();
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//div[@class='ProgressConatiner']/div/div[@aria-valuenow='67']")).size()>0){
			return true;
		}
			else {
				
			return false;
			}
	}
	
	public boolean completedcourse() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Training & Awareness']")));
		driver.findElement(By.xpath("//div[text()='Child Development - 2']")).click();
		Thread.sleep(2000);	
		clkcompleted.click();
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//div[@class='ProgressConatiner']/div/div[@aria-valuemax='100']")).size()>0){
			return true;
		}
			else {
				
			return false;
			}
	}
	
	public boolean returnarrow() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Training & Awareness']")));
		driver.findElement(By.xpath("//div[text()='Child Development - 2']")).click();
		Thread.sleep(2000);	
		clkreturnarrow.click();
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//h2[text()='Training & Awareness']")).size()>0){
			return true;
		}
			else {
			return false;
			}
		
	}
	

}
