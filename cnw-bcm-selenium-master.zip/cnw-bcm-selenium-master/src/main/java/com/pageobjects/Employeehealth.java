package com.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Base.Testbase;

public class Employeehealth extends Testbase {
	
	@FindBy(xpath = "//a[@href='#/home/employeehealth']/span/img")
	WebElement clkemployeehealth;
	
	@FindBy(xpath = "//*[@id='messageForm']/div[1]/div[1]/div[1]/div/div/input[1]")
	WebElement empcode;
	
	@FindBy(xpath = "//*[@id='temp']")
	WebElement emptemp;
	
	@FindBy(xpath = "//*[@id='messageForm']/div[3]/div/label[1]/div[1]/img")
	WebElement empsym;	

	@FindBy(xpath = "//*[@id='messageForm']/div[4]/div/label[1]")
	WebElement empppe;
	
	@FindBy(xpath = "//button[text()='Submit']")
	WebElement empsubmit;
	
	@FindBy(xpath = "//button[text()='Verify']")
	WebElement clkverify;
	
	@FindBy(xpath = "//button[@id='user-profile']/img")
	WebElement clkuserprofile;
	
	@FindBy(xpath = "//a[text()='Logout']")
	WebElement logout;
	
	@FindBy(xpath = "//h5[text()='Stay at Home - ']/span[@class='chartValue']")
	WebElement stayathomecount;
	
	@FindBy(xpath = "//h5[text()='Stay at Home - ']")
	WebElement clkstayathome;
	
	@FindBy(xpath = "//div[@class='emp-health card']//div//div")
	WebElement clkemphealth;
	
	@FindBy(xpath = "//h5[text()='Employee Directory  - ']//span")
	WebElement empdircounts;
	
	@FindBy(xpath = "//div[@class='PieChart']/span/h5")
	WebElement totalcount;
	
	@FindBy(xpath = "//span[text()='WFO']//parent::div//*[local-name()='svg']//*[local-name()='text']")
	WebElement onsitecount;
	
	@FindBy(xpath = "//span[text()='WFO']")
	WebElement clkonsitecount;
	
	@FindBy(xpath = "//h5[text()='On Site  - ']/span")
	WebElement iOnsitecount;
	
	@FindBy(xpath = "//span[text()='Quarantine']")
	WebElement clkquarantinedash;
	
	@FindBy(xpath = "//span[text()='Quarantine']//parent::div//*[local-name()='svg']//*[local-name()='text']")
	WebElement quarantinecountdash;
	
	@FindBy(xpath = "//h5[text()='Quarantine  - ']//span")
	WebElement iquarantinecount;
	
	@FindBy(xpath = "//span[text()='Suspected']")
	WebElement clksuspecteddash;
	
	@FindBy(xpath = "//span[text()='Suspected']//parent::div//*[local-name()='svg']//*[local-name()='text']")
	WebElement suspectedcountdash;
	
	@FindBy(xpath = "//h5[text()='Suspected - ']//span")
	WebElement isuspectedcount;
	
	@FindBy(xpath = "//span[text()='COVID Confirmed']")
	WebElement clkcoviddash;
	
	@FindBy(xpath = "//span[text()='COVID Confirmed']//parent::div//*[local-name()='svg']//*[local-name()='text']")
	WebElement covidcountdash;
	
	@FindBy(xpath = "//h5[text()='COVID Confirmed  - ']//span")
	WebElement icovidcount;
	
	@FindBy(xpath = "//span[text()='WFH']")
	WebElement clkWFHdash;
	
	@FindBy(xpath = "//span[text()='WFH']//parent::div//*[local-name()='svg']//*[local-name()='text']")
	WebElement WFHcountdash;
	
	@FindBy(xpath = "//h5[text()='Work from Home  - ']//span")
	WebElement iWFHcount;
	
	@FindBy(xpath = "//table[@class='caseDetailsTable table table-striped']/tbody/tr[1]/td[4]/span/img[@src='/static/media/survey.89acf7fd.svg']")
	WebElement iWFHsurvey;
	
	@FindBy(xpath = "//input[@placeholder='Search']")
	WebElement iWFHsearch;
	
	@FindBy(xpath = "//button[@class='react-multiple-carousel__arrow react-multiple-carousel__arrow--right']")
	WebElement rightarrow;
	
	@FindBy(xpath = "//button[@class='react-multiple-carousel__arrow react-multiple-carousel__arrow--left']")
	WebElement leftarrow;
	
	
	public Employeehealth() {
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 40), this);
	}
	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	
	public boolean emphealth() throws Exception{
		
		Thread.sleep(2000);
		clkemphealth.click();
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//h2[text()='Employee Health']")).size()>0){
			System.out.println("Successfully open the employee health page");	
			return true;
		}
			else {
				System.out.println("Does not open the employee health page");	
			return false;
			}
		
		}
	
	public boolean onsitedashboardpage() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkonsitecount.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h5[text()='On Site  - ']")).size()>0){
		System.out.println("Successfully open the Onsite page and employee entered under onsite");	
			return true;
		}
			else {
				System.out.println("Does not open the Onsite page");	
			return false;
			}
		
	}
	
	public boolean quarantinedashboardpage() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkquarantinedash.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h5[text()='Quarantine  - ']")).size()>0){
		System.out.println("Successfully open the Quarantine page");	
			return true;
		}
			else {
				System.out.println("Does not open the Quarantine page");	
			return false;
			}
		
	}
	
	public boolean suspecteddashboardpage() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clksuspecteddash.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h5[text()='Suspected - ']")).size()>0){
		System.out.println("Successfully open the Suspected page");	
			return true;
		}
			else {
				System.out.println("Does not open the Suspected page");	
			return false;
			}
		
	}
	
	public boolean coviddashboardpage() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkcoviddash.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h5[text()='COVID Confirmed  - ']")).size()>0){
		System.out.println("Successfully open the Covid confirmed page");	
			return true;
		}
			else {
				System.out.println("Does not open the Covid confirmed page");	
			return false;
			}
		
	}
	
	public boolean wfhdashboardpage() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='welcome-text']/div")));
		clkWFHdash.click();	
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h5[text()='Work from Home  - ']")).size()>0){
		System.out.println("Successfully open the Work from home page");	
			return true;
		}
			else {
				System.out.println("Does not open the Work from home page");	
			return false;
			}
		
	}
	
	public String empdircounts() throws Exception{
		Thread.sleep(4000);
		System.out.println(empdircounts.getText());
		return empdircounts.getText();
		
		
	}
	
	public boolean countsinempdir() throws Exception{
		
		int dashno=driver.findElements(By.xpath("//div[@class='PieChart']/span/h5")).size();
		int idirempno=driver.findElements(By.xpath("//h5[text()='Employee Directory  - ']//span")).size();
		
		if(dashno == idirempno) {
			
			return true;
			
		}
		else {
			
			return false;
			
		}
		
		
	}
	
	public String onsitedircounts() throws Exception{
		Thread.sleep(4000);
		System.out.println(iOnsitecount.getText());
		return iOnsitecount.getText();
	
		
	}	
	
	public String onsitedircountdash() throws Exception{
		Thread.sleep(4000);
		System.out.println(onsitecount.getText());
		return onsitecount.getText();
	
		
	}
	
	public boolean onsitecountsinempdir() throws Exception{
		
		int donsiteno=driver.findElements(By.xpath("//span[text()='OnSite']//parent::div//*[local-name()='svg']//*[local-name()='text']")).size();
		int ionsiteno=driver.findElements(By.xpath("//h5[text()='On Site  - ']/span")).size();
		
		if(donsiteno == ionsiteno) {
			
			return true;
			
		}
		else {
			
			return false;
			
		}
		
	}
	
	public String quarantinecountdash() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Employee Health']")));
		Thread.sleep(3000);
		System.out.println(quarantinecountdash.getText());
		return quarantinecountdash.getText();
	}
	
	public String iquarantinecountdash() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Employee Health']")));
		Thread.sleep(3000);
		System.out.println(iquarantinecount.getText());
		return iquarantinecount.getText();
	}
		
	public boolean comparequarantinetotals() throws Exception{
		
		int dquranno=driver.findElements(By.xpath("//span[text()='Quarantine']//parent::div//*[local-name()='svg']//*[local-name()='text']")).size();
		int iquaranno=driver.findElements(By.xpath("//h5[text()='Quarantine  - ']//span")).size();
		
		if(dquranno == iquaranno) {
			
			return true;
			
		}
		else {
			
			return false;
			
		}
		
	}
	
	public String covidcountdash() throws Exception{
		
		Thread.sleep(3000);
		System.out.println(covidcountdash.getText());
		return covidcountdash.getText();
	}
	
	public String icovidcountdash() throws Exception{
		
		Thread.sleep(3000);
		System.out.println(icovidcount.getText());
		return icovidcount.getText();
	}
	
	public boolean comparecovidtotals() throws Exception{
		
		int dCovidno=driver.findElements(By.xpath("//span[text()='COVID Confirmed']//parent::div//*[local-name()='svg']//*[local-name()='text']")).size();
		int iCovidno=driver.findElements(By.xpath("//h5[text()='COVID Confirmed  - ']//span")).size();
		
		if(dCovidno == iCovidno) {
			
			return true;
			
		}
		else {
			
			return false;
			
		}
	}
	
	public String suspectcountdash() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Employee Health']")));
		Thread.sleep(3000);
		System.out.println(suspectedcountdash.getText());
		return suspectedcountdash.getText();
	}
	
	public String isuspectcountdash() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Employee Health']")));
		Thread.sleep(3000);
		System.out.println(isuspectedcount.getText());
		return isuspectedcount.getText();
	}
	
	public boolean comparesuspecttotals() throws Exception{
		
		int dSuspectsno=driver.findElements(By.xpath("//span[text()='Suspected']//parent::div//*[local-name()='svg']//*[local-name()='text']")).size();
		int iSuspectno=driver.findElements(By.xpath("//h5[text()='Suspected - ']//span")).size();
		
		if(dSuspectsno == iSuspectno) {
			
			return true;
			
		}
		else {
			
			return false;
			
		}
		
	}
	
	public String wfhcountdash() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Employee Health']")));
		Thread.sleep(3000);
		System.out.println(WFHcountdash.getText());
		return WFHcountdash.getText();
	}
	
	public String iwfhcountdash() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Employee Health']")));
		Thread.sleep(3000);
		System.out.println(iWFHcount.getText());
		return iWFHcount.getText();
	}
	
	public boolean comparewfhtotals() throws Exception{
		
		int dwfhno=driver.findElements(By.xpath("//span[text()='Work from Home']//parent::div//*[local-name()='svg']//*[local-name()='text']")).size();
		int iwfhno=driver.findElements(By.xpath("//h5[text()='Work from Home  - ']//span")).size();
		
		if(dwfhno == iwfhno) {
			return true;
			
		}
		else {
			return false;
			
		}
		
	}
	
	
	public boolean surveystatusforemp() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Entry Health Check']")));
		empcode.sendKeys("1133");
		Thread.sleep(3000);
		empcode.sendKeys(Keys.ARROW_DOWN);
		Thread.sleep(3000);
		empcode.sendKeys(Keys.RETURN);		
		Thread.sleep(6000);
		emptemp.sendKeys("140");
		Thread.sleep(4000);
		empsym.click();
		Thread.sleep(4000);
		empppe.click();
		Thread.sleep(2000);
		clkverify.click();
		Thread.sleep(7000);
		empsubmit.click();
		Thread.sleep(4000);
		if(driver.findElements(By.xpath("//button[text()='Submit']")).size()>0){
			return true;
		}
			else {
				
			return false;
			}
	}

	public void logout() throws Exception{
		Thread.sleep(2000);
		clkuserprofile.click();
		Thread.sleep(1000);
		logout.click();
		Thread.sleep(1000);
	
	}
	
	public String stayathomeofcount() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Employee Health']")));
		System.out.println(stayathomecount.getText());
		return stayathomecount.getText();
	}
	
	public void stayathome() throws Exception{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Employee Health']")));
		clkstayathome.click();
		Thread.sleep(2000);
		
	}
	
	public String onsitecountdash() throws Exception{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Employee Health']")));

		Thread.sleep(3000);


		System.out.println(onsitecount.getText());
		return onsitecount.getText();
	}
	
	
	public boolean empdirdropdown() throws Exception{
		
		Thread.sleep(1000);
		clkemphealth.click();
		Select branch=new Select(driver.findElement(By.xpath("//div[@class='custom-emp-select form-group']/select[@class='newEmpdirtory form-control']")));
		branch.selectByVisibleText("Work from Home");
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h5[text()='Work from Home  - ']")).size()>0){
			return true;
		}
			else {
				
			return false;
			}
		
	}
	
	public boolean empdirsearch() throws Exception{
		
		Thread.sleep(1000);
		clkemphealth.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h5[text()='Employee Directory  - ']")));
		iWFHsearch.sendKeys("rakhi");
		Thread.sleep(6000);
		if(driver.findElements(By.xpath("//span[text()='Rakhi Deepak ']")).size()>0){
			return true;
		}
			else {
				
			return false;
			}
		
	}
	
	public void empdirarrows() throws Exception{
		
		Thread.sleep(1000);
		clkemphealth.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h5[text()='Employee Directory  - ']")));
		rightarrow.click();
		Thread.sleep(2000);
		leftarrow.click();
		Thread.sleep(6000);
			
	}
	
	public void scrollin() throws Exception{
		Thread.sleep(1000);
		clkemphealth.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h5[text()='Employee Directory  - ']")));
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(5000);
		
	}
			 
	
}
	

