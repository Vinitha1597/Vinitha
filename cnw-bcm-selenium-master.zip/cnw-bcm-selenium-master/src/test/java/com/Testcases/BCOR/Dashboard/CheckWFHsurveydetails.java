package com.Testcases.BCOR.Dashboard;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.Dashboard;
import com.pageobjects.Employeehealth;
import com.pageobjects.loginpage;

public class CheckWFHsurveydetails extends Testbase {
	
	loginpage login;
	Dashboard dash;
	Employeehealth eh;
	
	
	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("To view details WFH survey tabs in dashboard page","To view details WFH survey tabs in dashboard page");
		login = new loginpage();
		dash=new Dashboard();
		eh=new Employeehealth();
		test.log(Status.INFO, "Login as AKKU_BCOR");
		login.Login(prop.getProperty("email_at_dashboard_Merit"), prop.getProperty("password_at_dashboard_Merit"));
		Thread.sleep(4000);
		test.log(Status.PASS, "Successfully login the AKKU_BCOR application");
	}
	
	@Test(priority = 1)
	public void checksurveytabs() throws Exception {
		test.log(Status.INFO, "To enter survey in dashboard page");
		test.log(Status.INFO, "To view the employee taken survey details in WFH");
		int count = Integer.parseInt(dash.wfhsurveydetails());
		test.log(Status.INFO, "The WFH taken survey details is : "+count);
	}
	
	@Test(priority = 2)
	public void checknottakentabs() throws Exception {
		test.log(Status.INFO, "To enter survey in dashboard page");
		test.log(Status.INFO, "To view the employee not taken survey details in WFH");
		int ncount = Integer.parseInt(dash.wfhnottakendetails());
		test.log(Status.INFO, "The WFH not taken survey details is : "+ncount);
	}
	
	@Test(priority = 3)
	public void checktotaltabs() throws Exception {
		test.log(Status.INFO, "To enter survey in dashboard page");
		test.log(Status.INFO, "To view the total employee WFH details");
		int tcount = Integer.parseInt(dash.wfhtotalemptakendetails());
		test.log(Status.INFO, "The WFH total employee details is : "+tcount);
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
	
	
}
	





