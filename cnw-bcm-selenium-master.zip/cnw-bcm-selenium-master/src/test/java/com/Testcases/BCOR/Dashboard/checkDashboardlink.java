package com.Testcases.BCOR.Dashboard;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.Dashboard;
import com.pageobjects.Employeehealth;
import com.pageobjects.Empsurveystatus;
import com.pageobjects.cleanlinesandsanitization;
import com.pageobjects.loginpage;

public class checkDashboardlink extends Testbase {
	
	loginpage login;
	Dashboard dash;
	
	
	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("To check dashboard page link","To check dashboard page link");
		login = new loginpage();
		dash=new Dashboard();
		test.log(Status.INFO, "Login as BCM");
		login.Login(prop.getProperty("email_at_dashboard_cloudnowBCM"), prop.getProperty("password_at_dashboard_cloudnowBCM"));
		Thread.sleep(4000);
		test.log(Status.PASS, "Successfully login the BCM");

	}
	
	@Test(priority = 1)
	public void checkdashlink() throws Exception {
		test.log(Status.INFO, "To enter dashboard page");
		AssertJUnit.assertTrue(dash.dashboardpage());
		test.log(Status.PASS, "Successfully Open the dashboard page");
	}
	
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
	
	
}
	
