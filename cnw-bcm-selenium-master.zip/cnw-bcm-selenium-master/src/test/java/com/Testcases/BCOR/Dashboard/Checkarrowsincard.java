package com.Testcases.BCOR.Dashboard;

import org.testng.AssertJUnit;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.Dashboard;
import com.pageobjects.Employeehealth;
import com.pageobjects.loginpage;

public class Checkarrowsincard extends Testbase {
	
	loginpage login;
	Dashboard dash;
	Employeehealth eh;
	
	
	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("To check left and right arrows in dashboard page","To check left and right arrows in dashboard page");
		login = new loginpage();
		dash=new Dashboard();
		eh=new Employeehealth();
		test.log(Status.INFO, "Login as AKKU_BCOR");
		login.Login(prop.getProperty("email_at_dashboard_Merit"), prop.getProperty("password_at_dashboard_Merit"));
		Thread.sleep(4000);
		test.log(Status.PASS, "Successfully login the AKKU_BCOR application");
	}
	
	@Test(priority = 1)
	public void checkarrows() throws Exception {
		test.log(Status.INFO, "To enter employee dirctory page");
		dash.empdirarrows();
		test.log(Status.PASS, "Successfully arrows moved left and right");
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
	
	
}
	



