package com.Testcases.BCM.SurveyStatus;


import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;


import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.Empsurveystatus;
import com.pageobjects.loginpage;

public class surveystatus extends Testbase {
	loginpage login;
	Empsurveystatus empstatus;
	
	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("Employee Survey Status", "Employee Survey Status");
		login = new loginpage();
		empstatus=new Empsurveystatus();
		test.log(Status.INFO, "Login as BCM");
		login.Login(prop.getProperty("email_at_security_BCM"), prop.getProperty("password_at_security_BCM"));
		Thread.sleep(4000);
		test.log(Status.PASS, "Successfully login the BCM");

	}
	
	@Test(priority = 1)
	public void empsurveystatus() throws Exception {
		
		test.log(Status.INFO, "Enter into a employee survey status");
		test.log(Status.INFO, "Check the employee yet to scan before count");
		int beforeyetdonecount = Integer.parseInt(empstatus.yettoscan());
		test.log(Status.INFO, "The employee yet to scan before count is : "+beforeyetdonecount);
		test.log(Status.INFO, "Check the employee scanned done before count");
		int beforedonecount = Integer.parseInt(empstatus.scancount());
		test.log(Status.INFO, "The employee done before done count is : "+beforedonecount);
		test.log(Status.INFO, "Enter the details of employee entry health check");
		Assert.assertTrue(empstatus.surveystatusforemp());
		test.log(Status.PASS, "Successfully entered the employee entry health check");
		test.log(Status.INFO, "Check the employee yet to scan after count");
		int afteryetdonecount = Integer.parseInt(empstatus.yettoscan());
		test.log(Status.INFO, "The employee yet to scan after count is : "+afteryetdonecount);
		int afterdonecount = Integer.parseInt(empstatus.scancount());
		test.log(Status.INFO, "The employee done after count is : "+afterdonecount);
		test.log(Status.PASS, "Successfully scan the employee survey status");
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}


}
