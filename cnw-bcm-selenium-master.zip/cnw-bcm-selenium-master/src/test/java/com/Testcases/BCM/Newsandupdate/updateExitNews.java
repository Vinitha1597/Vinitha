package com.Testcases.BCM.Newsandupdate;

import org.testng.Assert;
//import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.Newsandupdate;
import com.pageobjects.loginpage;

public class updateExitNews extends Testbase {
	
	loginpage login;
	Newsandupdate nau;
	
	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("To edit the updating existing News", "To edit the updating existing News");
		login = new loginpage();
		nau=new Newsandupdate();
		test.log(Status.INFO, "Login as BCM");
		login.Login(prop.getProperty("email_at_dashboard_cloudnowBCM"), prop.getProperty("password_at_dashboard_cloudnowBCM"));
		Thread.sleep(4000);
		test.log(Status.PASS, "Successfully login the BCM");

	}
	
	@Test(priority = 1)
	public void newsupdte() throws Exception {
		test.log(Status.INFO, "To Update the company news");
		nau.updateexitnews();
		Assert.assertTrue(nau.confirmupdatenews());
		test.log(Status.PASS, "Successfully Updated the Company News");
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
	
	
}


