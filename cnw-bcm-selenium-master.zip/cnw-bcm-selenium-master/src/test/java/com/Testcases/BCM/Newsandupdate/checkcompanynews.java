package com.Testcases.BCM.Newsandupdate;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.Newsandupdate;
import com.pageobjects.loginpage;

public class checkcompanynews extends Testbase {
	loginpage login;
	Newsandupdate nau;
	
	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("To check the Company News", "To check the Company News");
		login = new loginpage();
		nau=new Newsandupdate();
		test.log(Status.INFO, "Login as BCM");
		login.Login(prop.getProperty("email_at_dashboard_cloudnowBCM"), prop.getProperty("password_at_dashboard_cloudnowBCM"));
		Thread.sleep(4000);
		test.log(Status.PASS, "Successfully login the BCM");

	}
	
	@Test(priority = 1)
	public void chklink() throws Exception {
		test.log(Status.INFO, "Update the company news");
		Assert.assertTrue(nau.updatenews());
		test.log(Status.PASS, "Successfully updated the Company News");
		
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
	
	
}
