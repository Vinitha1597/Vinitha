package com.Testcases.BCM.Trainingawareness;

import org.testng.AssertJUnit;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.Trainingandawareness;
import com.pageobjects.loginpage;

public class assignCourse  extends Testbase {
	
	loginpage login;
	Trainingandawareness ta;
	
	
	
	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("To check the assign the course to the employee","To check the assign the course to the employee");
		login = new loginpage();
		ta=new Trainingandawareness();
		test.log(Status.INFO, "Login as BCM");
		login.Login(prop.getProperty("email_at_dashboard_cloudnowBCM"), prop.getProperty("password_at_dashboard_cloudnowBCM"));
		Thread.sleep(4000);
		test.log(Status.PASS, "Successfully login the BCM");

	}
	
	@Test(priority = 1)
	public void assignthecourse() throws Exception {
		test.log(Status.INFO, "To enter Training & Awareness page");
		AssertJUnit.assertTrue(ta.trainaware());
		test.log(Status.PASS, "Successfully Open the  Training & Awareness page");
		test.log(Status.INFO, "To assign the course to the employee");
		AssertJUnit.assertTrue(ta.assigncourse());	
		test.log(Status.PASS, "Successfully assign the course to the employee");
		
	}
	
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
	
	
}
	
