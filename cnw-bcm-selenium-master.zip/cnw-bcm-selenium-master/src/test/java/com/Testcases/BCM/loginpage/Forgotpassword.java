package com.Testcases.BCM.loginpage;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.loginpage;

public class Forgotpassword extends Testbase {
	loginpage login;
	
	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("To check forgotpassword page", "To check forgotpassword page");
		login = new loginpage();
		test.log(Status.INFO, "Login as BCM");
		Thread.sleep(4000);
		

}
	
	@Test(priority = 1)
	public void forgotpassword() throws Exception {
		
		test.log(Status.INFO, "Enter into a BCOR login page");
		Assert.assertTrue(login.forgotpass());
		test.log(Status.PASS, "Successfully reset password link send to the user");
		
	}
	
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}


	
}