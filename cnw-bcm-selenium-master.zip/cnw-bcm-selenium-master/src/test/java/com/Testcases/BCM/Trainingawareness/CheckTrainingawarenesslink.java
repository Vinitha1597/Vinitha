package com.Testcases.BCM.Trainingawareness;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
//import org.testng.AssertJUnit;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
//import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
//import com.pageobjects.Employeehealth;
//import com.pageobjects.Empsurveystatus;
import com.pageobjects.Trainingandawareness;
//import com.pageobjects.cleanlinesandsanitization;
import com.pageobjects.loginpage;

public class CheckTrainingawarenesslink extends Testbase {
	
	loginpage login;
	Trainingandawareness ta;
	
	
	
	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("To check Training & Awareness page link","To check Training & Awareness page link");
		login = new loginpage();
		ta=new Trainingandawareness();
		test.log(Status.INFO, "Login as BCM");
		login.Login(prop.getProperty("email_at_dashboard_cloudnowBCM"), prop.getProperty("password_at_dashboard_cloudnowBCM"));
		Thread.sleep(4000);
		test.log(Status.PASS, "Successfully login the BCM");

	}
	
	@Test(priority = 1)
	public void checktrainlink() throws Exception {
		test.log(Status.INFO, "To enter Training & Awareness page");
		AssertJUnit.assertTrue(ta.trainaware());
		test.log(Status.PASS, "Successfully Open the  Training & Awareness page");
	}
	
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
	
	
}
	
