package com.Testcases.BCM.loginpage;


import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Base.GenerateExtentReport;
import com.Base.Testbase;
import com.aventstack.extentreports.Status;
import com.pageobjects.loginpage;

public class Testmailinvitetion  extends Testbase {
	loginpage login;
	
	@BeforeTest
	public void setup() throws Exception {
		initialization(prop.getProperty("browser"));
		extent = GenerateExtentReport.getInstance();
		test = extent.createTest("To check forgotpassword Mail Invitetion", "To check forgotpassword Mail Invitetion");
		login = new loginpage();
		test.log(Status.INFO, "Login as BCM");
		Thread.sleep(4000);
		

}
	
	@Test(priority = 1)
	public void mailforgotpassword() throws Exception {
		
		test.log(Status.INFO, "Check the forgot password link page");
		login.openNewTab("https://akku-bcor.cloudnowtech.com/#/changepassword?token=tMAsVkOlct&email=prema.d@cloudnowtech.com");
		Thread.sleep(3000);
		login.SwitchToTheSecondTab();
		test.log(Status.INFO, "To set the forgot password");
		login.loginWithGmailAccount(prop.getProperty("To_set_newpassword"),prop.getProperty("To_set_confirmpassword"));
		test.log(Status.INFO, "Forgot password set successfully");
		login.openNew("http://bcm-qa.cloudnowtech.com/#/");
		Thread.sleep(3000);
		login.SwitchToTheSecondTab();
		login.setpassword();
		Thread.sleep(3000);
			
	}
	
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}


	
}