# cnw-bcm-selenium

This repository is created for automation script of BCM Project in Selenium